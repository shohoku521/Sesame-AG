package io.github.aoguai.sesameag.hook

import io.github.aoguai.sesameag.entity.UserEntity
import io.github.aoguai.sesameag.hook.keepalive.PersistentScheduleRegistry
import io.github.aoguai.sesameag.util.Files
import io.github.aoguai.sesameag.util.JsonUtil
import io.github.aoguai.sesameag.util.Log
import io.github.aoguai.sesameag.util.UserDataStoreManager
import kotlinx.coroutines.CancellationException
import java.io.File
import java.nio.channels.ClosedByInterruptException
import java.nio.channels.FileChannel
import java.nio.channels.FileLock
import java.nio.channels.FileLockInterruptionException
import java.nio.file.Files as NioFiles
import java.nio.file.StandardCopyOption.ATOMIC_MOVE
import java.nio.file.StandardCopyOption.REPLACE_EXISTING
import java.nio.file.StandardOpenOption.CREATE
import java.nio.file.StandardOpenOption.WRITE
import java.security.MessageDigest

const val MAX_EXECUTABLE_ACCOUNT_SLOTS = 2

enum class AccountSlotMigrationState {
    READY,
    SELECTION_REQUIRED,
}

data class AccountSlotRecord(
    val migrationState: AccountSlotMigrationState = AccountSlotMigrationState.READY,
    val activeUserIds: List<String> = emptyList(),
    val pendingRuntimeUserId: String? = null,
    val pendingRuntimeSinceMs: Long = 0L,
)

data class AccountSlotSnapshot(
    val migrationState: AccountSlotMigrationState,
    val activeUserIds: List<String>,
    val candidateUserIds: List<String>,
    val orphanedActiveUserIds: List<String> = emptyList(),
    val pendingRuntimeUserId: String? = null,
    val errorCode: String? = null,
) {
    val isReady: Boolean
        get() = errorCode == null && migrationState == AccountSlotMigrationState.READY
}

sealed interface AccountSlotAdmission {
    data class Allowed(
        val userId: String,
        val requiresConfirmation: Boolean,
        val pendingCreated: Boolean = false,
    ) : AccountSlotAdmission

    data class Denied(val reasonCode: String) : AccountSlotAdmission
}

sealed interface AccountSlotRuntimeConfirmation {
    data object Confirmed : AccountSlotRuntimeConfirmation

    data object PendingPersistence : AccountSlotRuntimeConfirmation

    data object Expired : AccountSlotRuntimeConfirmation

    data object RegistryUnavailable : AccountSlotRuntimeConfirmation
}

sealed interface AccountSlotExecutionCheck {
    data class Allowed(val userId: String) : AccountSlotExecutionCheck

    data object InvalidUserId : AccountSlotExecutionCheck

    data class Inactive(val userId: String) : AccountSlotExecutionCheck

    data object RegistryUnavailable : AccountSlotExecutionCheck
}

data class AccountSlotReplacement(
    val replaced: Boolean,
    val reasonCode: String? = null,
    val removedUserIds: List<String> = emptyList(),
)

/**
 * Separates locally stored account data from the accounts allowed to execute target-app work.
 * Registry writes are serialized across the module UI and injected target process with a stable lock
 * file; a lock or persistence failure deliberately denies business execution.
 */
object AccountSlotRegistry {
    private const val TAG = "AccountSlotRegistry"
    private const val RECORD_FILE_NAME = "account-slots.json"
    private const val LOCK_FILE_NAME = ".account-slots.lock"
    private const val MAX_USER_ID_LENGTH = 128
    private const val PENDING_RUNTIME_SLOT_TTL_MS = 120_000L
    private const val REGISTRY_UNAVAILABLE_LOG_INTERVAL_MS = 60_000L

    private val lastRegistryUnavailableLogAtMs = java.util.concurrent.atomic.AtomicLong(0L)

    private data class LoadedRecord(
        val record: AccountSlotRecord,
        val needsWrite: Boolean,
    )

    private data class LockedResult<T>(
        val value: T,
        val updatedRecord: AccountSlotRecord? = null,
    )

    fun snapshot(): AccountSlotSnapshot =
        withLockedRecord { loaded ->
            LockedResult(snapshotFor(loaded.record))
        } ?: AccountSlotSnapshot(
            migrationState = AccountSlotMigrationState.SELECTION_REQUIRED,
            activeUserIds = emptyList(),
            candidateUserIds = emptyList(),
            orphanedActiveUserIds = emptyList(),
            pendingRuntimeUserId = null,
            errorCode = "registry_unavailable",
        )

    fun admitRuntimeUser(rawUserId: String?): AccountSlotAdmission {
        val userId = normalizeUserId(rawUserId)
            ?: return AccountSlotAdmission.Denied("invalid_user_id")
        return withLockedRecord { loaded ->
            val record = loaded.record
            when (record.migrationState) {
                AccountSlotMigrationState.READY -> {
                    when {
                        userId in record.activeUserIds -> {
                            LockedResult(
                                AccountSlotAdmission.Allowed(userId, requiresConfirmation = false),
                            )
                        }

                        record.pendingRuntimeUserId == userId -> {
                            LockedResult(
                                AccountSlotAdmission.Allowed(userId, requiresConfirmation = true),
                            )
                        }

                        record.pendingRuntimeUserId != null -> {
                            LockedResult(AccountSlotAdmission.Denied("account_slot_provision_pending"))
                        }

                        record.activeUserIds.isEmpty() && configuredUserIds().isEmpty() -> {
                            LockedResult(
                                AccountSlotAdmission.Allowed(
                                    userId,
                                    requiresConfirmation = true,
                                    pendingCreated = true,
                                ),
                                record.copy(
                                    pendingRuntimeUserId = userId,
                                    pendingRuntimeSinceMs = System.currentTimeMillis(),
                                ),
                            )
                        }

                        else -> LockedResult(AccountSlotAdmission.Denied("account_slot_not_selected"))
                    }
                }

                AccountSlotMigrationState.SELECTION_REQUIRED -> {
                    LockedResult(AccountSlotAdmission.Denied("account_slot_migration_required"))
                }
            }
        }?.also { admission ->
            if (admission is AccountSlotAdmission.Allowed && admission.pendingCreated) {
                Log.record(TAG, "account_slot_provision_pending: account=${shortHash(userId)}")
            }
        } ?: AccountSlotAdmission.Denied("registry_unavailable")
    }

    fun confirmRuntimeUser(rawUserId: String?): AccountSlotRuntimeConfirmation {
        val userId = normalizeUserId(rawUserId)
            ?: return AccountSlotRuntimeConfirmation.PendingPersistence
        return withLockedRecord(recoverExpiredPending = false) { loaded ->
            val record = loaded.record
            when {
                record.pendingRuntimeUserId != userId -> {
                    LockedResult(AccountSlotRuntimeConfirmation.PendingPersistence)
                }

                isPendingRuntimeSlotExpired(record) -> {
                    LockedResult(
                        AccountSlotRuntimeConfirmation.Expired,
                        record.copy(
                            pendingRuntimeUserId = null,
                            pendingRuntimeSinceMs = 0L,
                        ),
                    )
                }

                !hasVerifiedConfiguredUser(userId) -> {
                    LockedResult(AccountSlotRuntimeConfirmation.PendingPersistence)
                }

                record.activeUserIds.size + 1 > MAX_EXECUTABLE_ACCOUNT_SLOTS -> {
                    LockedResult(AccountSlotRuntimeConfirmation.PendingPersistence)
                }

                else -> {
                    LockedResult(
                        AccountSlotRuntimeConfirmation.Confirmed,
                        record.copy(
                            activeUserIds = record.activeUserIds + userId,
                            pendingRuntimeUserId = null,
                            pendingRuntimeSinceMs = 0L,
                        ),
                    )
                }
            }
        }?.also { confirmation ->
            when (confirmation) {
                AccountSlotRuntimeConfirmation.Confirmed -> {
                    Log.record(TAG, "account_slot_provision_confirmed: account=${shortHash(userId)}")
                }

                AccountSlotRuntimeConfirmation.PendingPersistence -> {
                    Log.record(TAG, "account_slot_provision_unconfirmed: account=${shortHash(userId)}")
                    Log.w(TAG, "account_slot_provision_unconfirmed: account=${shortHash(userId)}")
                }

                AccountSlotRuntimeConfirmation.Expired -> {
                    Log.record(TAG, "account_slot_provision_expired: account=${shortHash(userId)}")
                    Log.w(TAG, "account_slot_provision_expired: account=${shortHash(userId)}")
                }

                AccountSlotRuntimeConfirmation.RegistryUnavailable -> Unit
            }
        } ?: AccountSlotRuntimeConfirmation.RegistryUnavailable
    }

    fun checkExecutableUser(rawUserId: String?): AccountSlotExecutionCheck {
        val userId = normalizeUserId(rawUserId) ?: return AccountSlotExecutionCheck.InvalidUserId
        return withLockedRecord<AccountSlotExecutionCheck> { loaded ->
            val record = loaded.record
            LockedResult(
                if (record.migrationState == AccountSlotMigrationState.READY && userId in record.activeUserIds) {
                    AccountSlotExecutionCheck.Allowed(userId)
                } else {
                    AccountSlotExecutionCheck.Inactive(userId)
                },
            )
        } ?: AccountSlotExecutionCheck.RegistryUnavailable
    }

    fun isExecutableUser(rawUserId: String?): Boolean =
        checkExecutableUser(rawUserId) is AccountSlotExecutionCheck.Allowed

    fun addExecutableSlot(
        context: android.content.Context?,
        rawUserId: String?,
    ): AccountSlotReplacement = mutateExecutableSlot(context, rawUserId, makeExecutable = true)

    fun removeExecutableSlot(
        context: android.content.Context?,
        rawUserId: String?,
    ): AccountSlotReplacement = mutateExecutableSlot(context, rawUserId, makeExecutable = false)

    private fun mutateExecutableSlot(
        context: android.content.Context?,
        rawUserId: String?,
        makeExecutable: Boolean,
    ): AccountSlotReplacement {
        val userId = normalizeUserId(rawUserId)
            ?: return AccountSlotReplacement(false, "invalid_user_id")
        val result = withLockedRecord { loaded ->
            val record = loaded.record
            val candidates = selectableUserIds()
            val occupiedSlotCount = record.activeUserIds.size +
                if (record.pendingRuntimeUserId == null) 0 else 1
            when {
                record.pendingRuntimeUserId != null -> {
                    LockedResult(AccountSlotReplacement(false, "account_slot_provision_pending"))
                }

                userId !in candidates -> {
                    LockedResult(AccountSlotReplacement(false, "unknown_slot_candidate"))
                }

                makeExecutable && userId in record.activeUserIds -> {
                    LockedResult(AccountSlotReplacement(false, "account_slot_already_active"))
                }

                makeExecutable && occupiedSlotCount >= MAX_EXECUTABLE_ACCOUNT_SLOTS -> {
                    LockedResult(AccountSlotReplacement(false, "account_slot_full"))
                }

                !makeExecutable && userId !in record.activeUserIds -> {
                    LockedResult(AccountSlotReplacement(false, "account_slot_not_active"))
                }

                else -> {
                    val activeUserIds = if (makeExecutable) {
                        record.activeUserIds + userId
                    } else {
                        record.activeUserIds - userId
                    }
                    LockedResult(
                        AccountSlotReplacement(
                            replaced = true,
                            removedUserIds = if (makeExecutable) emptyList() else listOf(userId),
                        ),
                        record.copy(
                            migrationState = AccountSlotMigrationState.READY,
                            activeUserIds = activeUserIds,
                        ),
                    )
                }
            }
        } ?: return AccountSlotReplacement(false, "registry_unavailable")

        if (result.replaced && result.removedUserIds.isNotEmpty()) {
            cleanupRemovedSlots(context, result.removedUserIds)
        }
        if (result.replaced) {
            Log.record(
                TAG,
                "account_slot_${if (makeExecutable) "enabled" else "disabled"}: account=${shortHash(userId)}",
            )
        }
        return result
    }

    fun normalizeUserId(rawUserId: String?): String? {
        val userId = rawUserId?.trim().orEmpty()
        if (userId.isEmpty() || userId.length > MAX_USER_ID_LENGTH) return null
        if (userId == "." || userId == ".." || userId.contains("..")) return null
        if (
            userId.any { character ->
                character.isISOControl() ||
                    character == '/' ||
                    character == '\\' ||
                    character == File.pathSeparatorChar
            }
        ) {
            return null
        }
        return userId
    }

    private fun cleanupRemovedSlots(context: android.content.Context?, removedUserIds: Collection<String>) {
        removedUserIds.forEach { userId ->
            PersistentScheduleRegistry.cancelByOwner(context, userId)
            UserDataStoreManager.releaseInstance(userId)
        }
    }

    private fun snapshotFor(record: AccountSlotRecord): AccountSlotSnapshot {
        val configuredUserIds = configuredUserIds()
        val configuredUserIdSet = configuredUserIds.toSet()
        return AccountSlotSnapshot(
            migrationState = record.migrationState,
            activeUserIds = record.activeUserIds,
            candidateUserIds = configuredUserIds,
            orphanedActiveUserIds = record.activeUserIds.filter { it !in configuredUserIdSet },
            pendingRuntimeUserId = record.pendingRuntimeUserId,
        )
    }

    private fun selectableUserIds(): List<String> = configuredUserIds()

    private fun configuredUserIds(): List<String> =
        Files.listExistingUserConfigIds()
            .asSequence()
            .map { userId -> Files.child(Files.CONFIG_DIR, userId) }
            .mapNotNull(::verifiedDirectoryUserId)
            .distinct()
            .sorted()
            .toList()

    private fun verifiedDirectoryUserId(directory: File): String? {
        val directoryUserId = normalizeUserId(directory.name) ?: return null
        val configFile = Files.child(directory, "config_v2.json")
        val selfFile = Files.child(directory, "self.json")
        if (!configFile.isFile || configFile.length() == 0L || !selfFile.isFile || selfFile.length() == 0L) {
            return null
        }
        val snapshotUserId = runCatching {
            JsonUtil.parseObject(Files.readFromFile(selfFile), UserEntity.UserDto::class.java).userId
        }.getOrNull()
        return normalizeUserId(snapshotUserId)?.takeIf { it == directoryUserId }
    }

    private fun hasVerifiedConfiguredUser(userId: String): Boolean =
        verifiedDirectoryUserId(Files.child(Files.CONFIG_DIR, userId)) == userId

    private fun bootstrapRecord(): AccountSlotRecord {
        val candidates = configuredUserIds()
        return when {
            candidates.size <= MAX_EXECUTABLE_ACCOUNT_SLOTS -> AccountSlotRecord(
                migrationState = AccountSlotMigrationState.READY,
                activeUserIds = candidates,
            )

            else -> AccountSlotRecord(
                migrationState = AccountSlotMigrationState.SELECTION_REQUIRED,
            )
        }
    }

    private fun recoverRecord(
        record: AccountSlotRecord,
        recoverExpiredPending: Boolean,
    ): AccountSlotRecord {
        val candidates = if (record.migrationState == AccountSlotMigrationState.SELECTION_REQUIRED) {
            configuredUserIds()
        } else {
            null
        }
        val expiredPendingUserId = record.pendingRuntimeUserId
            ?.takeIf { recoverExpiredPending && isPendingRuntimeSlotExpired(record) }
        val recordWithoutExpiredPending = if (expiredPendingUserId == null) {
            record
        } else {
            record.copy(
                pendingRuntimeUserId = null,
                pendingRuntimeSinceMs = 0L,
            )
        }
        val recovered = when {
            candidates != null && candidates.size <= MAX_EXECUTABLE_ACCOUNT_SLOTS -> {
                recordWithoutExpiredPending.copy(
                    migrationState = AccountSlotMigrationState.READY,
                    activeUserIds = candidates,
                )
            }

            else -> recordWithoutExpiredPending
        }
        if (expiredPendingUserId != null) {
            Log.record(TAG, "account_slot_provision_expired: account=${shortHash(expiredPendingUserId)}")
            Log.w(TAG, "account_slot_provision_expired: account=${shortHash(expiredPendingUserId)}")
        }
        if (recovered != record) {
            Log.record(
                TAG,
                "account_slot_record_recovered: from=${record.migrationState} " +
                    "to=${recovered.migrationState} active=${recovered.activeUserIds.size}",
            )
        }
        return recovered
    }

    private fun isPendingRuntimeSlotExpired(record: AccountSlotRecord): Boolean =
        record.pendingRuntimeUserId != null &&
            System.currentTimeMillis() - record.pendingRuntimeSinceMs >= PENDING_RUNTIME_SLOT_TTL_MS

    private fun validateRecord(record: AccountSlotRecord): AccountSlotRecord? {
        val activeUserIds = record.activeUserIds.mapNotNull(::normalizeUserId)
        if (activeUserIds.size != record.activeUserIds.size || activeUserIds.distinct().size != activeUserIds.size) {
            return null
        }
        val pendingRuntimeUserId = record.pendingRuntimeUserId?.let(::normalizeUserId)
        if (record.pendingRuntimeUserId != null && pendingRuntimeUserId == null) return null
        if (pendingRuntimeUserId == null && record.pendingRuntimeSinceMs != 0L) return null
        if (
            pendingRuntimeUserId != null &&
                (
                    record.pendingRuntimeSinceMs <= 0L ||
                        record.migrationState != AccountSlotMigrationState.READY ||
                        activeUserIds.isNotEmpty()
                )
        ) {
            return null
        }
        if (
            activeUserIds.size +
                (if (pendingRuntimeUserId == null) 0 else 1) > MAX_EXECUTABLE_ACCOUNT_SLOTS
        ) {
            return null
        }
        if (
            record.migrationState == AccountSlotMigrationState.SELECTION_REQUIRED &&
                (activeUserIds.isNotEmpty() || pendingRuntimeUserId != null)
        ) {
            return null
        }
        return record.copy(
            activeUserIds = activeUserIds,
            pendingRuntimeUserId = pendingRuntimeUserId,
            pendingRuntimeSinceMs = if (pendingRuntimeUserId == null) 0L else record.pendingRuntimeSinceMs,
        )
    }

    private fun <T> withLockedRecord(
        recoverExpiredPending: Boolean = true,
        operation: (LoadedRecord) -> LockedResult<T>,
    ): T? = runCatching {
        io.github.aoguai.sesameag.storage.StoreAccess.transaction {
            val configDir = Files.CONFIG_DIR
            check(configDir.isDirectory || configDir.mkdirs()) { "config_dir_unavailable" }
            val loaded = requireNotNull(readLockedRecord(configDir, recoverExpiredPending)) { "registry_read_failed" }
            val result = operation(loaded)
            val record = result.updatedRecord ?: loaded.record.takeIf { loaded.needsWrite }
            if (record != null) check(writeLockedRecord(configDir, record)) { "registry_write_failed" }
            result.value
        }
    }.onFailure { error ->
        if (error is CancellationException) throw error
        logRegistryUnavailable(error)
    }.getOrNull()

    private fun logRegistryUnavailable(error: Throwable) {
        val now = System.currentTimeMillis()
        while (true) {
            val previous = lastRegistryUnavailableLogAtMs.get()
            if (now - previous < REGISTRY_UNAVAILABLE_LOG_INTERVAL_MS) return
            if (lastRegistryUnavailableLogAtMs.compareAndSet(previous, now)) break
        }
        Log.record(
            TAG,
            "account_slot_registry_unavailable: ${error.javaClass.simpleName}:${error.message.orEmpty().take(200)}",
        )
        Log.w(TAG, "account_slot_registry_unavailable: error=${error.javaClass.simpleName}")
    }

    private fun readLockedRecord(
        configDir: File,
        recoverExpiredPending: Boolean,
    ): LoadedRecord? {
        val recordFile = Files.child(configDir, RECORD_FILE_NAME)
        if (!recordFile.exists()) {
            return LoadedRecord(bootstrapRecord(), needsWrite = true)
        }
        val parsedRecord = runCatching {
            JsonUtil.parseObject(Files.readFromFile(recordFile), AccountSlotRecord::class.java)
        }.getOrNull() ?: return null
        val validatedRecord = validateRecord(parsedRecord) ?: return null
        val recoveredRecord = recoverRecord(validatedRecord, recoverExpiredPending)
        return LoadedRecord(recoveredRecord, needsWrite = recoveredRecord != validatedRecord)
    }

    private fun writeLockedRecord(configDir: File, record: AccountSlotRecord): Boolean {
        val canonicalRecord = validateRecord(record) ?: return false
        return Files.writeAtomically(JsonUtil.formatJson(canonicalRecord), Files.child(configDir, RECORD_FILE_NAME))
    }

    internal fun shortHash(value: String): String =
        MessageDigest
            .getInstance("SHA-256")
            .digest(value.toByteArray(Charsets.UTF_8))
            .take(6)
            .joinToString("") { byte -> "%02x".format(byte.toInt() and 0xff) }
}
