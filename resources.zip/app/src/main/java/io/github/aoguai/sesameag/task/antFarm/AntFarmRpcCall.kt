package io.github.aoguai.sesameag.task.antFarm

import io.github.aoguai.sesameag.hook.RequestManager
import io.github.aoguai.sesameag.hook.RequestManager.requestString
import io.github.aoguai.sesameag.task.common.DeferredReason
import io.github.aoguai.sesameag.task.common.TaskFlowActionResult
import io.github.aoguai.sesameag.task.common.TaskRpcFailureType
import io.github.aoguai.sesameag.util.JsonUtil
import io.github.aoguai.sesameag.util.Log
import io.github.aoguai.sesameag.util.ResChecker
import io.github.aoguai.sesameag.util.RandomUtil.nextInt
import io.github.aoguai.sesameag.util.maps.UserMap
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException
import java.util.UUID

object AntFarmRpcCall {
    private const val TAG = "AntFarmRpcCall"
    private const val VERSION = "1.8.2302070202.46"
    private const val GAME_CENTER_VERSION = "10.8.20.8000"
    private const val KITCHEN_TASK_SOURCE = "antfarmzuofanrw"

    internal enum class FamilyInviteVisitOutcome {
        SUBMITTED,
        ALREADY_COMPLETED_CONFIRMED,
        RETRY_LATER,
    }

    /**
     * 进入庄园
     *
     * @param userId       自己的用户id
     * @param targetUserId 所在农场的用户id
     * @return 返回结果
     * @throws JSONException 异常内容
     */
    @JvmStatic
    @Throws(JSONException::class)
    fun enterFarm(
        userId: String?,
        targetUserId: String?,
    ): String {
        val args = JSONObject()
        args.put("animalId", "")
        args.put("bizCode", "")
        args.put("gotoneScene", "")
        args.put("gotoneTemplateId", "")
        args.put("groupId", "")
        args.put("growthExtInfo", "")
        args.put("inviteUserId", "")
        args.put("masterFarmId", "")
        args.put("queryLastRecordNum", true)
        args.put("recall", false)
        args.put("requestType", "NORMAL")
        args.put("sceneCode", "ANTFARM")
        args.put("shareId", "")
        args.put("shareUniqueId", System.currentTimeMillis().toString() + "_" + targetUserId)
        args.put("source", "ANTFOREST")
        args.put("starFarmId", "")
        args.put("subBizCode", "")
        args.put("touchRecordId", "")
        args.put("userId", userId)
        args.put("userToken", "")
        args.put("version", VERSION)
        val paras = "[" + args + "]"
        return requestString("com.alipay.antfarm.enterFarm", paras)
    }

    // 一起拿小鸡饲料
    @JvmStatic
    fun letsGetChickenFeedTogether(): String {
        val args1 =
            "[{\"needHasInviteUserByCycle\":\"true\",\"requestType\":\"RPC\",\"sceneCode\":\"ANTFARM_P2P\",\"source\":\"ANTFARM\",\"startIndex\":0," +
                "\"version\":\"" +
                VERSION +
                "\"}]"
        return requestString("com.alipay.antiep.canInvitePersonListP2P", args1)
    }

    // 赠送饲料
    @JvmStatic
    fun giftOfFeed(
        bizTraceId: String?,
        userId: String?,
    ): String {
        val args1 =
            "[{\"beInvitedUserId\":\"" + userId +
                "\",\"bizTraceId\":\"" + bizTraceId +
                "\",\"requestType\":\"RPC\",\"sceneCode\":\"ANTFARM_P2P\"," +
                "\"source\":\"ANTFARM\",\"version\":\"" + VERSION + "\"}]"
        return requestString("com.alipay.antiep.inviteP2P", args1)
    }

    @JvmStatic
    @Throws(JSONException::class)
    fun syncAnimalStatus(
        farmId: String?,
        operTag: String?,
        operType: String?,
        source: String = "H5",
    ): String {
        val args = JSONObject()
        args.put("farmId", farmId)
        args.put("operTag", operTag)
        args.put("operType", operType)
        args.put("requestType", "NORMAL")
        args.put("sceneCode", "ANTFARM")
        args.put("source", source)
        args.put("version", VERSION)
        val params = "[" + args + "]"
        return requestString("com.alipay.antfarm.syncAnimalStatus", params)
    }

    @JvmStatic
    fun sleep(): String {
        val args1 =
            "[{\"requestType\":\"RPC\",\"sceneCode\":\"ANTFARM\",\"source\":\"LOVECABIN\",\"version\":\"unknown\"}]"
        return requestString("com.alipay.antfarm.sleep", args1)
    }

    /**
     * 家庭睡觉
     *
     * @param groupId 家庭ID
     * @return 返回结果
     */
    @JvmStatic
    fun sleep(groupId: String): String {
        val args1 =
            "[{\"groupId\":\"$groupId\",\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\",\"spaceType\":\"ChickFamily\", \"version\":\"unknown\"}]"
        return requestString("com.alipay.antfarm.sleep", args1)
    }

    @JvmStatic
    fun wakeUp(): String {
        val args1 =
            "[{\"requestType\":\"RPC\",\"sceneCode\":\"ANTFARM\",\"source\":\"LOVECABIN\",\"version\":\"unknown\"}]"
        return requestString("com.alipay.antfarm.wakeUp", args1)
    }

    @JvmStatic
    fun queryLoveCabin(userId: String?): String {
        val args1 =
            "[{\"requestType\":\"RPC\",\"sceneCode\":\"ANTFARM\",\"source\":\"LOVECABIN\",\"userId\":\"" +
                userId + "\"}]"
        return requestString("com.alipay.antfarm.queryLoveCabin", args1)
    }

    @JvmStatic
    fun rewardFriend(
        consistencyKey: String?,
        friendId: String?,
        productNum: String?,
        time: String?,
    ): String {
        val args1 = (
            "[{\"canMock\":true,\"consistencyKey\":\"" + consistencyKey +
                "\",\"friendId\":\"" + friendId + "\",\"operType\":\"1\",\"productNum\":" + productNum +
                ",\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\",\"time\":" +
                time + ",\"version\":\"" + VERSION + "\"}]"
        )
        return requestString("com.alipay.antfarm.rewardFriend", args1)
    }

    @JvmStatic
    fun recallAnimal(
        animalId: String?,
        currentFarmId: String?,
        masterFarmId: String?,
    ): String {
        val args1 = (
            "[{\"animalId\":\"" + animalId + "\",\"currentFarmId\":\"" +
                currentFarmId + "\",\"masterFarmId\":\"" + masterFarmId +
                "\",\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\",\"version\":\"" +
                VERSION + "\"}]"
        )
        return requestString("com.alipay.antfarm.recallAnimal", args1)
    }

    @JvmStatic
    fun orchardRecallAnimal(
        animalId: String?,
        userId: String?,
    ): String {
        val args1 =
            "[{\"animalId\":\"" + animalId + "\",\"orchardUserId\":\"" + userId +
                "\",\"requestType\":\"NORMAL\",\"sceneCode\":\"ORCHARD\",\"source\":\"zhuangyuan_zhaohuixiaoji\",\"version\":\"0.1.2403061630.6\"}]"
        return requestString("com.alipay.antorchard.recallAnimal", args1)
    }

    @JvmStatic
    fun sendBackAnimal(
        sendType: String?,
        animalId: String?,
        currentFarmId: String?,
        masterFarmId: String?,
    ): String {
        val args1 = (
            "[{\"animalId\":\"" + animalId + "\",\"currentFarmId\":\"" +
                currentFarmId + "\",\"masterFarmId\":\"" + masterFarmId +
                "\",\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"sendType\":\"" +
                sendType + "\",\"source\":\"H5\",\"version\":\"" +
                VERSION + "\"}]"
        )
        return requestString("com.alipay.antfarm.sendBackAnimal", args1)
    }

    @JvmStatic
    fun harvestProduce(farmId: String?): String {
        val args1 = (
            "[{\"canMock\":true,\"farmId\":\"" + farmId +
                "\",\"giftType\":\"\",\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\",\"version\":\"" +
                VERSION + "\"}]"
        )
        return requestString("com.alipay.antfarm.harvestProduce", args1)
    }

    @JvmStatic
    fun listActivityInfo(): String {
        val args1 =
            (
                "[{\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\",\"version\":\"" +
                    VERSION + "\"}]"
            )
        return requestString("com.alipay.antfarm.listActivityInfo", args1)
    }

    @JvmStatic
    fun donation(
        activityId: String?,
        donationAmount: Int,
        projectId: String? = null,
        batchId: String? = null,
        targetId: String? = null,
    ): String {
        val hasStructuredTarget =
            !projectId.isNullOrBlank() && !batchId.isNullOrBlank() && !targetId.isNullOrBlank()
        val args = JSONObject().apply {
            put("activityId", activityId)
            put("donationAmount", donationAmount)
            put("requestType", "NORMAL")
            put("sceneCode", "ANTFARM")
            put("source", if (hasStructuredTarget) "ANTFARM" else "H5")
            put("version", if (hasStructuredTarget) GAME_CENTER_VERSION else VERSION)
            if (hasStructuredTarget) {
                put("batchId", batchId)
                put("businessCoinType", "BENE_SCORE")
                put("cele", 1)
                put("projectId", projectId)
                put("targetId", targetId)
            }
        }
        return requestString("com.alipay.antfarm.donation", JSONArray().put(args).toString())
    }

    @JvmStatic
    fun donationToLoveChickenProject(
        projectId: String,
        donationAmount: Int,
    ): String {
        val args = JSONObject().apply {
            put("cele", 1)
            put("donationAmount", donationAmount)
            put("projectId", projectId)
            put("requestType", "NORMAL")
            put("sceneCode", "ANTFARM")
            put("source", "H5")
            put("version", VERSION)
        }
        return requestString("com.alipay.antfarm.donation", JSONArray().put(args).toString())
    }

    @JvmStatic
    fun listFarmTask(taskSceneCode: String = "ANTFARM_FOOD_TASK"): String {
        val args = JSONObject()
            .put("requestType", "NORMAL")
            .put("sceneCode", if (taskSceneCode == "ANTFARM_AI_KITCHEN_TASK") taskSceneCode else "ANTFARM")
            .put("source", "H5")
            .put("taskSceneCode", taskSceneCode)
        if (taskSceneCode != "ANTFARM_AI_KITCHEN_TASK") args.put("version", VERSION)
        return requestString("com.alipay.antfarm.listFarmTask", JSONArray().put(args).toString())
    }

    /**
     * 完成普通任务（无广告）
     *
     * @param taskType 任务类型
     * @param sceneCode 场景代码
     * @param outBizNo 外部业务号
     * @return 返回结果JSON字符串
     * @throws JSONException JSON异常
     */
    @JvmStatic
    @Throws(JSONException::class)
    fun finishTask(
        taskType: String,
        sceneCode: String,
        outBizNo: String,
    ): String {
        val aiKitchen = sceneCode == "ANTFARM_AI_KITCHEN_TASK"
        val args = JSONObject()
        args.put("outBizNo", outBizNo)
        args.put("requestType", if (aiKitchen) "NORMAL" else "RPC")
        args.put("sceneCode", sceneCode)
        args.put("source", if (aiKitchen) "aikitchen_daily" else "ADBASICLIB")
        args.put("taskType", taskType)
        if (aiKitchen) {
            args.put("bizKey", taskType)
            args.put("taskSceneCode", sceneCode)
            args.put("userId", UserMap.currentUid)
        }
        val method = if (aiKitchen) "com.alipay.antieptask.finishTaskantfarm" else "com.alipay.antiep.finishTask"
        return requestString(method, JSONArray().put(args).toString())
    }

    @JvmStatic
    fun FlyGameListFarmTask(): String {
        val args =
            "[{" +
                "\"bizKey\":\"SHANGYEHUA_GAME_TIMES\"," +
                "\"gameType\":\"flyGame\"," +
                "\"requestType\":\"RPC\"," +
                "\"sceneCode\":\"FLAYGAME\"," +
                "\"signSceneCode\":\"\"," +
                "\"source\":\"ANTFARM\"," +
                "\"taskSceneCode\":\"ANTFARM_GAME_TIMES_TASK\"," +
                "\"version\":\"\"" +
                "}]"
        return requestString("com.alipay.antfarm.listFarmTask", args)
    }

    @JvmStatic
    fun HitGameListFarmTask(): String {
        val args =
            "[{" +
                "\"bizKey\":\"SHANGYEHUA_HIT_ANIMAL\"," +
                "\"gameType\":\"hitGame\"," +
                "\"requestType\":\"RPC\"," +
                "\"sceneCode\":\"HITGAME\"," +
                "\"signSceneCode\":\"\"," +
                "\"source\":\"ANTFARM\"," +
                "\"taskSceneCode\":\"ANTFARM_GAME_TIMES_TASK\"," +
                "\"version\":\"\"" +
                "}]"
        return requestString("com.alipay.antfarm.listFarmTask", args)
    }

    @JvmStatic
    fun receiveFarmTaskAward(
        taskId: String,
        awardType: String? = null,
    ): String {
        val args = JSONObject()
        args.put("requestType", "NORMAL")
        args.put("sceneCode", "ANTFARM")
        args.put("source", "H5")
        args.put("taskId", taskId)
        args.put("version", VERSION)
        if (!awardType.isNullOrBlank()) {
            args.put("awardType", awardType)
        }
        return requestString("com.alipay.antfarm.receiveFarmTaskAward", JSONArray().put(args).toString())
    }

    @JvmStatic
    fun listToolTaskDetails(): String {
        val args1 =
            (
                "[{\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\",\"version\":\"" +
                    VERSION + "\"}]"
            )
        return requestString("com.alipay.antfarm.listToolTaskDetails", args1)
    }

    @JvmStatic
    fun receiveToolTaskReward(
        rewardType: String?,
        rewardCount: Int,
        taskType: String?,
    ): String {
        val args1 =
            (
                "[{\"ignoreLimit\":false,\"requestType\":\"NORMAL\",\"rewardCount\":" + rewardCount +
                    ",\"rewardType\":\"" + rewardType + "\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\",\"taskType\":\"" +
                    taskType + "\",\"version\":\"" + VERSION + "\"}]"
            )
        return requestString("com.alipay.antfarm.receiveToolTaskReward", args1)
    }

    @JvmStatic
    @Throws(JSONException::class)
    fun feedAnimal(farmId: String?): String {
        val args = JSONObject()
        args.put("animalType", "CHICK")
        args.put("canMock", true)
        args.put("farmId", farmId)
        args.put("requestType", "NORMAL")
        args.put("sceneCode", "ANTFARM")
        args.put("source", "chInfo_ch_appcollect__chsub_my-recentlyUsed")
        args.put("version", VERSION)
        val params = "[" + args + "]"
        return requestString("com.alipay.antfarm.feedAnimal", params)
    }

    @JvmStatic
    fun listFarmTool(): String {
        val args1 =
            "[{\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\",\"version\":\"" + VERSION + "\"}]"
        return requestString("com.alipay.antfarm.listFarmTool", args1)
    }

    @JvmStatic
    fun useFarmTool(
        targetFarmId: String?,
        toolId: String?,
        toolType: String?,
        achievementId: String? = null,
        dollId: String? = null,
    ): String {
        // 数字公仔补签卡使用时需指定补签目标
        val supplementArgs =
            if (!achievementId.isNullOrEmpty() && !dollId.isNullOrEmpty()) {
                ",\"achievementId\":\"$achievementId\",\"dollId\":\"$dollId\""
            } else {
                ""
            }
        val args1 =
            (
                "[{\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\",\"targetFarmId\":\"" +
                    targetFarmId + "\",\"toolId\":\"" + toolId + "\",\"toolType\":\"" + toolType + "\"" + supplementArgs +
                    ",\"version\":\"" +
                    VERSION + "\"}]"
            )
        return requestString("com.alipay.antfarm.useFarmTool", args1)
    }

    /** 查询指定数字公仔的获得状态，响应含 dollInfoVO(acquired/achievementId) 与 dollTool 补签卡库存 */
    @JvmStatic
    fun queryAntfarmDoll(dollId: String?): String {
        val args1 =
            (
                "[{\"dollId\":\"" + dollId + "\",\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\",\"version\":\"" +
                    VERSION + "\"}]"
            )
        return requestString("com.alipay.antfarm.queryAntfarmDoll", args1)
    }

    @JvmStatic
    fun rankingList(pageStartSum: Int): String {
        val args1 =
            (
                "[{\"pageSize\":20,\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\",\"startNum\":" +
                    pageStartSum + ",\"version\":\"" + VERSION + "\"}]"
            )
        return requestString("com.alipay.antfarm.rankingList", args1)
    }

    @JvmStatic
    fun notifyFriend(
        animalId: String?,
        notifiedFarmId: String?,
    ): String {
        val args1 = (
            "[{\"animalId\":\"" + animalId +
                "\",\"animalType\":\"CHICK\",\"canBeGuest\":true,\"notifiedFarmId\":\"" + notifiedFarmId +
                "\",\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\",\"version\":\"" +
                VERSION + "\"}]"
        )
        return requestString("com.alipay.antfarm.notifyFriend", args1)
    }

    @JvmStatic
    @Throws(JSONException::class)
    fun feedFriendAnimal(friendFarmId: String?): String {
        val args = JSONObject()
        args.put("friendFarmId", friendFarmId)
        args.put("requestType", "NORMAL")
        args.put("sceneCode", "ANTFARM")
        args.put("source", "chInfo_ch_appcenter__chsub_9patch")
        args.put("version", VERSION)
        val params = "[" + args + "]"

        return requestString("com.alipay.antfarm.feedFriendAnimal", params)
    }

    @JvmStatic
    fun farmId2UserId(farmId: String?): String? {
        if (farmId == null) return null
        val l = farmId.length / 2
        return farmId.substring(l)
    }

    /**
     * 收集肥料
     *
     * @param manurePotNO 肥料袋号
     * @return 返回结果
     */
    @JvmStatic
    fun collectManurePot(manurePotNO: String?): String {
//        "isSkipTempLimit":true, 肥料满了也强行收取，解决 农场未开通 打扫鸡屎失败问题
        return requestString(
            "com.alipay.antfarm.collectManurePot",
            (
                "[{\"isSkipTempLimit\":true,\"manurePotNOs\":\"" + manurePotNO +
                    "\",\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\",\"version\":\"" + VERSION +
                    "\"}]"
            ),
        )
    }

    @JvmStatic
    fun sign(): String =
        requestString(
            "com.alipay.antfarm.sign",
            "[{\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\",\"version\":\"" + VERSION + "\"}]",
        )

    @JvmStatic
    fun initFarmGame(gameType: String?): String {
        if ("flyGame" == gameType) {
            return requestString(
                "com.alipay.antfarm.initFarmGame",
                "[{\"gameType\":\"flyGame\",\"requestType\":\"RPC\",\"sceneCode\":\"FLAYGAME\"," +
                    "\"source\":\"FARM_game_yundongfly\",\"toolTypes\":\"ACCELERATETOOL,SHARETOOL,NONE\",\"version\":\"\"}]",
            )
        }
        return requestString(
            "com.alipay.antfarm.initFarmGame",
            (
                "[{\"gameType\":\"" + gameType +
                    "\",\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\",\"toolTypes\":\"STEALTOOL,ACCELERATETOOL,SHARETOOL\"}]"
            ),
        )
    }

    private fun randomScore(str: String?): Int {
        if ("starGame" == str) {
            return nextInt(300, 400)
        } else if ("jumpGame" == str) {
            return nextInt(250, 270) * 10
        } else if ("flyGame" == str) {
            return nextInt(4500, 7450)
        } else if ("hitGame" == str) {
            return nextInt(80, 120)
        } else {
            return 210
        }
    }

    @JvmStatic
    fun recordFarmGame(gameType: String?): String {
        val uuid: String = uuid
        val md5String = getMD5(uuid)
        val score = randomScore(gameType)
        if ("flyGame" == gameType) {
            val foodCount = score / 50
            return requestString(
                "com.alipay.antfarm.recordFarmGame",
                (
                    "[{\"foodCount\":" + foodCount + ",\"gameType\":\"flyGame\",\"md5\":\"" + md5String +
                        "\",\"requestType\":\"RPC\",\"sceneCode\":\"FLAYGAME\",\"score\":" + score +
                        ",\"source\":\"ANTFARM\",\"toolTypes\":\"ACCELERATETOOL,SHARETOOL,NONE\",\"uuid\":\"" + uuid +
                        "\",\"version\":\"\"}]"
                ),
            )
        }
        return requestString(
            "com.alipay.antfarm.recordFarmGame",
            (
                "[{\"gameType\":\"" + gameType + "\",\"md5\":\"" + md5String +
                    "\",\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"score\":" + score +
                    ",\"source\":\"H5\",\"toolTypes\":\"STEALTOOL,ACCELERATETOOL,SHARETOOL\",\"uuid\":\"" + uuid +
                    "\"}]"
            ),
        )
    }

    private val uuid: String
        get() {
            val sb = StringBuilder()
            for (str in UUID
                .randomUUID()
                .toString()
                .split("-".toRegex())
                .dropLastWhile { it.isEmpty() }
                .toTypedArray()) {
                sb.append(str.substring(str.length / 2))
            }
            return sb.toString()
        }

    private fun getMD5(password: String): String {
        try {
            // 得到一个信息摘要器
            val digest = MessageDigest.getInstance("md5")
            val result = digest.digest(password.toByteArray())
            val buffer = StringBuilder()
            // 把没一个byte 做一个与运算 0xff;
            for (b in result) {
                // 与运算
                val number = b.toInt() and 0xff // 加盐
                val str = Integer.toHexString(number)
                if (str.length == 1) {
                    buffer.append("0")
                }
                buffer.append(str)
            }
            // 标准的md5加密后的结果
            return buffer.toString()
        } catch (e: NoSuchAlgorithmException) {
            Log.printStackTrace(TAG, e)
            return ""
        }
    }

    /**
     * 小鸡厨房 - 进厨房
     *
     * @param userId 用户id
     * @return 返回结果
     * @throws JSONException 异常
     */
    @JvmStatic
    @Throws(JSONException::class)
    fun enterKitchen(userId: String?): String {
        val args = JSONObject()
        args.put("requestType", "RPC")
        args.put("sceneCode", "ANTFARM")
        args.put("source", KITCHEN_TASK_SOURCE)
        args.put("userId", userId)
        args.put("version", "unknown")
        val params = "[" + args + "]"
        return requestString("com.alipay.antfarm.enterKitchen", params)
    }

    @JvmStatic
    fun collectDailyFoodMaterial(dailyFoodMaterialAmount: Int): String =
        requestString(
            "com.alipay.antfarm.collectDailyFoodMaterial",
            "[{\"collectDailyFoodMaterialAmount\":" + dailyFoodMaterialAmount +
                ",\"requestType\":\"RPC\",\"sceneCode\":\"ANTFARM\",\"source\":\"" +
                KITCHEN_TASK_SOURCE +
                "\",\"version\":\"unknown\"}]",
        )

    @JvmStatic
    fun queryFoodMaterialPack(): String =
        requestString(
            "com.alipay.antfarm.queryFoodMaterialPack",
            "[{\"requestType\":\"RPC\",\"sceneCode\":\"ANTFARM\",\"source\":\"kitchen\",\"version\":\"unknown\"}]",
        )

    @JvmStatic
    fun collectDailyLimitedFoodMaterial(dailyLimitedFoodMaterialAmount: Int): String =
        requestString(
            "com.alipay.antfarm.collectDailyLimitedFoodMaterial",
            (
                "[{\"collectDailyLimitedFoodMaterialAmount\":" + dailyLimitedFoodMaterialAmount +
                    ",\"requestType\":\"RPC\",\"sceneCode\":\"ANTFARM\",\"source\":\"kitchen\",\"version\":\"unknown\"}]"
            ),
        )

    @JvmStatic
    fun farmFoodMaterialCollect(): String =
        requestString(
            "com.alipay.antorchard.farmFoodMaterialCollect",
            "[{\"collect\":true,\"requestType\":\"RPC\",\"sceneCode\":\"ORCHARD\",\"source\":\"" + KITCHEN_TASK_SOURCE +
                "\",\"version\":\"unknown\"}]",
        )

    /**
     * 小鸡厨房 - 做菜
     *
     * @param userId
     * @return
     * @throws JSONException
     */
    @JvmStatic
    @Throws(JSONException::class)
    fun cook(userId: String?): String {
// [{"requestType":"RPC","sceneCode":"ANTFARM","source":"antfarmzuofanrw","userId":"2088522730162798","version":"unknown"}]
        val args = JSONObject()
        args.put("requestType", "RPC")
        args.put("sceneCode", "ANTFARM")
        args.put("source", KITCHEN_TASK_SOURCE)
        args.put("userId", userId)
        args.put("version", "unknown")
        val params = "[" + args + "]"
        return requestString("com.alipay.antfarm.cook", params)
    }

    @JvmStatic
    fun useFarmFood(cuisineList: JSONArray?): String {
        try {
            val args =
                JSONObject().apply {
                    put("cuisineList", cuisineList ?: JSONArray())
                    put("requestType", "NORMAL")
                    put("sceneCode", "ANTFARM")
                    put("source", "chInfo_ch_appcenter__chsub_9patch")
                    put("version", VERSION)
                }
            val params = "[$args]"
            return requestString("com.alipay.antfarm.useFarmFood", params)
        } catch (_: JSONException) {
            return ""
        }
    }

    @JvmStatic
    fun useFarmFood(cookbookId: String, cuisineId: String, cuisineType: String, resultLevel: String): String {
        val args = JSONObject().apply {
            put("cookbookId", cookbookId)
            put("cuisineId", cuisineId)
            if (cuisineType.isNotEmpty()) put("cuisineType", cuisineType)
            if (resultLevel.isNotEmpty()) put("resultLevel", resultLevel)
            put("requestType", "NORMAL")
            put("sceneCode", "ANTFARM")
            put("source", "chInfo_ch_appcenter__chsub_9patch")
            put("useCuisine", true)
            put("version", VERSION)
        }
        return requestString("com.alipay.antfarm.useFarmFood", JSONArray().put(args).toString())
    }

    @JvmStatic
    fun collectKitchenGarbage(): String =
        requestString(
            "com.alipay.antfarm.collectKitchenGarbage",
            "[{\"requestType\":\"RPC\",\"sceneCode\":\"ANTFARM\",\"source\":\"VILLA\",\"version\":\"unknown\"}]",
        )

    // 日常任务
    @JvmStatic
    @JvmOverloads
    fun doFarmTask(
        bizKey: String?, taskSceneCode: String? = null, requestType: String = "NORMAL",
        sceneCode: String = "ANTFARM", source: String = "H5",
    ): String =
        requestString(
            "com.alipay.antfarm.doFarmTask",
            JSONArray().put(JSONObject().apply {
                put("bizKey", bizKey)
                put("requestType", requestType)
                put("sceneCode", sceneCode)
                put("source", source)
                put("version", VERSION)
                if (!taskSceneCode.isNullOrBlank()) put("taskSceneCode", taskSceneCode)
            }).toString(),
        )

    fun doSceneTask(
        bizKey: String,
        taskSceneCode: String,
        originalFailure: TaskFlowActionResult,
        sceneCode: String,
        source: String,
        onFailure: (JSONObject) -> TaskFlowActionResult,
    ): TaskFlowActionResult {
        val rpc = "AntFarmRpcCall.doFarmTask"
        val originalDetail = "originalRpc=${originalFailure.rpc} originalCode=${originalFailure.code} originalRaw=${originalFailure.raw}"
        val raw = doFarmTask(bizKey, taskSceneCode, "RPC", sceneCode, source)
        val response = JsonUtil.parseJSONObjectOrNull(raw) ?: return TaskFlowActionResult.failure(
            TaskRpcFailureType.RETRYABLE_RPC,
            message = "场景任务请求返回空或无法解析",
            rpc = rpc,
            raw = raw,
            detail = originalDetail,
            continueCurrentRoundOnFailure = true,
        ).copy(refreshAfterAction = true)
        if (!ResChecker.checkRes(TAG, response)) {
            val failure = onFailure(response).copy(
                rpc = rpc, raw = raw, refreshAfterAction = true, detail = originalDetail,
            )
            if (failure.code == "1009" || failure.code == "331") {
                return failure.copy(failureType = TaskRpcFailureType.BUSINESS_LIMIT)
            }
            if (failure.code == "400000040") {
                return failure.copy(
                    failureType = TaskRpcFailureType.NON_RETRYABLE_INVALID,
                    continueCurrentRoundOnFailure = true,
                    stopCurrentRound = false,
                )
            }
            // 保留失败语义；后续列表确认进展时由统一任务执行流程消解失败。
            return failure
        }
        return TaskFlowActionResult.defer(
            DeferredReason.STATE_CONFIRMATION,
            message = "场景任务已受理，等待所属任务列表确认",
            rpc = rpc,
            raw = raw,
            detail = "$originalDetail sceneCode=$sceneCode source=$source taskSceneCode=$taskSceneCode bizKey=$bizKey",
            refreshAfterAction = true,
        )
    }

    @JvmStatic
    fun queryTabVideoUrl(): String =
        requestString(
            "com.alipay.antfarm.queryTabVideoUrl",
            (
                "[{\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\",\"version\":\"" + VERSION +
                    "\"}]"
            ),
        )

    @JvmStatic
    fun videoDeliverModule(bizId: String?): String =
        requestString(
            "alipay.content.reading.life.deliver.module",
            (
                "[{\"bizId\":\"" + bizId +
                    "\",\"bizType\":\"CONTENT\",\"chInfo\":\"ch_antFarm\",\"refer\":\"antFarm\",\"timestamp\":\"" +
                    System.currentTimeMillis() + "\"}]"
            ),
        )

    @JvmStatic
    fun videoTrigger(bizId: String?): String =
        requestString(
            "alipay.content.reading.life.prize.trigger",
            (
                "[{\"bizId\":\"" + bizId +
                    "\",\"bizType\":\"CONTENT\",\"prizeFlowNum\":\"VIDEO_TASK\",\"prizeType\":\"farmFeed\"}]"
            ),
        )

    // 惊喜礼包
    @JvmStatic
    fun drawLotteryPlus(): String =
        requestString(
            "com.alipay.antfarm.drawLotteryPlus",
            "[{\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5 \",\"version\":\"\"}]",
        )

    // 小麦
    @JvmStatic
    fun acceptGift(): String =
        requestString(
            "com.alipay.antfarm.acceptGift",
            (
                "[{\"ignoreLimit\":false,\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\",\"version\":\"" +
                    VERSION + "\"}]"
            ),
        )

    @JvmStatic
    fun visitFriend(friendFarmId: String?): String =
        requestString(
            "com.alipay.antfarm.visitFriend",
            (
                "[{\"friendFarmId\":\"" + friendFarmId +
                    "\",\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\",\"version\":\"" +
                    VERSION + "\"}]"
            ),
        )

    /**
     * 小鸡日志当月日期查询
     *
     * @return
     */
    @JvmStatic
    fun queryChickenDiaryList(): String =
        requestString(
            "com.alipay.antfarm.queryChickenDiaryList",
            "[{\"requestType\":\"NORMAL\",\"sceneCode\":\"DIARY\",\"source\":\"antfarm_icon\"}]",
        )

    /**
     * 小鸡日志指定月份日期查询
     *
     * @param yearMonth 日期格式：yyyy-MM
     * @return
     */
    @JvmStatic
    fun queryChickenDiaryList(yearMonth: String?): String =
        requestString(
            "com.alipay.antfarm.queryChickenDiaryList",
            "[{\"queryMonthStr\":\"" + yearMonth + "\",\"requestType\":\"NORMAL\",\"sceneCode\":\"DIARY\",\"source\":\"antfarm_icon\"}]",
        )

    @JvmStatic
    fun queryChickenDiary(queryDayStr: String?): String =
        requestString(
            "com.alipay.antfarm.queryChickenDiary",
            (
                "[{\"queryDayStr\":\"" + queryDayStr +
                    "\",\"requestType\":\"NORMAL\",\"sceneCode\":\"DIARY\",\"source\":\"antfarm_icon\"}]"
            ),
        )

    @JvmStatic
    fun diaryTietie(
        diaryDate: String?,
        roleId: String?,
    ): String =
        requestString(
            "com.alipay.antfarm.diaryTietie",
            (
                "[{\"diaryDate\":\"" + diaryDate + "\",\"requestType\":\"NORMAL\",\"roleId\":\"" + roleId +
                    "\",\"sceneCode\":\"DIARY\",\"source\":\"antfarm_icon\"}]"
            ),
        )

    /**
     * 小鸡日记点赞
     *
     * @param DiaryId 日记id
     * @return
     */
    @JvmStatic
    fun collectChickenDiary(DiaryId: String?): String =
        requestString(
            "com.alipay.antfarm.collectChickenDiary",
            "[{\"collectStatus\":true,\"diaryId\":\"" + DiaryId + "\",\"requestType\":\"NORMAL\",\"sceneCode\":\"MOOD\",\"source\":\"H5\"}]",
        )

    @JvmStatic
    fun visitAnimal(): String =
        requestString(
            "com.alipay.antfarm.visitAnimal",
            "[{\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\",\"version\":\"" + VERSION +
                "\"}]",
        )

    @JvmStatic
    fun feedFriendAnimalVisit(friendFarmId: String?): String =
        requestString(
            "com.alipay.antfarm.feedFriendAnimal",
            "[{\"friendFarmId\":\"" + friendFarmId + "\",\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\"," +
                "\"source\":\"visitChicken\",\"version\":\"" + VERSION + "\"}]",
        )

    @JvmStatic
    fun visitAnimalSendPrize(token: String?): String =
        requestString(
            "com.alipay.antfarm.visitAnimalSendPrize",
            "[{\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\",\"token\":\"" + token +
                "\",\"version\":\"" + VERSION + "\"}]",
        )

    // 抽抽乐
    @JvmStatic
    fun enterDrawMachine(): String =
        requestString(
            "com.alipay.antfarm.enterDrawMachine",
            "[{\"requestType\":\"RPC\",\"sceneCode\":\"ANTFARM\",\"source\":\"siliaorenwu\"}]",
        )

    @JvmStatic
    fun refinedOperation(
        actionId: String,
        source: String = "H5",
        requestType: String = "NORMAL",
    ): String {
        val args = JSONObject()
        args.put("actionId", actionId)
        args.put("requestType", requestType)
        args.put("sceneCode", "ANTFARM")
        args.put("source", source)
        args.put("version", VERSION)
        return requestString("com.alipay.antfarm.refinedOperation", JSONArray().put(args).toString())
    }

    /**
     * 抽抽乐-抽奖类型选择器
     *
     * @param drawType 抽奖类型 ipDraw-对应IP抽奖
     * @return ""
     */
    private fun chouchouleSelector(drawType: String): String {
        if (drawType == "ipDraw") {
            return "ANTFARM_IP_DRAW_TASK"
        }
        // 日常抽抽乐任务场景
        return "ANTFARM_DAILY_DRAW_TASK"
    }

    /**
     * 查询抽抽乐任务列表
     *
     * @param drawType 抽奖类型
     * @return 返回结果
     * @throws JSONException 异常
     */
    @JvmStatic
    @Throws(JSONException::class)
    fun chouchouleListFarmTask(drawType: String): String {
        val taskSceneCode = chouchouleSelector(drawType)
        val args = JSONObject()
        args.put("requestType", "NORMAL")
        args.put("sceneCode", "ANTFARM")
        args.put("source", "H5")
        args.put("taskSceneCode", taskSceneCode)
        args.put("topTask", "")
        val params = "[" + args + "]"
        return requestString("com.alipay.antfarm.listFarmTask", params)
    }

    /**
     * 执行抽抽乐任务
     *
     * @param drawType 抽奖类型
     * @param bizKey   任务ID
     * @return 返回结果
     * @throws JSONException 异常
     */
    @JvmStatic
    @Throws(JSONException::class)
    fun chouchouleDoFarmTask(
        drawType: String,
        bizKey: String?,
    ): String {
        val taskSceneCode = chouchouleSelector(drawType)
        val args = JSONObject()
        args.put("bizKey", bizKey)
        args.put("requestType", "RPC")
        args.put("sceneCode", "ANTFARM")
        args.put("source", "antfarm_villa")
        args.put("taskSceneCode", taskSceneCode)
        val params = "[" + args + "]"
        return requestString("com.alipay.antfarm.doFarmTask", params)
    }

    /**
     * 领取抽抽乐任务奖励-抽奖次数
     *
     * @param drawType 抽奖类型
     * @param taskId   任务ID
     * @return 返回结果
     * @throws JSONException 异常
     */
    @JvmStatic
    @Throws(JSONException::class)
    fun chouchouleReceiveFarmTaskAward(
        drawType: String,
        taskId: String?,
        awardType: String? = null,
    ): String {
        val taskSceneCode = chouchouleSelector(drawType)
        val args = JSONObject()
        args.put("requestType", "RPC")
        args.put("sceneCode", "ANTFARM")
        args.put("source", "antfarm_villa")
        args.put("taskId", taskId)
        args.put("taskSceneCode", taskSceneCode)
        if (!awardType.isNullOrBlank()) {
            args.put("awardType", awardType)
        }
        val params = "[" + args + "]"
        return requestString("com.alipay.antfarm.receiveFarmTaskAward", params)
    }

    /**
     * IP抽抽乐查询活动与抽奖次数
     */
    @JvmStatic
    fun queryDrawMachineActivity(): String =
        requestString(
            "com.alipay.antfarm.queryDrawMachineActivity",
            "[{\"otherScenes\":[\"dailyDrawMachine\"],\"requestType\":\"RPC\",\"scene\":\"ipDrawMachine\",\"sceneCode\":\"ANTFARM\",\"source\":\"ip_ccl\"}]",
        )

    /**
     * 查询抽抽乐活动详情（新版统一接口）
     *
     * @param scene 主场景 "dailyDrawMachine" 或 "ipDrawMachine"
     * @param otherScene 其他场景
     */
    @JvmStatic
    fun queryDrawMachineActivity_New(
        scene: String,
        otherScene: String,
        source: String = "antfarm_villa",
    ): String =
        requestString(
            "com.alipay.antfarm.queryDrawMachineActivity",
            "[{\"otherScenes\":[\"$otherScene\"],\"requestType\":\"RPC\",\"scene\":\"$scene\",\"sceneCode\":\"ANTFARM\",\"source\":\"$source\"}]",
        )

    /**
     * IP抽抽乐抽奖
     */
    @JvmStatic
    fun drawMachine(): String =
        requestString(
            "com.alipay.antfarm.drawMachine",
            "[{\"requestType\":\"RPC\",\"scene\":\"ipDrawMachine\",\"sceneCode\":\"ANTFARM\",\"source\":\"ip_ccl\"}]",
        )

    /**
     * 执行抽奖（IP抽抽乐）- 支持连抽
     */
    @JvmStatic
    fun drawMachineIP(batchDrawTimes: Int): String {
        val data = "[{\"batchDrawTimes\":$batchDrawTimes,\"requestType\":\"RPC\",\"scene\":\"ipDrawMachine\",\"sceneCode\":\"ANTFARM\",\"source\":\"antfarm_villa\"}]"
        return requestString("com.alipay.antfarm.drawMachine", data)
    }

    /**
     * 执行抽奖（普通抽抽乐）- 支持连抽
     */
    @JvmStatic
    fun drawMachineDaily(batchDrawTimes: Int, source: String = "antfarm_villa"): String {
        val data = "[{\"batchDrawTimes\":$batchDrawTimes,\"requestType\":\"RPC\",\"scene\":\"dailyDrawMachine\",\"sceneCode\":\"ANTFARM\",\"source\":\"$source\"}]"
        return requestString("com.alipay.antfarm.drawMachine", data)
    }

    @JvmStatic
    fun adTaskApplayerQuery(renderConfigKey: String): String {
        val args = JSONObject().apply {
            put("spaceCode", renderConfigKey)
        }
        return requestString(
            "com.alipay.adtask.biz.mobilegw.service.applayer.query",
            JSONArray().put(args).toString(),
        )
    }

    @JvmStatic
    fun hireAnimal(
        farmId: String?,
        animalId: String?,
    ): String =
        requestString(
            "com.alipay.antfarm.hireAnimal",
            "[{\"friendFarmId\":\"" + farmId + "\",\"hireActionType\":\"HIRE_IN_FRIEND_FARM\",\"hireAnimalId\":\"" + animalId +
                "\",\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"sendCardChat\":false,\"source\":\"H5\",\"version\":\"" +
                VERSION +
                "\"}]",
        )

    /**
     * 查询“雇佣小鸡拿饲料”任务限定的服务端候选。
     * 该任务的候选和普通好友雇佣并非同一契约，不能复用 friendFarmId/hireAnimalId 请求。
     */
    @JvmStatic
    fun hireAnimalTaskList(): String {
        val args = JSONObject()
        args.put("requestType", "NORMAL")
        args.put("sceneCode", "ANTFARMWORKSHOP")
        args.put("source", "H5")
        return requestString("com.alipay.antfarm.hireAnimalTaskList", JSONArray().put(args).toString())
    }

    /**
     * 雇佣“雇佣小鸡拿饲料”任务下发的候选。
     * 最新闭环使用 friendUserId 和任务标识字段，不携带普通好友雇佣的 farmId/animalId/version。
     */
    @JvmStatic
    fun hireAnimalFromTaskList(friendUserId: String): String {
        val args = JSONObject()
        args.put("friendUserId", friendUserId)
        args.put("hireActionType", "HIRE_IN_FRIEND_FARM")
        args.put("isDoubleReward", true)
        args.put("isFromHireTaskList", true)
        args.put("requestType", "NORMAL")
        args.put("sceneCode", "ANTFARMWORKSHOP")
        args.put("sendCardChat", true)
        args.put("source", "H5")
        return requestString("com.alipay.antfarm.hireAnimal", JSONArray().put(args).toString())
    }

    /**
     * 雇佣NPC小鸡（支持传入source）
     *
     * @param animalId 动物ID
     * @param source 请求来源，如 "zhimaxiaoji_lianjin"
     */
    @JvmStatic
    @Throws(JSONException::class)
    fun hireNpcAnimal(
        animalId: String?,
        source: String?,
    ): String {
        val args = JSONObject()
        args.put("hireActionType", "HIRE_IN_SELF_FARM")
        args.put("hireAnimalId", animalId)
        args.put("isNpcAnimal", true)
        args.put("requestType", "NORMAL")
        args.put("sceneCode", "ANTFARM")
        args.put("source", source)
        args.put("version", VERSION)
        return requestString("com.alipay.antfarm.hireAnimal", "[$args]")
    }

    /**
     * 遣返NPC小鸡（领取奖励）
     */
    @JvmStatic
    @Throws(JSONException::class)
    fun sendBackNpcAnimal(
        animalId: String?,
        currentFarmId: String?,
        masterFarmId: String?,
        receiveNpcReward: Boolean = true,
        source: String = "H5",
    ): String {
        val args = JSONObject()
        args.put("animalId", animalId)
        args.put("currentFarmId", currentFarmId)
        args.put("masterFarmId", masterFarmId)
        args.put("receiveNPCReward", receiveNpcReward)
        args.put("requestType", "NORMAL")
        args.put("sceneCode", "ANTFARM")
        args.put("sendType", "NORMAL")
        args.put("source", source)
        args.put("version", VERSION)
        return requestString("com.alipay.antfarm.sendBackAnimal", "[$args]")
    }

    @JvmStatic
    fun npcVisitAnimal(): String = requestString(
        "com.alipay.antfarm.npcVisitAnimal",
        JSONArray().put(JSONObject().put("requestType", "NORMAL").put("sceneCode", "ANTFARM")
            .put("source", "H5").put("version", VERSION)).toString(),
    )

    @JvmStatic
    fun npcVisitAnimalReport(animalId: String, actionType: String): String = requestString(
        "com.alipay.antfarm.npcVisitAnimalReport",
        JSONArray().put(JSONObject().put("animalId", animalId).put("actionType", actionType)
            .put("reportTime", System.currentTimeMillis()).put("requestType", "NORMAL")
            .put("sceneCode", "ANTFARM").put("source", "H5").put("version", VERSION)).toString(),
    )

    @JvmStatic
    fun listNpcFarmTask(source: String, taskSceneCode: String): String = requestString(
        "com.alipay.antfarm.listFarmTask",
        JSONArray().put(JSONObject().put("requestType", "NORMAL").put("sceneCode", "ANTFARM")
            .put("source", source).put("taskSceneCode", taskSceneCode).put("version", VERSION)).toString(),
    )

    @JvmStatic
    fun receiveNpcFarmTaskAward(
        taskId: String,
        awardType: String,
        source: String,
        taskSceneCode: String,
    ): String {
        val args =
            JSONObject().apply {
                put("awardType", awardType)
                put("requestType", "NORMAL")
                put("sceneCode", "ANTFARM")
                put("source", source)
                put("taskId", taskId)
                put("taskSceneCode", taskSceneCode)
                put("version", VERSION)
            }
        return requestString("com.alipay.antfarm.receiveFarmTaskAward", JSONArray().put(args).toString())
    }

    @JvmStatic
    fun DrawPrize(): String =
        requestString(
            "com.alipay.antfarm.DrawPrize",
            "[{\"requestType\":\"RPC\",\"sceneCode\":\"ANTFARM\",\"source\":\"chouchoule\"}]",
        )

    @JvmStatic
    fun DrawPrize(activityId: String?): String =
        requestString(
            "com.alipay.antfarm.DrawPrize",
            "[{\"activityId\":\"" + activityId + "\",\"requestType\":\"RPC\",\"sceneCode\":\"ANTFARM\",\"source\":\"icon\"}]",
        )

    @JvmStatic
    fun drawGameCenterAward(): String = drawGameCenterAward(1)

    /**
     * 领取蚂蚁庄园游戏中心奖励 (开宝箱)
     *
     * @param drawTimes 开启次数
     */
    @JvmStatic
    fun drawGameCenterAward(drawTimes: Int): String =
        try {
            val args =
                JSONObject().apply {
                    put("batchDrawCount", drawTimes.coerceAtLeast(1))
                    put("bizType", "ANTFARM")
                    put("requestType", "NORMAL")
                    put("sceneCode", "ANTFARM")
                    put("source", "H5")
                    put("version", GAME_CENTER_VERSION)
                }
            requestString(
                "com.alipay.charitygamecenter.drawGameCenterAward",
                JSONArray().put(args).toString(),
            )
        } catch (_: Exception) {
            ""
        }

    @JvmStatic
    fun queryGameList(): String =
        try {
            val args =
                JSONObject().apply {
                    put("bizType", "ANTFARM")
                    put(
                        "commonDegradeFilterRequest",
                        JSONObject().apply {
                            put("deviceLevel", "high")
                            put("platform", "Android")
                            put("unityDeviceLevel", "high")
                        },
                    )
                    put("requestType", "NORMAL")
                    put("sceneCode", "ANTFARM")
                    put("source", "H5")
                    put("version", GAME_CENTER_VERSION)
                }
            requestString(
                "com.alipay.charitygamecenter.queryGameList",
                JSONArray().put(args).toString(),
            )
        } catch (_: Exception) {
            ""
        }

    @JvmStatic
    fun queryOptionalPlay(): String =
        try {
            val args =
                JSONObject().apply {
                    put("bizType", "ANTFARM")
                    put(
                        "commonDegradeFilterRequest",
                        JSONObject().apply {
                            put("appMode", "normal")
                            put("deviceLevel", "high")
                            put("initialized", true)
                            put("platform", "Android")
                            put("unityDeviceLevel", "high")
                        },
                    )
                    put("playTypeList", JSONArray().put("TASK_TRIGGER").put("TOP_UP_COUPON"))
                    put("requestType", "NORMAL")
                    put("sceneCode", "ANTFARM_COMMON")
                    put("source", "H5")
                    put("version", GAME_CENTER_VERSION)
                }
            requestString(
                "com.alipay.charitygamecenter.queryOptionalPlay",
                JSONArray().put(args).toString(),
            )
        } catch (_: Exception) {
            ""
        }

    @JvmStatic
    fun finishLeyuanTask(sceneCode: String, taskType: String): String = requestString(
        "com.alipay.antieptask.finishTaskantfarm",
        JSONArray().put(
            JSONObject()
                .put("outBizNo", taskType + System.currentTimeMillis())
                .put("requestType", "NORMAL")
                .put("sceneCode", sceneCode)
                .put("source", "antfarm")
                .put("taskType", taskType)
                .put("version", GAME_CENTER_VERSION),
        ).toString(),
    )

    @JvmStatic
    fun receiveTaskAwardAntFarm(
        sceneCode: String,
        taskType: String,
        awardCountForReceive: Int,
    ): String =
        try {
            val args =
                JSONObject().apply {
                    put("awardCountForReceive", awardCountForReceive)
                    put("ignoreLimit", true)
                    put("requestType", "RPC")
                    put("sceneCode", sceneCode)
                    put("source", "antfarm")
                    put("taskType", taskType)
                }
            requestString(
                "com.alipay.antieptask.receiveTaskAwardantfarm",
                JSONArray().put(args).toString(),
            )
        } catch (_: Exception) {
            ""
        }

    @JvmStatic
    fun enterAiKitchen(): String = requestString(
        "com.alipay.antfarm.enterAiKitchen",
        JSONArray().put(JSONObject().put("requestType", "RPC").put("sceneCode", "ANTFARM")
            .put("source", "aikitchen_daily")).toString(),
    )

    @JvmStatic
    fun getAiKitchenCookbookInfo(seasonId: String, pageNum: Int): String = requestString(
        "com.alipay.antfarm.getAiKitchenCookbookInfo",
        JSONArray().put(JSONObject().put("pageNum", pageNum).put("sortField", "HIGHEST_SCORE_COOK_TIME")
            .put("seasonId", seasonId).put("requestType", "RPC").put("sceneCode", "ANTFARM")
            .put("source", "H5")).toString(),
    )

    @JvmStatic
    fun queryAiKitchenDishDetail(seasonId: String, dishId: String): String = requestString(
        "com.alipay.antfarm.queryAiKitchenDishDetail",
        JSONArray().put(JSONObject().put("seasonId", seasonId).put("dishId", dishId)
            .put("requestType", "RPC").put("sceneCode", "ANTFARM").put("source", "H5")).toString(),
    )

    @JvmStatic
    fun shareAiKitchenIngredient(
        seasonId: String,
        ingredientId: String,
        receiverId: String,
        requestId: String,
    ): String = requestString(
        "com.alipay.antfarm.shareAiKitchenIngredient",
        JSONArray().put(JSONObject().put("seasonId", seasonId).put("ingredientId", ingredientId)
            .put("receiverId", receiverId).put("requestId", requestId).put("requestType", "RPC")
            .put("sceneCode", "ANTFARM").put("source", "aikitchen_daily")).toString(),
    )

    @JvmStatic
    fun cookAiKitchen(seasonId: String, ingredientIds: List<String>): String = requestString(
        "com.alipay.antfarm.cookAiKitchen",
        JSONArray().put(JSONObject().put("ingredientIds", JSONArray(ingredientIds)).put("seasonId", seasonId)
            .put("requestType", "RPC").put("sceneCode", "ANTFARM").put("source", "aikitchen_daily")).toString(),
    )

    // 小鸡换装
    @JvmStatic
    fun listOrnaments(setsType: String = "ACHIEVEMENTSETS", pageNo: Int = 1): String =
        requestString(
            "com.alipay.antfarm.listOrnaments",
            JSONArray().put(JSONObject()
                .put("pageNo", pageNo.toString())
                .put("requestType", "NORMAL")
                .put("sceneCode", "ANTFARM")
                .put("setsType", setsType)
                .put("source", "H5")
                .put("subType", "sets")
                .put("type", "apparels")
                .put("version", VERSION)).toString(),
        )

    fun ornamentActivityDetail(activityId: String, ornamentId: String): String =
        requestString(
            "com.alipay.antfarm.ornamentActivityDetail",
            JSONArray().put(JSONObject()
                .put("activityId", activityId)
                .put("ornamentId", ornamentId)
                .put("requestType", "NORMAL")
                .put("sceneCode", "ANTFARM")
                .put("source", "H5")
                .put("version", VERSION)).toString(),
        )

    fun completeOrnamentTask(activityId: String, taskId: String): String =
        requestString(
            "com.alipay.antfarm.completeOrnamentTask",
            JSONArray().put(JSONObject()
                .put("activityId", activityId)
                .put("taskId", taskId)
                .put("requestType", "NORMAL")
                .put("sceneCode", "ANTFARM")
                .put("source", "H5")
                .put("version", VERSION)).toString(),
        )

    fun receiveOrnamentTaskAward(taskId: String, completeActivity: Boolean): String =
        requestString(
            "com.alipay.antfarm.receiveUserAward",
            JSONArray().put(JSONObject()
                .put("completeActivity", completeActivity)
                .put("taskId", taskId)
                .put("taskType", "ORNAMENT_TASK")
                .put("requestType", "NORMAL")
                .put("sceneCode", "ANTFARM")
                .put("source", "H5")
                .put("version", VERSION)).toString(),
        )

    @JvmStatic
    fun saveOrnaments(
        animalId: String?,
        farmId: String?,
        ornaments: String?,
    ): String =
        requestString(
            "com.alipay.antfarm.saveOrnaments",
            "[{\"animalId\":\"" + animalId + "\",\"farmId\":\"" + farmId + "\",\"ornaments\":\"" + ornaments +
                "\",\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\",\"version\":\"" +
                VERSION +
                "\"}]",
        )

    // 亲密家庭
    @JvmStatic
    fun enterFamily(): String {
        val args =
            "[{\"fromAnn\":false,\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\",\"timeZoneId\":\"Asia/Shanghai\"}]"
        return requestString("com.alipay.antfarm.enterFamily", args)
    }

    @JvmStatic
    fun queryFamilyInfo(): String {
        val args =
            "[{\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\"}]"
        return requestString("com.alipay.antfarm.queryFamilyInfo", args)
    }

    @JvmStatic
    fun familyTreadMill(): String {
        val args =
            "[{\"openSportsPolicy\":true,\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\",\"timeZoneId\":\"Asia/Shanghai\"}]"
        return requestString("com.alipay.antfarm.familyTreadMill", args)
    }

    /**
     * 家庭任务入口 - 查询当前是否还有「道早安」等家庭任务
     *
     * @param animals enterFamily 接口返回的家庭 animals 数组（原样透传给 RPC）
     */
    @JvmStatic
    fun familyTaskTips(animals: JSONArray): String {
        val args =
            "[{" +
                "\"animals\":$animals," +
                "\"requestType\":\"NORMAL\"," +
                "\"sceneCode\":\"ANTFARM\"," +
                "\"source\":\"H5\"," +
                "\"taskSceneCode\":\"ANTFARM_FAMILY_TASK\"," +
                "\"timeZoneId\":\"Asia/Shanghai\"" +
                "}]"
        return requestString("com.alipay.antfarm.familyTaskTips", args)
    }

    @JvmStatic
    fun listFamilyTask(): String {
        val args =
            "[{\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\",\"timeZoneId\":\"Asia/Shanghai\"}]"
        return requestString("com.alipay.antfarm.listFamilyTask", args)
    }

    @JvmStatic
    fun familyReceiveFarmTaskAward(taskId: String?): String {
        val args =
            "[{\"awardType\":\"FAMILY_INTIMACY\",\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\",\"taskId\":\"" +
                taskId +
                "\",\"taskSceneCode\":\"ANTFARM_FAMILY_TASK\"}]"
        return requestString("com.alipay.antfarm.receiveFarmTaskAward", args)
    }

    @JvmStatic
    fun familyAwardList(): String {
        val args = "[{\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\"}]"
        return requestString("com.alipay.antfarm.familyAwardList", args)
    }

    @JvmStatic
    fun receiveFamilyAward(rightId: String?): String {
        val args =
            "[{\"requestType\":\"NORMAL\",\"rightId\":\"" + rightId + "\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\"}]"
        return requestString("com.alipay.antfarm.receiveFamilyAward", args)
    }

    @JvmStatic
    fun assignFamilyMember(
        assignAction: String?,
        beAssignUser: String?,
    ): String =
        requestString(
            "com.alipay.antfarm.assignFamilyMember",
            "[{\"assignAction\":\"" + assignAction + "\",\"beAssignUser\":\"" + beAssignUser +
                "\",\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\"}]",
        )

    @JvmStatic
    fun sendChat(
        chatCardType: String?,
        receiverUserId: String?,
    ): String =
        requestString(
            "com.alipay.antfarm.sendChat",
            "[{\"chatCardType\":\"" + chatCardType + "\",\"receiverUserId\":\"" + receiverUserId +
                "\",\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\"}]",
        )

    @JvmStatic
    fun deliverSubjectRecommend(friendUserIdList: JSONArray?): String {
        val args =
            "[{\"friendUserIds\":" + friendUserIdList + ",\"requestType\":\"NORMAL\",\"sceneCode\":\"ChickFamily\",\"source\":\"H5\"}]"
        return requestString("com.alipay.antfarm.deliverSubjectRecommend", args)
    }

    @JvmStatic
    @Throws(JSONException::class)
    fun OpenAIPrivatePolicy(): String {
        val args = JSONObject()
        args.put("privatePolicyIdList", JSONArray().put("AI_CHICK_PRIVATE_POLICY"))
        args.put("requestType", "NORMAL")
        args.put("sceneCode", "ANTFARM")
        args.put("source", "H5")
        args.put("version", VERSION)
        val params = "[" + args + "]"
        return requestString("com.alipay.antfarm.OpenPrivatePolicy", params)
    }

    @JvmStatic
    @Throws(JSONException::class)
    fun deliverContentExpand(
        ariverRpcTraceId: String?,
        eventId: String?,
        eventName: String?,
        memo: String?,
        resultCode: String?,
        sceneId: String?,
        sceneName: String?,
        success: Boolean,
        friendUserIdList: JSONArray?,
    ): String {
        val args = JSONObject()
        args.put("ariverRpcTraceId", ariverRpcTraceId)
        args.put("eventId", eventId)
        args.put("eventName", eventName)
        args.put("friendUserIds", friendUserIdList)
        args.put("memo", memo)
        args.put("requestType", "NORMAL")
        args.put("resultCode", resultCode)
        args.put("sceneCode", "ANTFARM")
        args.put("sceneId", sceneId)
        args.put("sceneName", sceneName)
        args.put("source", "H5")
        args.put("success", success)
        val params = "[" + args + "]"
        return requestString("com.alipay.antfarm.DeliverContentExpand", params)
    }

    @JvmStatic
    @Throws(JSONException::class)
    fun QueryExpandContent(deliverId: String?): String {
        val args = JSONObject()
        args.put("requestType", "NORMAL")
        args.put("sceneCode", "ANTFARM")
        args.put("source", "H5")
        args.put("deliverId", deliverId)
        val params = "[" + args + "]"
        return requestString("com.alipay.antfarm.QueryExpandContent", params)
    }

    @JvmStatic
    @Throws(JSONException::class)
    fun deliverMsgSend(
        groupId: String?,
        friendUserIds: JSONArray?,
        content: String?,
        deliverId: String?,
    ): String {
        val args = JSONObject()
        args.put("content", content)
        args.put("deliverId", deliverId)
        args.put("friendUserIds", friendUserIds)
        args.put("groupId", groupId)
        args.put("mode", "AI")
        args.put("requestType", "NORMAL")
        args.put("sceneCode", "ANTFARM")
        args.put("source", "H5")
        args.put("spaceType", "ChickFamily")
        val params = "[" + args + "]"
        return requestString("com.alipay.antfarm.DeliverMsgSend", params)
    }

    @JvmStatic
    fun syncFamilyStatus(
        groupId: String?,
        operType: String?,
        syncUserIds: String?,
    ): String {
        val args =
            "[{\"groupId\":\"" + groupId + "\",\"operType\":\"" + operType +
                "\",\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\",\"syncUserIds\":[\"" +
                syncUserIds +
                "\"]}]"
        return requestString("com.alipay.antfarm.syncFamilyStatus", args)
    }

    @JvmStatic
    fun inviteFriendVisitFamily(receiverUserId: JSONArray?): String {
        val args =
            "[{\"bizType\":\"FAMILY_SHARE\",\"receiverUserId\":" + receiverUserId +
                ",\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\"}]"
        return requestString("com.alipay.antfarm.inviteFriendVisitFamily", args)
    }

    /**
     * FAMILY48 是服务端声明“任务已完成”的业务终态，不能把 success=false 静默当作成功。
     * 仅在随后的家庭任务快照不再显示 FAMILY_SHARE TODO 时，才允许调用方写入当日标记。
     */
    internal fun confirmFamilyInviteVisitOutcome(response: JSONObject): FamilyInviteVisitOutcome {
        if (response.optString("memo") == "SUCCESS") {
            return FamilyInviteVisitOutcome.SUBMITTED
        }
        if (response.optString("resultCode") != "FAMILY48") {
            return FamilyInviteVisitOutcome.RETRY_LATER
        }

        val taskSnapshot = JSONObject(listFamilyTask())
        if (!isFamilyTaskSnapshotSuccess(taskSnapshot) || hasPendingFamilyShareTask(taskSnapshot)) {
            return FamilyInviteVisitOutcome.RETRY_LATER
        }
        return FamilyInviteVisitOutcome.ALREADY_COMPLETED_CONFIRMED
    }

    private fun isFamilyTaskSnapshotSuccess(response: JSONObject): Boolean =
        response.optBoolean("success") ||
            response.optString("memo") == "SUCCESS" ||
            response.optString("resultCode") == "SUCCESS"

    private fun hasPendingFamilyShareTask(response: JSONObject): Boolean {
        val familyTasks = response.optJSONArray("familyTasks") ?: return true
        for (index in 0 until familyTasks.length()) {
            val task = familyTasks.optJSONObject(index) ?: continue
            val isFamilyShare =
                task.optString("bizKey") == "FAMILY_SHARE" ||
                    task.optString("taskId") == "FAMILY_SHARE" ||
                    task.optString("taskType") == "FAMILY_SHARE"
            if (isFamilyShare && task.optString("taskStatus") == "TODO") {
                return true
            }
        }
        return false
    }

    @JvmStatic
    fun familyEatTogether(
        groupId: String?,
        friendUserIdList: JSONArray?,
        cuisines: JSONArray?,
    ): String {
        val args =
            "[{\"cuisines\":" + cuisines + ",\"friendUserIds\":" + friendUserIdList + ",\"groupId\":\"" + groupId +
                "\",\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\",\"spaceType\":\"ChickFamily\"}]"
        return requestString("com.alipay.antfarm.familyEatTogether", args)
    }

    @JvmStatic
    fun queryRecentFarmFood(queryNum: Int, pageNo: Int? = null): String {
        val args = JSONObject().put("requestType", "NORMAL").put("sceneCode", "ANTFARM").put("source", "H5")
        if (pageNo == null) args.put("queryNum", queryNum)
        else args.put("pageNo", pageNo).put("pageSize", 10)
        return requestString("com.alipay.antfarm.queryRecentFarmFood", JSONArray().put(args).toString())
    }

    @JvmStatic
    fun feedFriendAnimal(
        friendFarmId: String?,
        groupId: String?,
    ): String {
        val args =
            "[{\"friendFarmId\": \"" + friendFarmId + "\",\"groupId\": \"" + groupId +
                "\",\"requestType\":\"NORMAL\",\"sceneCode\":\"ChickFamily\",\"source\":\"H5\",\"spaceType\":\"ChickFamily\"}]"
        return requestString("com.alipay.antfarm.feedFriendAnimal", args)
    }

    @JvmStatic
    fun getMallHome(): String {
        val data =
            "[{\"bizType\":\"ANTFARM_GAME_CENTER\",\"pageSize\":10,\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\",\"startIndex\":0}]"
        return requestString("com.alipay.charitygamecenter.getMallHome", data)
    }

    @JvmStatic
    fun getMallItemDetail(spuId: String?): String {
        val data =
            "[{\"bizType\":\"ANTFARM_GAME_CENTER\",\"itemId\":\"" + spuId +
                "\",\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\"}]"
        return requestString("com.alipay.charitygamecenter.getMallItemDetail", data)
    }

    @JvmStatic
    fun exchangeBenefit(
        spuId: String?,
        skuId: String?,
    ): String {
        val data =
            "[{\"bizType\":\"ANTFARM_GAME_CENTER\",\"ignoreHoldLimit\":false,\"itemId\":\"" + spuId +
                "\",\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"H5\",\"subItemId\":\"" +
                skuId +
                "\"}]"
        return requestString("com.alipay.charitygamecenter.buyMallItem", data)
    }

    /**
     * 装修金商城 - 分页查询家具列表
     */
    @JvmStatic
    fun getFitmentItemList(
        activityId: String?,
        pageSize: Int,
        labelType: String?,
        startIndex: Int,
    ): String =
        try {
            val args = JSONObject()
            args.put("activityId", activityId)
            if (!labelType.isNullOrEmpty()) {
                args.put("labelType", labelType)
            }
            args.put("pageSize", pageSize)
            args.put("requestType", "NORMAL")
            args.put("sceneCode", "ANTFARM_FITMENT_MALL")
            args.put("source", "antfarm")
            args.put("startIndex", startIndex)
            requestString("com.alipay.antiep.itemList", "[$args]")
        } catch (_: Exception) {
            ""
        }

    /**
     * 查询物品列表（IP抽抽乐）
     *
     * @param activityId 活动ID（如 ipDrawMachine_260112）
     * @param pageSize 每页数量
     * @param startIndex 起始索引
     */
    @JvmStatic
    fun getItemList(
        activityId: String?,
        pageSize: Int,
        startIndex: Int,
    ): String {
        val data = "[{\"activityId\":\"$activityId\",\"pageSize\":$pageSize,\"requestType\":\"RPC\",\"sceneCode\":\"ANTFARM_IP_DRAW_MALL\",\"source\":\"antfarm_villa\",\"startIndex\":$startIndex}]"
        return requestString("com.alipay.antiep.itemList", data)
    }

    /**
     * 查询物品详情（IP抽抽乐）
     */
    @JvmStatic
    fun getIpDrawMallItemDetail(spuId: String?): String {
        val args =
            JSONObject().apply {
                put("requestType", "RPC")
                put("sceneCode", "ANTFARM_IP_DRAW_MALL")
                put("source", "antfarm_villa")
                put("spuId", spuId ?: "")
            }
        return requestString("com.alipay.antiep.itemDetail", "[$args]")
    }

    /**
     * 兑换庄园家具（装修金商城）
     */
    @JvmStatic
    fun exchangeBenefit(
        spuId: String?,
        skuId: String?,
        activityId: String?,
    ): String {
        val requestId = generateRequestId()
        return try {
            val requestDataItem = JSONObject()

            val context = JSONObject()
            context.put("activityId", activityId)

            requestDataItem.put("context", context)
            requestDataItem.put("requestId", requestId)
            requestDataItem.put("requestType", "NORMAL")
            requestDataItem.put("sceneCode", "ANTFARM_FITMENT_MALL")
            requestDataItem.put("skuId", skuId)
            requestDataItem.put("source", "H5")
            requestDataItem.put("spuId", spuId)

            val requestData = JSONArray().put(requestDataItem)
            requestString("com.alipay.antcommonweal.exchange.h5.exchangeBenefit", requestData.toString())
        } catch (_: JSONException) {
            ""
        }
    }

    /**
     * IP抽抽乐兑换装扮
     *
     * @param spuId 标准产品单元ID
     * @param skuId 库存保持单位ID
     * @param activityId 活动ID（例如: ipDrawMachine_260112）
     * @param sceneCode 场景代码（例如: ANTFARM_IP_DRAW_MALL）
     * @param source 来源
     */
    @JvmStatic
    fun exchangeBenefit(
        spuId: String?,
        skuId: String?,
        activityId: String?,
        sceneCode: String?,
        source: String?,
    ): String {
        val requestId = generateRequestId()
        return try {
            val requestDataItem = JSONObject()

            val context = JSONObject()
            context.put("activityId", activityId)

            requestDataItem.put("context", context)
            requestDataItem.put("buyCount", 1)
            requestDataItem.put("requestId", requestId)
            requestDataItem.put("requestType", "RPC")
            requestDataItem.put("sceneCode", sceneCode)
            requestDataItem.put("skuId", skuId)
            requestDataItem.put("source", source)
            requestDataItem.put("spuId", spuId)

            val requestData = JSONArray().put(requestDataItem)
            requestString("com.alipay.antcommonweal.exchange.h5.exchangeBenefit", requestData.toString())
        } catch (_: JSONException) {
            ""
        }
    }

    /**
     * 生成RequestId: 时间戳 + _ + 16位随机数
     */
    private fun generateRequestId(): String {
        val timestamp = System.currentTimeMillis()
        val randomNum = ((Math.random() * 9 + 1) * Math.pow(10.0, 15.0)).toLong()
        return "${timestamp}_$randomNum"
    }

    /**
     * 领取活动食物
     *
     * @param foodType
     * @param giftIndex
     * @return
     */
    @JvmStatic
    fun clickForGiftV2(
        foodType: String?,
        giftIndex: Int,
    ): String {
        val data =
            "[{\"foodType\":\"" + foodType + "\",\"giftIndex\":" + giftIndex +
                ",\"requestType\":\"NORMAL\",\"sceneCode\":\"ANTFARM\",\"source\":\"ANTFOREST\",\"version\":\"" +
                VERSION +
                "\"}]"
        return requestString("com.alipay.antfarm.clickForGiftV2", data)
    }

    /**
     * 装扮币商城 - 查询物品列表
     */
    @JvmStatic
    fun getOrnamentItemList(
        pageSize: Int,
        startIndex: Int,
    ): String {
        val args =
            JSONObject().apply {
                put("pageSize", pageSize)
                put("requestType", "RPC")
                put("sceneCode", "ANTFARM_DRESSUP_MALL")
                put("source", "H5")
                put("startIndex", startIndex)
            }
        return requestString("com.alipay.antiep.itemList", "[$args]")
    }

    /**
     * 装扮币商城 - 查询装扮详情
     */
    @JvmStatic
    fun getOrnamentItemDetail(spuId: String?): String {
        val args =
            JSONObject().apply {
                put("requestType", "RPC")
                put("sceneCode", "ANTFARM_DRESSUP_MALL")
                put("source", "H5")
                put("spuId", spuId ?: "")
            }
        return requestString("com.alipay.antiep.itemDetail", "[$args]")
    }

    /**
     * 装扮币商城 - 兑换装扮
     */
    @JvmStatic
    fun exchangeOrnamentBenefit(
        spuId: String?,
        skuId: String?,
    ): String {
        val requestId = generateRequestId()
        val args =
            JSONObject().apply {
                put("context", JSONObject())
                put("requestId", requestId)
                put("requestType", "RPC")
                put("sceneCode", "ANTFARM_DRESSUP_MALL")
                put("skuId", skuId ?: "")
                put("source", "H5")
                put("spuId", spuId ?: "")
            }
        return requestString("com.alipay.antcommonweal.exchange.h5.exchangeBenefit", "[$args]")
    }

    /**
     * 同步装扮币
     */
    @JvmStatic
    fun syncOrnamentCoin(): String {
        val args =
            JSONObject().apply {
                put("requestType", "RPC")
                put("sceneCode", "ANTFARM")
                put("source", "H5")
            }
        return requestString("com.alipay.antfarm.syncOrnamentCoin", "[$args]")
    }

    @JvmStatic
    fun queryCompetitionEntranceInfo(): String {
        val args =
            JSONObject().apply {
                put("requestType", "NORMAL")
                put("sceneCode", "ANTFARM")
                put("source", "H5")
                put("version", VERSION)
            }
        return RequestManager.requestString("com.alipay.antfarm.queryCompetitionEntranceInfo", "[$args]")
    }

    @JvmStatic
    fun enterDonationCompetitionRank(): String {
        val args =
            JSONObject().apply {
                put("requestType", "NORMAL")
                put("sceneCode", "ANTFARM")
                put("source", "H5")
                put("version", VERSION)
            }
        return RequestManager.requestString("com.alipay.antfarm.enterDonationCompetitionRank", "[$args]")
    }

    @JvmStatic
    fun participateCompetition(): String {
        val args =
            JSONObject().apply {
                put("requestType", "NORMAL")
                put("sceneCode", "ANTFARM")
                put("source", "H5")
                put("version", VERSION)
            }
        return RequestManager.requestString("com.alipay.antfarm.participateCompetition", "[$args]")
    }

    @JvmStatic
    fun getAnnGift(): String {
        val args =
            JSONObject().apply {
                put("requestType", "NORMAL")
                put("sceneCode", "ANTFARM")
                put("source", "H5")
                put("version", VERSION)
            }
        return RequestManager.requestString("com.alipay.antfarm.getAnnGift", "[$args]")
    }

    @JvmStatic
    fun listCompetitionTask(): String {
        val args =
            JSONObject().apply {
                put("requestType", "NORMAL")
                put("sceneCode", "ANTFARM")
                put("source", "H5")
                put("version", VERSION)
            }
        return RequestManager.requestString("com.alipay.antfarm.listCompetitionTask", "[$args]")
    }

    @JvmStatic
    fun queryAllMemberRankInfo(): String {
        val args =
            JSONObject().apply {
                put("requestType", "NORMAL")
                put("sceneCode", "ANTFARM")
                put("source", "H5")
                put("version", VERSION)
            }
        return RequestManager.requestString("com.alipay.antfarm.queryAllMemberRankInfo", "[$args]")
    }

    @JvmStatic
    fun queryPageRankInfo(
        rankRoundId: String,
        pageNo: Int,
    ): String {
        val args =
            JSONObject().apply {
                put("pageNo", pageNo)
                put("rankRoundId", rankRoundId)
                put("requestType", "NORMAL")
                put("sceneCode", "ANTFARM")
                put("source", "H5")
                put("version", VERSION)
            }
        return RequestManager.requestString("com.alipay.antfarm.queryPageRankInfo", "[$args]")
    }

    @JvmStatic
    fun enterCompetitionAwardPage(): String {
        val args =
            JSONObject().apply {
                put("requestType", "NORMAL")
                put("sceneCode", "ANTFARM")
                put("source", "H5")
                put("version", VERSION)
            }
        return RequestManager.requestString("com.alipay.antfarm.enterCompetitionAwardPage", "[$args]")
    }

    @JvmStatic
    fun receiveDonationLevelReward(rightsId: String?): String {
        val args =
            JSONObject().apply {
                put("requestType", "NORMAL")
                put("rightsId", rightsId ?: "")
                put("sceneCode", "ANTFARM")
                put("source", "H5")
                put("version", VERSION)
            }
        return RequestManager.requestString("com.alipay.antfarm.receiveDonationLevelReward", "[$args]")
    }

    @JvmStatic
    fun receiveDonationCompetitionProgressAward(): String {
        val args =
            JSONObject().apply {
                put("requestType", "NORMAL")
                put("sceneCode", "ANTFARM")
                put("source", "H5")
                put("version", VERSION)
            }
        return RequestManager.requestString(
            "com.alipay.antfarm.receiveDonationCompetitionProgressAward",
            "[$args]",
        )
    }
}
