package io.github.aoguai.sesameag.task.goldenBean

import io.github.aoguai.sesameag.data.Status
import io.github.aoguai.sesameag.data.StatusFlags
import io.github.aoguai.sesameag.hook.ExchangeOptionsRefreshBridge
import io.github.aoguai.sesameag.hook.ApplicationHookConstants
import io.github.aoguai.sesameag.hook.rpc.RpcDailyCircuit
import io.github.aoguai.sesameag.task.exchange.ExchangeCost
import io.github.aoguai.sesameag.task.exchange.ExchangeDisplayMeta
import io.github.aoguai.sesameag.task.exchange.ExchangeFetchPacing
import io.github.aoguai.sesameag.task.exchange.ExchangeFetchSession
import io.github.aoguai.sesameag.task.exchange.ExchangeItem
import io.github.aoguai.sesameag.task.exchange.ExchangeLimit
import io.github.aoguai.sesameag.task.exchange.ExchangeOptionsCache
import io.github.aoguai.sesameag.task.exchange.ExchangeOptionsSnapshot
import io.github.aoguai.sesameag.task.exchange.ExchangeSafety
import io.github.aoguai.sesameag.util.maps.UserMap
import io.github.aoguai.sesameag.task.common.GameCenterPlayRpcCall
import io.github.aoguai.sesameag.task.common.NonDurationGameTask
import io.github.aoguai.sesameag.task.common.TaskFlowActionResult
import io.github.aoguai.sesameag.task.common.TaskFlowItem
import io.github.aoguai.sesameag.task.common.TaskRpcFailureType
import io.github.aoguai.sesameag.util.GameTask
import io.github.aoguai.sesameag.util.Log
import io.github.aoguai.sesameag.util.TaskBlacklist
import io.github.aoguai.sesameag.util.TimeUtil
import io.github.aoguai.sesameag.util.UserDataStoreManager
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import org.json.JSONArray
import org.json.JSONObject

internal data class GoldenBeanManureExchangePlan(
    val reservedManure: Int,
    val exchangedToday: Int,
    val minimumRemainingManure: Int,
)

internal data class GoldenBeanSesameExchangePlan(
    val exchangeBeanAmount: Int,
    val exchangedToday: Int,
)

private data class GoldenBeanGameSnapshot(
    val drawRights: JSONObject?,
    val candidates: List<GameCenterPlayRpcCall.DeliveryBenefitCandidate>,
)

internal data class GoldenBeanGameFlowResult(
    val completed: Boolean,
    val progressed: Boolean,
    val taskRefreshRequested: Boolean = false,
    val blocked: Boolean = false,
)

internal object GoldenBeanTreasureSupport {
    private val unsupportedCodes = setOf("400000040")
    private val invalidCodes = setOf("20020012", "TASK_ID_INVALID", "ILLEGAL_ARGUMENT")
    private val retryableCodes = setOf("3000", "REMOTE_INVOKE_EXCEPTION")

    internal fun parseResponse(response: String): JSONObject? =
        response.takeIf { it.isNotBlank() }?.let { raw ->
            runCatching { JSONObject(raw) }
                .onFailure { Log.error(GOLDEN_BEAN_BLACKLIST_MODULE, "金豆夺宝响应解析失败 raw=$raw") }
                .getOrNull()
        }

    internal fun isSuccess(response: JSONObject): Boolean {
        if (response.optBoolean("success", false)) {
            return true
        }
        return response.optString("resultCode") in setOf("100", "SUCCESS") ||
            response.optString("code") == "100000000"
    }

    internal fun collectFloatingBeans(): Boolean {
        val identity = RpcDailyCircuit.captureIdentity()
        val attempted = mutableSetOf<String>()
        var previousAsset: String? = null
        while (true) {
            if (Thread.currentThread().isInterrupted) throw InterruptedException("浮动金豆收取已中断")
            if (ApplicationHookConstants.isOffline() || !RpcDailyCircuit.isCurrent(identity)) return false
            val snapshot = parseResponse(GoldenBeanRpcCall.sync(listOf("FLOATING_BEANS")))
            if (snapshot == null || !isSuccess(snapshot)) {
                Log.error(GOLDEN_BEAN_BLACKLIST_MODULE, "浮动金豆列表查询失败 raw=$snapshot")
                return false
            }
            val beans = snapshot.optJSONArray("floatingBeans")
                ?: snapshot.optJSONObject("data")?.optJSONArray("floatingBeans") ?: JSONArray()
            val candidates = (0 until beans.length()).mapNotNull { beans.optJSONObject(it) }
            if (previousAsset != null) {
                if (candidates.any { it.optString("assetId") == previousAsset }) {
                    Log.error(GOLDEN_BEAN_BLACKLIST_MODULE, "浮动金豆收取后仍待确认 assetId=$previousAsset raw=$snapshot")
                    return false
                }
                Log.goldenBean("浮动金豆已收取并回查 assetId=$previousAsset")
            }
            if (candidates.isEmpty()) return true
            val assetId = candidates.first().optString("assetId")
            if (assetId.isBlank() || !attempted.add(assetId)) {
                Log.error(GOLDEN_BEAN_BLACKLIST_MODULE, "浮动金豆资产标识缺失或重复 raw=$snapshot")
                return false
            }
            val result = parseResponse(GoldenBeanRpcCall.collect(assetId))
            if (result == null || !isSuccess(result)) {
                Log.error(GOLDEN_BEAN_BLACKLIST_MODULE, "浮动金豆收取失败 assetId=$assetId raw=$result")
                return false
            }
            previousAsset = assetId
        }
    }

    internal fun planSesameExchange(
        indexResponse: JSONObject,
        configuredDailyBeanAmount: Int,
    ): GoldenBeanSesameExchangePlan? {
        if (configuredDailyBeanAmount == 0) {
            return null
        }

        val exchangeInfo = requireSesameExchangeInfo(indexResponse, "计划") ?: return null
        val beanReward = exchangeInfo.optInt("beanReward", 0)
        val currentManure = exchangeInfo.optInt("currentManure", 0)
        val effectiveExchangeManure = exchangeInfo.optInt("effectiveExchangeManure", 0)
        val minExchangeAmount = exchangeInfo.optInt("minExchangeAmount", 0)
        val remainQuota = exchangeInfo.optInt("remainQuota", 0)
        val exchangedToday =
            Status.getIntFlagToday(StatusFlags.FLAG_GOLDEN_BEAN_ZHIMA_EXCHANGE_BEAN_AMOUNT) ?: 0
        val configuredRemaining =
            if (configuredDailyBeanAmount > 0) configuredDailyBeanAmount - exchangedToday else Int.MAX_VALUE
        val availableBeans = minOf(
            remainQuota.toLong(),
            currentManure.toLong() * beanReward.toLong(),
            effectiveExchangeManure.toLong() * beanReward.toLong(),
            configuredRemaining.toLong(),
        ).coerceAtLeast(0L).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()

        Log.goldenBean(
            "金豆夺宝芝麻粒换豆资格 pageOpened=${exchangeInfo.optBoolean("pageOpened")} " +
                "currentSesameGrain=$currentManure effectiveSesameGrain=$effectiveExchangeManure " +
                "beanReward=$beanReward minExchangeAmount=$minExchangeAmount remainQuota=$remainQuota " +
                "configuredDailyBeanAmount=$configuredDailyBeanAmount exchangedToday=$exchangedToday " +
                "availableBeans=$availableBeans",
        )
        if (!exchangeInfo.optBoolean("pageOpened") || beanReward <= 0 || minExchangeAmount <= 0) {
            Log.goldenBean("金豆夺宝芝麻粒换豆[BUSINESS_LIMIT] 服务端资格未满足")
            return null
        }
        if (availableBeans < minExchangeAmount) {
            Log.goldenBean("金豆夺宝芝麻粒换豆[BUSINESS_LIMIT] 可兑换金豆不足最低兑换量")
            return null
        }
        return GoldenBeanSesameExchangePlan(availableBeans, exchangedToday)
    }

    internal fun exchangePlannedSesame(
        indexResponse: JSONObject,
        plan: GoldenBeanSesameExchangePlan,
    ): Boolean {
        requireSesameExchangeInfo(indexResponse, "执行") ?: return false
        val exchangeResponse =
            parseResponse(GoldenBeanRpcCall.manureExchange(plan.exchangeBeanAmount, GoldenBeanRpcCall.ZHIMA_ENTRY))
        if (exchangeResponse == null || !isSuccess(exchangeResponse)) {
            logManureExchangeFailure("zhimaManureExchange", exchangeResponse)
            return false
        }
        val beanDelta = exchangeResponse.optInt("beanDelta", 0)
        if (beanDelta <= 0) {
            Log.error(
                GOLDEN_BEAN_BLACKLIST_MODULE,
                "金豆夺宝芝麻粒换豆 classification=UNKNOWN_NEEDS_REVIEW 响应缺少有效beanDelta raw=$exchangeResponse",
            )
            return false
        }

        val syncResponse =
            parseResponse(
                GoldenBeanRpcCall.sync(
                    listOf("JAR_INFO", "EXCHANGE_MANURE", "TASK_LIST"),
                    GoldenBeanRpcCall.ZHIMA_ENTRY,
                ),
            )
        if (syncResponse == null || !isSuccess(syncResponse)) {
            logManureExchangeFailure("zhimaSync", syncResponse)
            return false
        }
        if (!hasSesameExchangeProgress(indexResponse, syncResponse)) {
            Log.error(
                GOLDEN_BEAN_BLACKLIST_MODULE,
                "金豆夺宝芝麻粒换豆 classification=UNKNOWN_NEEDS_REVIEW " +
                    "请求成功但同步未确认芝麻粒、配额、金豆罐或任务状态推进 raw=$syncResponse",
            )
            return false
        }

        Status.setIntFlagToday(
            StatusFlags.FLAG_GOLDEN_BEAN_ZHIMA_EXCHANGE_BEAN_AMOUNT,
            plan.exchangedToday + beanDelta,
        )
        val afterInfo = syncResponse.optJSONObject("manureExchangeInfo")
        Log.goldenBean(
            "金豆夺宝芝麻粒兑换成功并完成服务端回查 requested=${plan.exchangeBeanAmount} " +
                "beanDelta=$beanDelta sesameCost=${exchangeResponse.optInt("manureCost", -1)} " +
                "remainSesameGrain=${afterInfo?.optInt("currentManure", -1)} " +
                "remainQuota=${afterInfo?.optInt("remainQuota", -1)}",
        )
        return true
    }

    internal fun planManureExchange(
        indexResponse: JSONObject,
        configuredDailyReserveAmount: Int,
        minimumRemainingManure: Int,
    ): GoldenBeanManureExchangePlan? {
        if (configuredDailyReserveAmount == 0) {
            return null
        }

        val exchangeInfo = requireManureExchangeInfo(indexResponse, "预留")
            ?: return null
        val farmOpened = exchangeInfo.optBoolean("farmOpened")
        val pageOpened = exchangeInfo.optBoolean("pageOpened")
        val taobaoBinding = exchangeInfo.optBoolean("taobaoBinding")
        val currentManure = exchangeInfo.optInt("currentManure", 0)
        val effectiveExchangeManure = exchangeInfo.optInt("effectiveExchangeManure", 0)
        val minExchangeAmount = exchangeInfo.optInt("minExchangeAmount", 0)
        val remainQuota = exchangeInfo.optInt("remainQuota", 0)
        val exchangedToday =
            Status.getIntFlagToday(StatusFlags.FLAG_GOLDEN_BEAN_MANURE_EXCHANGE_AMOUNT) ?: 0
        val reservedManure =
            when {
                configuredDailyReserveAmount == -1 -> minOf(
                    effectiveExchangeManure, remainQuota,
                    (currentManure - minimumRemainingManure).coerceAtLeast(0),
                )
                configuredDailyReserveAmount > 0 -> configuredDailyReserveAmount - exchangedToday
                else -> {
                    Log.error(
                        GOLDEN_BEAN_BLACKLIST_MODULE,
                        "金豆夺宝肥料换豆 classification=UNKNOWN_NEEDS_REVIEW " +
                            "配置额度=$configuredDailyReserveAmount 不受支持",
                    )
                    return null
                }
            }

        Log.goldenBean(
            "金豆夺宝肥料换豆预留资格 farmOpened=$farmOpened " +
                "pageOpened=$pageOpened " +
                "taobaoBinding=$taobaoBinding " +
                "currentManure=$currentManure " +
                "effectiveExchangeManure=$effectiveExchangeManure " +
                "minExchangeAmount=$minExchangeAmount " +
                "remainQuota=$remainQuota " +
                "configuredDailyReserveAmount=$configuredDailyReserveAmount " +
                "exchangedToday=$exchangedToday reservedManure=$reservedManure",
        )

        if (!farmOpened || !pageOpened || !taobaoBinding) {
            Log.goldenBean("金豆夺宝肥料换豆[BUSINESS_LIMIT] 服务端资格未满足")
            return null
        }
        if (minExchangeAmount <= 0) {
            Log.error(
                GOLDEN_BEAN_BLACKLIST_MODULE,
                "金豆夺宝肥料换豆 classification=UNKNOWN_NEEDS_REVIEW 服务端最低兑换量无效=$minExchangeAmount",
            )
            return null
        }
        if (reservedManure <= 0) {
            Log.goldenBean("金豆夺宝肥料换豆[USER_LIMIT] 今日配置额度已用完")
            return null
        }
        if (reservedManure < minExchangeAmount) {
            val classification =
                if (configuredDailyReserveAmount > 0) "USER_CONFIGURATION" else "BUSINESS_LIMIT"
            Log.goldenBean(
                "金豆夺宝肥料换豆[$classification] 预留${reservedManure}低于服务端最小兑换量$minExchangeAmount，本轮不预留也不换豆",
            )
            return null
        }
        if (currentManure.toLong() - reservedManure < minimumRemainingManure ||
            effectiveExchangeManure < reservedManure ||
            remainQuota < reservedManure
        ) {
            Log.goldenBean(
                "金豆夺宝肥料换豆[USER_RESERVE_UNMET] 当前肥料或服务端可兑换额度不足预留$reservedManure，" +
                    "本轮不预留也不换豆",
            )
            return null
        }

        return GoldenBeanManureExchangePlan(
            reservedManure = reservedManure,
            exchangedToday = exchangedToday,
            minimumRemainingManure = minimumRemainingManure,
        )
    }

    internal fun exchangePlannedManure(
        indexResponse: JSONObject,
        plan: GoldenBeanManureExchangePlan,
    ): Boolean {
        val exchangeInfo = requireManureExchangeInfo(indexResponse, "最终兑换")
            ?: return false
        val farmOpened = exchangeInfo.optBoolean("farmOpened")
        val pageOpened = exchangeInfo.optBoolean("pageOpened")
        val taobaoBinding = exchangeInfo.optBoolean("taobaoBinding")
        val currentManure = exchangeInfo.optInt("currentManure", 0)
        val effectiveExchangeManure = exchangeInfo.optInt("effectiveExchangeManure", 0)
        val minExchangeAmount = exchangeInfo.optInt("minExchangeAmount", 0)
        val remainQuota = exchangeInfo.optInt("remainQuota", 0)

        if (!farmOpened || !pageOpened || !taobaoBinding) {
            Log.goldenBean("金豆夺宝肥料换豆[BUSINESS_LIMIT] 最终回查资格未满足")
            return false
        }
        if (minExchangeAmount <= 0) {
            Log.error(
                GOLDEN_BEAN_BLACKLIST_MODULE,
                "金豆夺宝肥料换豆 classification=UNKNOWN_NEEDS_REVIEW 最终回查最低兑换量无效=$minExchangeAmount",
            )
            return false
        }
        if (plan.reservedManure < minExchangeAmount ||
            currentManure.toLong() - plan.reservedManure < plan.minimumRemainingManure ||
            effectiveExchangeManure < plan.reservedManure ||
            remainQuota < plan.reservedManure
        ) {
            Log.goldenBean(
                "金豆夺宝肥料换豆[BUSINESS_LIMIT] 最终回查无法满足预留${plan.reservedManure}，不发送兑换请求",
            )
            return false
        }

        val exchangeResponse = parseResponse(GoldenBeanRpcCall.manureExchange(plan.reservedManure))
        if (exchangeResponse == null || !isSuccess(exchangeResponse)) {
            logManureExchangeFailure("manureExchange", exchangeResponse)
            return false
        }

        val syncResponse =
            parseResponse(
                GoldenBeanRpcCall.sync(
                    listOf("JAR_INFO", "EXCHANGE_MANURE", "TASK_LIST"),
                    GoldenBeanRpcCall.MASTER_ENTRY,
                ),
            )
        if (syncResponse == null || !isSuccess(syncResponse)) {
            logManureExchangeFailure("sync", syncResponse)
            return false
        }

        if (hasManureExchangeProgress(indexResponse, syncResponse)) {
            val afterInfo = syncResponse.optJSONObject("manureExchangeInfo")
            val confirmedManureCost = resolveConfirmedManureCost(exchangeResponse, indexResponse, syncResponse)
            if (confirmedManureCost != null) {
                Status.setIntFlagToday(
                    StatusFlags.FLAG_GOLDEN_BEAN_MANURE_EXCHANGE_AMOUNT,
                    plan.exchangedToday + confirmedManureCost,
                )
            } else {
                Log.error(
                    GOLDEN_BEAN_BLACKLIST_MODULE,
                    "金豆夺宝肥料兑换 classification=UNKNOWN_NEEDS_REVIEW " +
                        "服务端已确认状态推进但缺少可计量肥料消耗 raw=$syncResponse",
                )
                return false
            }
            Log.goldenBean(
                "金豆夺宝肥料兑换成功并完成服务端回查 amount=${plan.reservedManure} " +
                    "manureCost=${confirmedManureCost ?: "UNKNOWN"} " +
                    "remainManure=${afterInfo?.optInt("currentManure", -1)} " +
                    "remainQuota=${afterInfo?.optInt("remainQuota", -1)} " +
                    "taskStatus=${findManureExchangeTaskStatus(syncResponse) ?: "UNKNOWN"}",
            )
            return true
        } else {
            Log.error(
                GOLDEN_BEAN_BLACKLIST_MODULE,
                "金豆夺宝肥料兑换 classification=UNKNOWN_NEEDS_REVIEW " +
                    "请求成功但同步未确认肥料、配额、金豆罐或任务状态推进 " +
                    "amount=${plan.reservedManure} raw=$syncResponse",
            )
        }
        return false
    }

    private fun requireSesameExchangeInfo(
        indexResponse: JSONObject,
        phase: String,
    ): JSONObject? {
        val exchangeInfo = indexResponse.optJSONObject("manureExchangeInfo")
        if (exchangeInfo == null) {
            Log.error(
                GOLDEN_BEAN_BLACKLIST_MODULE,
                "金豆夺宝芝麻粒换豆 classification=UNKNOWN_NEEDS_REVIEW $phase 缺少manureExchangeInfo raw=$indexResponse",
            )
            return null
        }
        val requiredFields = listOf(
            "pageOpened",
            "currentManure",
            "effectiveExchangeManure",
            "beanReward",
            "minExchangeAmount",
            "remainQuota",
        )
        val missingField = requiredFields.firstOrNull { !exchangeInfo.has(it) }
        if (missingField != null) {
            Log.error(
                GOLDEN_BEAN_BLACKLIST_MODULE,
                "金豆夺宝芝麻粒换豆 classification=UNKNOWN_NEEDS_REVIEW $phase 缺少字段=$missingField raw=$exchangeInfo",
            )
            return null
        }
        return exchangeInfo
    }

    private fun hasSesameExchangeProgress(
        beforeResponse: JSONObject,
        afterResponse: JSONObject,
    ): Boolean {
        val beforeInfo = beforeResponse.optJSONObject("manureExchangeInfo") ?: return false
        val afterInfo = afterResponse.optJSONObject("manureExchangeInfo") ?: return false
        val grainProgressed = listOf("currentManure", "effectiveExchangeManure", "remainQuota").any { field ->
            afterInfo.optInt(field, Int.MAX_VALUE) < beforeInfo.optInt(field, Int.MIN_VALUE)
        }
        if (grainProgressed) {
            return true
        }
        val beforeJar = beforeResponse.optJSONObject("jarInfo")?.optInt("currentProgress", -1) ?: -1
        val afterJar = afterResponse.optJSONObject("jarInfo")?.optInt("currentProgress", -1) ?: -1
        if (beforeJar >= 0 && afterJar > beforeJar) {
            return true
        }
        val beforeStatus = findManureExchangeTaskStatus(beforeResponse)
        val afterStatus = findManureExchangeTaskStatus(afterResponse)
        return beforeStatus != null && afterStatus != null && beforeStatus != afterStatus &&
            afterStatus in setOf("FINISHED", "TO_RECEIVE", "RECEIVED", "DONE")
    }

    private fun requireManureExchangeInfo(
        indexResponse: JSONObject,
        phase: String,
    ): JSONObject? {
        val exchangeInfo = indexResponse.optJSONObject("manureExchangeInfo")
        if (exchangeInfo == null) {
            Log.error(
                GOLDEN_BEAN_BLACKLIST_MODULE,
                "金豆夺宝肥料兑换 classification=UNKNOWN_NEEDS_REVIEW $phase 缺少manureExchangeInfo raw=$indexResponse",
            )
            return null
        }

        val requiredFields =
            listOf(
                "farmOpened",
                "pageOpened",
                "taobaoBinding",
                "currentManure",
                "effectiveExchangeManure",
                "minExchangeAmount",
                "remainQuota",
            )
        val missingField = requiredFields.firstOrNull { !exchangeInfo.has(it) }
        if (missingField != null) {
            Log.error(
                GOLDEN_BEAN_BLACKLIST_MODULE,
                "金豆夺宝肥料兑换 classification=UNKNOWN_NEEDS_REVIEW $phase 缺少字段=$missingField raw=$exchangeInfo",
            )
            return null
        }
        return exchangeInfo
    }

    private fun resolveConfirmedManureCost(
        exchangeResponse: JSONObject,
        beforeResponse: JSONObject,
        afterResponse: JSONObject,
    ): Int? {
        val responseCost = exchangeResponse.optInt("manureCost", 0)
        if (responseCost > 0) {
            return responseCost
        }

        val beforeInfo = beforeResponse.optJSONObject("manureExchangeInfo") ?: return null
        val afterInfo = afterResponse.optJSONObject("manureExchangeInfo") ?: return null
        for (field in listOf("currentManure", "effectiveExchangeManure")) {
            if (!beforeInfo.has(field) || !afterInfo.has(field)) {
                continue
            }
            val decrease = beforeInfo.optInt(field) - afterInfo.optInt(field)
            if (decrease > 0) {
                return decrease
            }
        }
        return null
    }

    private fun hasManureExchangeProgress(
        beforeResponse: JSONObject,
        afterResponse: JSONObject,
    ): Boolean {
        val beforeInfo = beforeResponse.optJSONObject("manureExchangeInfo")
        val afterInfo = afterResponse.optJSONObject("manureExchangeInfo")
        if (beforeInfo != null && afterInfo != null) {
            val manureDecreased =
                afterInfo.optInt("currentManure", Int.MAX_VALUE) <
                    beforeInfo.optInt("currentManure", Int.MIN_VALUE)
            val effectiveAmountDecreased =
                afterInfo.optInt("effectiveExchangeManure", Int.MAX_VALUE) <
                    beforeInfo.optInt("effectiveExchangeManure", Int.MIN_VALUE)
            val quotaDecreased =
                afterInfo.optInt("remainQuota", Int.MAX_VALUE) <
                    beforeInfo.optInt("remainQuota", Int.MIN_VALUE)
            if (manureDecreased || effectiveAmountDecreased || quotaDecreased) {
                return true
            }
        }

        val beforeProgress = beforeResponse.optJSONObject("jarInfo")?.optInt("currentProgress", -1) ?: -1
        val afterProgress = afterResponse.optJSONObject("jarInfo")?.optInt("currentProgress", -1) ?: -1
        if (beforeProgress >= 0 && afterProgress > beforeProgress) {
            return true
        }

        val beforeStatus = findManureExchangeTaskStatus(beforeResponse)
        val afterStatus = findManureExchangeTaskStatus(afterResponse)
        return beforeStatus != null &&
            afterStatus != null &&
            beforeStatus != afterStatus &&
            afterStatus in setOf("FINISHED", "TO_RECEIVE", "RECEIVED", "DONE")
    }

    private fun findManureExchangeTaskStatus(response: JSONObject): String? {
        val taskList = response.optJSONArray("taskList") ?: return null
        for (index in 0 until taskList.length()) {
            val task = taskList.optJSONObject(index) ?: continue
            if (task.optString("sceneCode") == GoldenBeanRpcCall.TASK_SCENE_CODE &&
                task.optString("taskId") == GoldenBeanRpcCall.MANURE_EXCHANGE_TASK_TYPE
            ) {
                return task.optString("taskStatus").trim().ifBlank { null }
            }
        }
        return null
    }

    private fun logManureExchangeFailure(
        action: String,
        response: JSONObject?,
    ) {
        val classification =
            if (response == null) {
                TaskRpcFailureType.RETRYABLE_RPC
            } else if (response.optBoolean("retryable", false) || response.optBoolean("retriable", false)) {
                TaskRpcFailureType.RETRYABLE_RPC
            } else {
                TaskRpcFailureType.UNKNOWN_NEEDS_REVIEW
            }
        Log.error(
            GOLDEN_BEAN_BLACKLIST_MODULE,
            "金豆夺宝肥料兑换 action=$action classification=$classification " +
                "code=${response?.optString("code").orEmpty()} " +
                "resultCode=${response?.optString("resultCode").orEmpty()} " +
                "desc=${response?.let(::extractFailureMessage).orEmpty()} raw=${response ?: "EMPTY"}",
        )
    }

    internal fun handleFortuneDraw(indexResponse: JSONObject) {
        if (Status.hasFlagToday(StatusFlags.FLAG_GOLDEN_BEAN_FORTUNE_DRAWN)) return
        val info = indexResponse.optJSONObject("fortuneDrawInfo") ?: return
        if (info.optBoolean("todayDrawn")) {
            Status.setFlagToday(StatusFlags.FLAG_GOLDEN_BEAN_FORTUNE_DRAWN)
            return
        }
        val result = parseResponse(GoldenBeanRpcCall.fortuneDraw())
        val succeeded = result != null && isSuccess(result)
        val reward = result?.opt("beanDelta") as? Number
        val fortuneType = result?.optJSONObject("fortuneType")
        var confirmed = succeeded && reward != null && fortuneType != null
        if (!confirmed) {
            val refreshed = parseResponse(GoldenBeanRpcCall.index())
            confirmed = refreshed != null && isSuccess(refreshed) &&
                refreshed.optJSONObject("fortuneDrawInfo")?.optBoolean("todayDrawn") == true
        }
        if (!confirmed) {
            Log.error(GOLDEN_BEAN_BLACKLIST_MODULE, "金豆求签未确认完成 raw=${result ?: "EMPTY"}")
            return
        }
        Status.setFlagToday(StatusFlags.FLAG_GOLDEN_BEAN_FORTUNE_DRAWN)
        if (succeeded && reward != null) {
            Log.goldenBean("金豆夺宝🔮[${fortuneType?.optString("typeName").orEmpty()}]获得${reward.toInt()}金豆")
        } else {
            Log.goldenBean("金豆夺宝🔮服务端已确认今日求签完成")
        }
    }

    internal fun handleDailySign(
        indexResponse: JSONObject,
        entry: GoldenBeanEntry = GoldenBeanRpcCall.MASTER_ENTRY,
    ): JSONObject? {
        val signList = indexResponse.optJSONObject("signInfo")?.optJSONArray("signList") ?: return null
        for (index in 0 until signList.length()) {
            val sign = signList.optJSONObject(index) ?: continue
            if (!sign.optBoolean("today", false) || sign.optBoolean("signed", false)) {
                continue
            }
            val signKey = sign.optString("signKey").trim()
            if (signKey.isBlank()) {
                Log.error(GOLDEN_BEAN_BLACKLIST_MODULE, "金豆夺宝签到缺少服务端signKey")
                return null
            }

            val signResponse = parseResponse(GoldenBeanRpcCall.sign(signKey, entry))
            if (signResponse == null || !isSuccess(signResponse)) {
                Log.error(GOLDEN_BEAN_BLACKLIST_MODULE, "金豆夺宝签到失败 raw=${signResponse ?: "EMPTY"}")
                return null
            }
            val syncResponse = parseResponse(
                GoldenBeanRpcCall.sync(
                    listOf("JAR_INFO", "SIGN", "MARKETING_POPUP", "TASK_LIST"),
                    entry,
                ),
            )
            if (isTodaySigned(syncResponse)) {
                Log.goldenBean("金豆夺宝签到成功 signKey=$signKey")
            } else {
                Log.error(GOLDEN_BEAN_BLACKLIST_MODULE, "金豆夺宝签到未通过服务端状态确认 raw=${syncResponse ?: "EMPTY"}")
            }
            return syncResponse
        }
        return null
    }

    internal fun handleMarketingPopup(
        indexResponse: JSONObject,
        entry: GoldenBeanEntry = GoldenBeanRpcCall.MASTER_ENTRY,
    ) {
        val marketingTask = indexResponse.optJSONObject("marketingPopupTask") ?: return
        val taskId = marketingTask.optString("taskId").trim()
        val triggerType = marketingTask.optString("triggerType").trim().ifBlank { MARKETING_POPUP_CLICKED }
        if (taskId.isBlank()) {
            Log.error(
                GOLDEN_BEAN_BLACKLIST_MODULE,
                "金豆夺宝营销弹窗缺少服务端taskId raw=$marketingTask",
            )
            return
        }

        val triggerResponse = parseResponse(GoldenBeanRpcCall.trigger(taskId, triggerType, entry))
        if (triggerResponse == null || !isSuccess(triggerResponse)) {
            Log.error(GOLDEN_BEAN_BLACKLIST_MODULE, "金豆夺宝营销弹窗触发失败 taskId=$taskId raw=${triggerResponse ?: "EMPTY"}")
            return
        }
        val syncResponse = parseResponse(GoldenBeanRpcCall.sync(listOf("MARKETING_POPUP"), entry))
        if (syncResponse == null || !isSuccess(syncResponse)) {
            Log.error(GOLDEN_BEAN_BLACKLIST_MODULE, "金豆夺宝营销弹窗回查失败 taskId=$taskId raw=${syncResponse ?: "EMPTY"}")
        }
    }

    internal fun queryMallItems(forceRefresh: Boolean = false): ExchangeOptionsSnapshot =
        ExchangeOptionsCache.getOrFetch(
            UserMap.currentUid, ExchangeOptionsRefreshBridge.TARGET_GOLDEN_BEAN_MALL, forceRefresh,
        ) { session -> collectMallItems(session) {} }

    internal fun queryLiveMallItems(): ExchangeOptionsSnapshot = ExchangeOptionsCache.readAndReplaceFromLive(
        UserMap.currentUid, ExchangeOptionsRefreshBridge.TARGET_GOLDEN_BEAN_MALL, JSONObject(),
    ) { checkCurrent -> collectMallItems(null, checkCurrent) }

    private fun collectMallItems(session: ExchangeFetchSession?, checkCurrent: () -> Unit): ExchangeOptionsSnapshot {
        if (session != null) {
            val topResponse = parseResponse(GoldenBeanRpcCall.listTopItemsByScene())
            if (topResponse == null || !isSuccess(topResponse)) {
                Log.error(GOLDEN_BEAN_BLACKLIST_MODULE, "金豆夺宝商城运营位查询失败 raw=${topResponse ?: "EMPTY"}")
            } else {
                logMallItems(topResponse.optJSONObject("itemsSceneMap")?.optJSONArray("OPERATION_STRATEGY") ?: JSONArray(), "运营位")
            }
        }
        val allItems = JSONArray()
        val rows = linkedMapOf<String, io.github.aoguai.sesameag.task.exchange.ExchangeOptionRow>()
        val seenItems = mutableSetOf<String>()
        var startIndex = 0
        while (true) {
            checkCurrent()
            val fetch = { parseResponse(GoldenBeanRpcCall.itemList(startIndex)) ?: error("金豆商城商品列表返回空") }
            val response = session?.read("items", JSONObject().put("startIndex", startIndex), "商品第${startIndex / 20 + 1}页", fetch) ?: fetch()
            check(isSuccess(response)) { "金豆商城列表查询失败 startIndex=$startIndex raw=$response" }
            val items = response.getJSONArray("itemInfoVOList")
            val hasMore = response.getBoolean("hasMore")
            val next = if (hasMore) response.getInt("nextStartIndex") else startIndex
            check(!hasMore || items.length() > 0 && next > startIndex) { "金豆商城分页未推进 startIndex=$startIndex next=$next" }
            var added = 0
            for (i in 0 until items.length()) {
                val spu = items.getJSONObject(i)
                val spuId = spu.getString("spuId")
                require(spuId.isNotBlank()) { "金豆商城商品缺少 spuId" }
                val skus = spu.optJSONArray("skuModelList") ?: JSONArray()
                if (skus.length() == 0 && seenItems.add(spuId)) added++
                for (j in 0 until skus.length()) {
                    val sku = skus.getJSONObject(j)
                    require(sku.optString("skuId").isNotBlank()) { "金豆商城规格缺少 skuId:$sku" }
                    val item = mallExchangeItem(spu, sku)
                    if (seenItems.add(item.id)) added++
                    rows[item.id] = item.toOptionRow()
                }
                allItems.put(spu)
            }
            check(items.length() == 0 || added > 0) { "金豆商城返回重复页 startIndex=$startIndex" }
            logMallItems(items, "商品")
            session?.commit(JSONObject().put("startIndex", next).put("hasMore", hasMore), items.length(),
                if (hasMore) "商品第${next / 20 + 1}页" else "保存商品规格列表")
            if (!hasMore) return ExchangeOptionsSnapshot(rows.values.toList(), JSONObject().put("items", allItems))
            startIndex = next
            if (session != null) session.pageTurnDelay() else ExchangeFetchPacing.pageTurnDelay()
        }
    }

    internal fun mallExchangeItem(spu: JSONObject, sku: JSONObject): ExchangeItem {
        val cost = sku.optJSONObject("price")?.optLong("cent", -1L) ?: -1L
        val money = sku.optJSONObject("moneyPrice")
        val cash = if (!sku.has("moneyPrice") || sku.isNull("moneyPrice")) 0L else money?.optLong("cent", -1L) ?: -1L
        val externalOrder = spu.optString("outSpuType").isNotBlank() || spu.optString("outSpuId").isNotBlank() ||
            sku.optString("outSpuOrderLink").isNotBlank() || sku.optString("outSkuId").isNotBlank()
        val dayLeft = sku.optInt("userDayLeftAmount", -1)
        val totalLeft = sku.optInt("userTotalLeftAmount", -1)
        val stock = spu.optInt("remainStockCounts", -1)
        val (safety, reason) = when {
            cost < 0L -> ExchangeSafety.UNAVAILABLE to "未取得有效金豆罐价格"
            cash < 0L -> ExchangeSafety.LOG_ONLY to "实付金额未明确"
            cash > 0L || externalOrder -> ExchangeSafety.LOG_ONLY to "需要实付或外部下单"
            sku.optString("rightsConfigId").isBlank() -> ExchangeSafety.LOG_ONLY to "未明确内部权益领取方式"
            dayLeft == 0 || totalLeft == 0 || stock == 0 -> ExchangeSafety.UNAVAILABLE to "库存或兑换次数已用完"
            else -> ExchangeSafety.AUTO to ""
        }
        val name = listOf(spu.optString("spuName"), sku.optString("skuName")).filter { it.isNotBlank() }.distinct().joinToString(" / ")
        return ExchangeItem(
            id = "${spu.optString("spuId")}:${sku.optString("skuId")}", name = name,
            cost = ExchangeCost(
                pointText = if (cost >= 0L) "${java.math.BigDecimal.valueOf(cost, 2).stripTrailingZeros().toPlainString()}金豆罐" else "金豆罐价格未知",
                cashText = if (cash > 0L) "${java.math.BigDecimal.valueOf(cash, 2).toPlainString()}${money?.optString("currencyCode", "CNY")}" else "",
            ),
            limit = ExchangeLimit(statusText = sku.optString("skuRuleResult"),
                stockText = listOfNotNull(stock.takeIf { it >= 0 }?.let { "库存$it" }, dayLeft.takeIf { it >= 0 }?.let { "今日余${it}次" }).joinToString("，")),
            safety = safety, safetyReason = reason, displayMeta = ExchangeDisplayMeta(sourceModule = "金豆罐"),
        )
    }

    internal fun queryMallOrders(checkCurrent: () -> Unit): List<JSONObject> {
        val orders = linkedMapOf<String, JSONObject>()
        var page = 1
        while (true) {
            checkCurrent()
            val response = parseResponse(GoldenBeanRpcCall.queryExchangeOrders(page)) ?: error("金豆商城订单查询返回空")
            checkCurrent()
            check(isSuccess(response)) { "金豆商城订单查询失败 page=$page raw=$response" }
            val list = response.getJSONArray("orderInfos")
            var added = 0
            for (i in 0 until list.length()) {
                val order = list.getJSONObject(i)
                val no = order.optString("orderNo")
                require(no.isNotBlank()) { "金豆商城订单缺少 orderNo:$order" }
                if (orders.put(no, order) == null) added++
            }
            check(list.length() == 0 || added > 0) { "金豆商城订单分页未推进 page=$page" }
            if (list.length() < 20) return orders.values.toList()
            page++
            ExchangeFetchPacing.pageTurnDelay()
        }
    }

    internal suspend fun runGameCenterOpportunityFlow(
        attemptedSnapshots: MutableSet<String>,
        scheduleConfirmation: (Long) -> Unit,
        resumeOnly: Boolean = false,
    ): GoldenBeanGameFlowResult {
        val identity = RpcDailyCircuit.captureIdentity()
        val store = requireNotNull(UserDataStoreManager.getCurrentInstance()?.takeIf { it.uid == identity.userId })
        val startedAt = System.currentTimeMillis()
        val stateKey = "goldenBeanGameAttempts"
        val saved = store.get(stateKey, String::class.java)?.let(::JSONObject)
        val submittedSnapshots = mutableSetOf<String>()
        if (saved != null && TimeUtil.isSameDay(saved.optLong("day"), startedAt)) {
            val snapshots = saved.optJSONArray("snapshots") ?: JSONArray()
            for (i in 0 until snapshots.length()) submittedSnapshots.add(snapshots.getString(i))
        }
        val currentSaved = saved?.takeIf { TimeUtil.isSameDay(it.optLong("day"), startedAt) }
        val pendingTasks = currentSaved?.optJSONObject("pending") ?: JSONObject()
        val failures = currentSaved?.optJSONObject("failures") ?: JSONObject()
        val resumeKeys = pendingTasks.keys().asSequence().toSet()
        attemptedSnapshots.addAll(submittedSnapshots)
        val newlyPending = mutableSetOf<String>()
        val persist = {
            check(RpcDailyCircuit.isCurrent(identity)) { "金豆游戏账号会话已变化" }
            store.put(stateKey, JSONObject().put("day", startedAt).put("pending", pendingTasks)
                .put("failures", failures).put("snapshots", JSONArray(submittedSnapshots)).toString(), requirePersistence = true)
        }
        val rememberSubmission: (String) -> Unit = { key ->
            submittedSnapshots.add(key)
            newlyPending.add("draw")
            pendingTasks.put("draw", JSONObject().put("snapshot", key)
                .put("reason", io.github.aoguai.sesameag.task.common.DeferredReason.STATE_CONFIRMATION.name))
            persist()
        }
        var progressed = false
        var taskRefreshRequested = false
        while (true) {
            currentCoroutineContext().ensureActive()
            if (ApplicationHookConstants.isOffline() || !RpcDailyCircuit.isCurrent(identity) ||
                !TimeUtil.isSameDay(startedAt, System.currentTimeMillis())) {
                return GoldenBeanGameFlowResult(false, progressed, taskRefreshRequested, blocked = true)
            }
            val before =
                queryGameCenterSnapshot()
                    ?: return GoldenBeanGameFlowResult(false, progressed, blocked = true)
            val beforeRights = before.drawRights
            val beforeQuota = beforeRights?.optInt("quotaCanUse", 0)?.coerceAtLeast(0) ?: 0
            val beforeUsed = beforeRights?.optInt("usedQuota", 0)?.coerceAtLeast(0) ?: 0
            val quotaLimit = beforeRights?.optInt("quotaLimit", 0)?.coerceAtLeast(0) ?: 0

            // Draw rights and per-game rights are independent server state machines.
            if (beforeQuota > 0 && (!resumeOnly || "draw" in resumeKeys)) {
                val drawSnapshot = "draw:$beforeQuota:$beforeUsed:$quotaLimit"
                if (!attemptedSnapshots.add(drawSnapshot)) {
                    Log.error(GOLDEN_BEAN_BLACKLIST_MODULE, "金豆乐园抽奖配额未变化，保留待确认并停止重复提交")
                    return GoldenBeanGameFlowResult(false, progressed, blocked = true)
                }
                val drawResponse = parseResponse(GoldenBeanRpcCall.drawGameCenterAward())
                if (drawResponse == null || !isSuccess(drawResponse)) {
                    Log.error(GOLDEN_BEAN_BLACKLIST_MODULE, "金豆乐园抽奖失败 raw=${drawResponse ?: "EMPTY"}")
                    return GoldenBeanGameFlowResult(false, progressed, blocked = true)
                }
                rememberSubmission(drawSnapshot)
                val after = queryGameCenterSnapshot() ?: run {
                    scheduleConfirmation(System.currentTimeMillis())
                    return GoldenBeanGameFlowResult(false, progressed, blocked = true)
                }
                val afterQuota = after.drawRights?.optInt("quotaCanUse", beforeQuota)?.coerceAtLeast(0) ?: 0
                val afterUsed = after.drawRights?.optInt("usedQuota", beforeUsed)?.coerceAtLeast(0) ?: beforeUsed
                if (afterQuota >= beforeQuota && afterUsed <= beforeUsed) {
                    Log.error(
                        GOLDEN_BEAN_BLACKLIST_MODULE,
                        "金豆乐园抽奖回查未确认配额推进 quotaCanUse=$beforeQuota->$afterQuota " +
                            "usedQuota=$beforeUsed->$afterUsed",
                    )
                    scheduleConfirmation(System.currentTimeMillis())
                    return GoldenBeanGameFlowResult(false, progressed, blocked = true)
                }
                pendingTasks.remove("draw")
                persist()
                progressed = true
                Log.goldenBean("金豆乐园抽奖回查 quotaCanUse=$beforeQuota->$afterQuota usedQuota=$beforeUsed->$afterUsed")
                continue
            }

            // New-user game rewards can be exhausted while daily draw rights still need replenishing.
            val remainingDraws = (quotaLimit - beforeUsed - beforeQuota).coerceAtLeast(0)
            for (game in before.candidates) {
                for (states in listOf(pendingTasks, failures)) {
                    val old = states.optJSONObject(game.key) ?: continue
                    if (old.optString("snapshot") != game.snapshotKey) states.remove(game.key)
                }
            }
            persist()
            val candidates = before.candidates.filter { !resumeOnly || it.key in resumeKeys }
            val candidate =
                candidates.firstOrNull { game ->
                    (game.hasPendingReward || remainingDraws > 0) &&
                        resolveGoldenBeanGameTask(game) != null &&
                        game.snapshotKey !in attemptedSnapshots &&
                        !Status.hasFlagToday(StatusFlags.FLAG_GOLDEN_BEAN_GAME_ACTION_STOP_PREFIX + game.snapshotKey) &&
                        (pendingTasks.optJSONObject(game.key)?.let {
                            it.optString("reason") == io.github.aoguai.sesameag.task.common.DeferredReason.NO_PROGRESS_COOLDOWN.name &&
                                it.optLong("until") <= System.currentTimeMillis()
                        } ?: true)
                }
            if (candidate == null) {
                val hasPendingSupportedGame =
                    candidates.any { game ->
                        (game.hasPendingReward || remainingDraws > 0) && resolveGoldenBeanGameTask(game) != null
                    }
                val drawComplete = beforeRights == null || quotaLimit <= 0 || beforeUsed >= quotaLimit
                if (beforeRights != null && quotaLimit > 0 && beforeUsed >= quotaLimit) {
                    Log.goldenBean("金豆乐园抽奖[服务端确认已达上限$beforeUsed/$quotaLimit]，继续以独立游戏权益状态收敛")
                }
                Log.goldenBean(
                    "金豆乐园[无已验证自动动作] usedQuota=$beforeUsed/$quotaLimit " +
                        "pendingSupportedGame=$hasPendingSupportedGame",
                )
                val waiting = candidates.filter { pendingTasks.has(it.key) }
                val now = System.currentTimeMillis()
                val nextAt = waiting.mapNotNull { game ->
                    val pending = pendingTasks.getJSONObject(game.key)
                    if (pending.optString("reason") ==
                        io.github.aoguai.sesameag.task.common.DeferredReason.NO_PROGRESS_COOLDOWN.name) {
                        pending.optLong("until").takeIf { it > 0L }
                    } else now.takeIf { game.key in newlyPending }
                }.minOrNull()
                nextAt?.let { scheduleConfirmation(maxOf(now, it)) }
                val hasUnconfirmedGameAction = waiting.isNotEmpty()
                return GoldenBeanGameFlowResult(
                    completed = drawComplete && !hasPendingSupportedGame && !hasUnconfirmedGameAction,
                    progressed = progressed,
                    taskRefreshRequested = taskRefreshRequested,
                    blocked = candidates.any { failures.has(it.key) },
                )
            }

            attemptedSnapshots += candidate.snapshotKey
            val gameTask = resolveGoldenBeanGameTask(candidate) ?: continue
            Log.goldenBean(
                "金豆乐园候选[${gameTask.title}] appId=${candidate.appId} taskId=${candidate.taskId} " +
                    "rightTimes=${candidate.rightTimes}/${candidate.rightTimesLimit} remainingDraws=$remainingDraws " +
                    "action=LEGACY_EXTERNAL_REPORT",
            )
            val reportResult = NonDurationGameTask.advance(
                gameTask, candidate.rawBenefit, candidate.rawGame,
                channel = GOLDEN_BEAN_GAME_CHANNEL, detail = "taskId=${candidate.taskId}",
                logger = Log::goldenBean,
                confirmProgress = {
                    val snapshot = queryGameCenterSnapshot()
                    if (snapshot == null) null
                    else {
                        val current = snapshot.candidates.firstOrNull { it.key == candidate.key }
                        val quota = snapshot.drawRights?.optInt("quotaCanUse", -1) ?: -1
                        val used = snapshot.drawRights?.optInt("usedQuota", -1) ?: -1
                        when {
                            beforeRights?.has("quotaCanUse") == true && quota > beforeQuota ||
                                beforeRights?.has("usedQuota") == true && used > beforeUsed -> true
                            current == null -> {
                                Log.error(GOLDEN_BEAN_BLACKLIST_MODULE, "金豆游戏候选消失且权益未确认增加[${candidate.key}]")
                                null
                            }
                            current.rightTimes > candidate.rightTimes ||
                                current.taskStatus != candidate.taskStatus &&
                                current.taskStatus in setOf("FINISHED", "RECEIVED") -> true
                            else -> false
                        }
                    }
                },
            )
            pendingTasks.remove(candidate.key)
            if (reportResult.deferredReason != null && !reportResult.progressChanged) {
                pendingTasks.put(candidate.key, JSONObject().put("snapshot", candidate.snapshotKey)
                    .put("reason", reportResult.deferredReason.name).put("until", reportResult.deferredUntil ?: 0L))
                newlyPending.add(candidate.key)
            } else if (!reportResult.success && reportResult.deferredReason == null) {
                failures.put(candidate.key, JSONObject().put("snapshot", candidate.snapshotKey)
                    .put("type", reportResult.failureType?.name).put("code", reportResult.code)
                    .put("message", reportResult.message).put("raw", reportResult.raw).put("detail", reportResult.detail))
                if (reportResult.failureType == TaskRpcFailureType.NON_RETRYABLE_INVALID) {
                    Status.setFlagToday(StatusFlags.FLAG_GOLDEN_BEAN_GAME_ACTION_STOP_PREFIX + candidate.snapshotKey)
                }
            }
            persist()
            if (reportResult.stopCurrentRound) return GoldenBeanGameFlowResult(false, progressed, blocked = true)
            val after = queryGameCenterSnapshot() ?: run {
                if (newlyPending.isNotEmpty()) scheduleConfirmation(reportResult.deferredUntil ?: System.currentTimeMillis())
                return GoldenBeanGameFlowResult(false, progressed, blocked = true)
            }
            val afterCandidate =
                after.candidates.firstOrNull {
                    it.appId == candidate.appId && it.taskId == candidate.taskId
                }
            val afterQuota = after.drawRights?.optInt("quotaCanUse", beforeQuota)?.coerceAtLeast(0) ?: 0
            val afterUsed = after.drawRights?.optInt("usedQuota", beforeUsed)?.coerceAtLeast(0) ?: beforeUsed
            val candidateProgressed = reportResult.progressChanged ||
                afterCandidate?.rightTimes?.let { it > candidate.rightTimes } == true
            val rightsProgressed = afterQuota > beforeQuota || afterUsed > beforeUsed
            if (candidateProgressed || rightsProgressed) {
                progressed = true
                Log.goldenBean(
                    "金豆乐园游戏[appId=${candidate.appId} taskId=${candidate.taskId}] " +
                        "rightTimes=${candidate.rightTimes}->${afterCandidate?.rightTimes ?: candidate.rightTimes} " +
                        "quotaCanUse=$beforeQuota->$afterQuota",
                )
            } else {
                taskRefreshRequested = taskRefreshRequested || reportResult.refreshAfterAction
                Log.goldenBean(
                    "金豆乐园动作回查尚未确认权益 appId=${candidate.appId} taskId=${candidate.taskId} " +
                        "rightTimes=${candidate.rightTimes}/${candidate.rightTimesLimit} " +
                        "${reportResult.detail} msg=${reportResult.message}",
                )
            }
        }
    }

    private fun queryGameCenterSnapshot(): GoldenBeanGameSnapshot? {
        val response = parseResponse(GoldenBeanRpcCall.queryGameList())
        if (response == null || !isSuccess(response)) {
            Log.error(GOLDEN_BEAN_BLACKLIST_MODULE, "金豆乐园游戏列表查询失败 raw=${response ?: "EMPTY"}")
            return null
        }
        val drawRights = findObjectByKey(response, "gameCenterDrawRights")
        if (drawRights == null) {
            Log.goldenBean("金豆乐园快照未返回抽奖权益，继续处理独立游戏权益")
        } else if (!drawRights.has("quotaCanUse") ||
            !drawRights.has("usedQuota") ||
            !drawRights.has("quotaLimit")
        ) {
            Log.goldenBean("金豆乐园抽奖权益字段不完整，抽奖分支待后续快照确认")
        }
        return GoldenBeanGameSnapshot(
            drawRights = drawRights,
            candidates = GameCenterPlayRpcCall.collectDeliveryBenefitCandidates(response),
        )
    }

    private fun findObjectByKey(
        source: Any?,
        targetKey: String,
    ): JSONObject? =
        when (source) {
            is JSONObject -> {
                source.optJSONObject(targetKey) ?: run {
                    val keys = source.keys()
                    var result: JSONObject? = null
                    while (keys.hasNext() && result == null) {
                        result = findObjectByKey(source.opt(keys.next()), targetKey)
                    }
                    result
                }
            }

            is JSONArray -> {
                var result: JSONObject? = null
                var index = 0
                while (index < source.length() && result == null) {
                    result = findObjectByKey(source.opt(index), targetKey)
                    index++
                }
                result
            }

            else -> null
        }

    private fun resolveGoldenBeanGameTask(candidate: GameCenterPlayRpcCall.DeliveryBenefitCandidate): GameTask? =
        GameCenterPlayRpcCall.resolveTaskAction(candidate.rawBenefit, candidate.rawGame).mappedTask

    internal fun runMiner(): Boolean {
        val indexResponse = parseResponse(GoldenBeanRpcCall.minerIndex())
        if (indexResponse == null || !isSuccess(indexResponse)) {
            Log.error(GOLDEN_BEAN_BLACKLIST_MODULE, "金猫矿工首页查询失败 raw=${indexResponse ?: "EMPTY"}")
            return false
        }

        if (!indexResponse.has("enabled")) {
            Log.error(GOLDEN_BEAN_BLACKLIST_MODULE, "金猫矿工首页缺少enabled raw=$indexResponse")
            return false
        }
        if (!indexResponse.optBoolean("enabled", false)) {
            Log.goldenBean("金猫矿工[服务端未启用]")
            return true
        }

        val minerInfo = indexResponse.optJSONObject("minerInfo") ?: run {
            Log.error(GOLDEN_BEAN_BLACKLIST_MODULE, "金猫矿工首页缺少minerInfo raw=$indexResponse")
            return false
        }
        val taskProgress = minerInfo.optJSONObject("taskProgress") ?: run {
            Log.error(GOLDEN_BEAN_BLACKLIST_MODULE, "金猫矿工首页缺少taskProgress raw=$indexResponse")
            return false
        }
        if (!taskProgress.has("canGrab") || !taskProgress.has("remainingTimes")) {
            Log.error(GOLDEN_BEAN_BLACKLIST_MODULE, "金猫矿工首页缺少可抓取状态 raw=$indexResponse")
            return false
        }
        if (!taskProgress.optBoolean("canGrab", false)) {
            Log.goldenBean("金猫矿工[服务端无可抓取次数]")
            return true
        }

        val grabbedItemIds = mutableSetOf<String>()
        val progress = minerInfo.optJSONObject("progress")
        val alreadyGrabbed = progress?.optJSONArray("grabbedItemIds") ?: JSONArray()
        for (index in 0 until alreadyGrabbed.length()) {
            alreadyGrabbed.optString(index).takeIf { it.isNotBlank() }?.let(grabbedItemIds::add)
        }
        val beanItemIds = mutableListOf<String>()
        val items = minerInfo.optJSONObject("currentLevel")?.optJSONArray("items") ?: run {
            Log.error(GOLDEN_BEAN_BLACKLIST_MODULE, "金猫矿工首页缺少items raw=$indexResponse")
            return false
        }
        for (index in 0 until items.length()) {
            val item = items.optJSONObject(index) ?: continue
            val itemId = item.optString("itemId").trim()
            if (item.optString("type") == "BEAN" && itemId.isNotBlank() && itemId !in grabbedItemIds) {
                beanItemIds.add(itemId)
            }
        }

        var candidateIndex = 0
        var remainingTimes = taskProgress.optInt("remainingTimes", 0)
        var canGrab = taskProgress.optBoolean("canGrab", false)
        while (canGrab && remainingTimes > 0) {
            val itemId = beanItemIds.getOrNull(candidateIndex)
            val expectedResult = if (itemId.isNullOrBlank()) "EMPTY" else "BEAN"
            val grabResponse = parseResponse(GoldenBeanRpcCall.minerGrab(expectedResult, itemId.orEmpty()))
            if (grabResponse == null || !isSuccess(grabResponse)) {
                Log.error(GOLDEN_BEAN_BLACKLIST_MODULE, "金猫矿工抓取失败 raw=${grabResponse ?: "EMPTY"}")
                return false
            }

            val syncResponse = parseResponse(GoldenBeanRpcCall.sync(
                    listOf("JAR_INFO"),
                    sourceOverride = GoldenBeanRpcCall.MINER_SOURCE,
                ))
            if (syncResponse == null || !isSuccess(syncResponse)) {
                Log.error(GOLDEN_BEAN_BLACKLIST_MODULE, "金猫矿工抓取后金豆罐回查失败 raw=${syncResponse ?: "EMPTY"}")
                return false
            }
            if (grabResponse.optBoolean("needAd", false)) {
                Log.goldenBean("金猫矿工[服务端要求广告，保留待人工处理]")
                return false
            }

            if (expectedResult == "BEAN") {
                candidateIndex++
            }
            val updatedProgress = grabResponse.optJSONObject("taskProgress") ?: run {
                Log.error(GOLDEN_BEAN_BLACKLIST_MODULE, "金猫矿工抓取响应缺少taskProgress raw=$grabResponse")
                return false
            }
            if (!updatedProgress.has("canGrab") || !updatedProgress.has("remainingTimes")) {
                Log.error(GOLDEN_BEAN_BLACKLIST_MODULE, "金猫矿工抓取响应缺少可抓取状态 raw=$grabResponse")
                return false
            }
            val updatedRemainingTimes = updatedProgress.optInt("remainingTimes", remainingTimes)
            if (updatedRemainingTimes >= remainingTimes) {
                Log.error(
                    GOLDEN_BEAN_BLACKLIST_MODULE,
                    "金猫矿工抓取后次数未推进 remainingTimes=$remainingTimes->$updatedRemainingTimes raw=$grabResponse",
                )
                return false
            }
            remainingTimes = updatedRemainingTimes
            canGrab = updatedProgress.optBoolean("canGrab", false)
        }

        val finalResponse = parseResponse(GoldenBeanRpcCall.minerIndex())
        if (finalResponse == null || !isSuccess(finalResponse)) {
            Log.error(GOLDEN_BEAN_BLACKLIST_MODULE, "金猫矿工最终回查失败 raw=${finalResponse ?: "EMPTY"}")
            return false
        }
        val finalProgress = finalResponse.optJSONObject("minerInfo")?.optJSONObject("taskProgress")
        if (finalProgress == null ||
            !finalProgress.has("canGrab") ||
            !finalProgress.has("remainingTimes")
        ) {
            Log.error(GOLDEN_BEAN_BLACKLIST_MODULE, "金猫矿工最终回查缺少可抓取状态 raw=$finalResponse")
            return false
        }
        Log.goldenBean(
            "金猫矿工最终回查 canGrab=${finalProgress.optBoolean("canGrab", false)} " +
                "remainingTimes=${finalProgress.optInt("remainingTimes", -1)}",
        )
        return !finalProgress.optBoolean("canGrab", false) || finalProgress.optInt("remainingTimes", -1) == 0
    }

    private fun logMallItems(
        items: JSONArray,
        listType: String,
    ) {
        for (index in 0 until items.length()) {
            val item = items.optJSONObject(index) ?: continue
            val itemId =
                item.optString("spuId")
                    .ifBlank { item.optString("itemId") }
                    .ifBlank { item.optString("id") }
            val skus = item.optJSONArray("skuModelList") ?: JSONArray()
            for (skuIndex in 0 until maxOf(skus.length(), 1)) {
                val sku = skus.optJSONObject(skuIndex)
                val price = sku?.optJSONObject("price") ?: item.optJSONObject("minPrice")
                Log.goldenBean(
                    "金豆夺宝商城[${listType}只读] itemId=${itemId.ifBlank { "UNKNOWN" }} " +
                        "itemStatus=${item.optString("itemStatus").ifBlank { "UNKNOWN" }} " +
                        "skuId=${sku?.optString("skuId").orEmpty().ifBlank { "UNKNOWN" }} " +
                        "skuStatus=${sku?.optString("skuRuleResult").orEmpty().ifBlank { "UNKNOWN" }} " +
                        "stock=${item.optInt("remainStockCounts", -1)} priceCent=${price?.optLong("cent", -1L)}",
                )
            }
        }
    }

    internal fun actionResult(
        item: TaskFlowItem,
        response: JSONObject,
        action: String,
    ): TaskFlowActionResult {
        if (isSuccess(response)) {
            return TaskFlowActionResult.success(
                refreshAfterAction = true,
                progressChanged = false,
            )
        }
        val code = extractFailureCode(response)
        val failureType =
            when {
                code in unsupportedCodes -> TaskRpcFailureType.UNSUPPORTED_NO_CLOSURE
                code in invalidCodes -> TaskRpcFailureType.NON_RETRYABLE_INVALID
                code in retryableCodes || response.optBoolean("retryable", false) || response.optBoolean("retriable", false) -> {
                    TaskRpcFailureType.RETRYABLE_RPC
                }

                else -> TaskRpcFailureType.UNKNOWN_NEEDS_REVIEW
            }
        return TaskFlowActionResult.failure(
            failureType = failureType,
            code = code,
            message = extractFailureMessage(response),
            rpc = "GoldenBeanRpcCall.$action",
            raw = response.toString(),
            detail = "taskId=${item.type.ifBlank { item.id }} actionType=${item.actionType.ifBlank { "UNKNOWN" }} " +
                "sceneCode=${item.sceneCode.ifBlank { "UNKNOWN" }}",
            continueCurrentRoundOnFailure = failureType == TaskRpcFailureType.RETRYABLE_RPC,
        )
    }

    internal fun emptyResponseFailure(
        item: TaskFlowItem,
        action: String,
    ): TaskFlowActionResult =
        TaskFlowActionResult.failure(
            failureType = TaskRpcFailureType.RETRYABLE_RPC,
            message = "RPC返回空",
            rpc = "GoldenBeanRpcCall.$action",
            detail = "taskId=${item.type.ifBlank { item.id }} actionType=${item.actionType.ifBlank { "UNKNOWN" }} " +
                "sceneCode=${item.sceneCode.ifBlank { "UNKNOWN" }}",
            continueCurrentRoundOnFailure = true,
        )

    internal fun missingTaskTypeFailure(
        item: TaskFlowItem,
        action: String,
    ): TaskFlowActionResult =
        TaskFlowActionResult.failure(
            failureType = TaskRpcFailureType.UNKNOWN_NEEDS_REVIEW,
            message = "缺少服务端taskId",
            rpc = "GoldenBeanRpcCall.$action",
            raw = item.raw?.toString().orEmpty(),
            detail = "taskId=${item.id.ifBlank { "UNKNOWN" }} actionType=${item.actionType.ifBlank { "UNKNOWN" }} " +
                "sceneCode=${item.sceneCode.ifBlank { "UNKNOWN" }}",
        )

    private fun extractFailureCode(response: JSONObject): String =
        response.optString("code")
            .ifBlank { response.optString("resultCode") }
            .ifBlank { response.optString("errorCode") }

    private fun extractFailureMessage(response: JSONObject): String =
        response.optString("desc")
            .ifBlank { response.optString("resultDesc") }
            .ifBlank { response.optString("memo") }

    private fun isTodaySigned(response: JSONObject?): Boolean {
        val signInfo = response?.optJSONObject("signInfo") ?: return false
        if (signInfo.optBoolean("todaySigned", false)) {
            return true
        }
        val signList = signInfo.optJSONArray("signList") ?: return false
        for (index in 0 until signList.length()) {
            val sign = signList.optJSONObject(index) ?: continue
            if (sign.optBoolean("today", false) && sign.optBoolean("signed", false)) {
                return true
            }
        }
        return false
    }
}
