package io.github.aoguai.sesameag.task.customTasks

import io.github.aoguai.sesameag.data.Config
import io.github.aoguai.sesameag.hook.ApplicationHook
import io.github.aoguai.sesameag.model.Model
import io.github.aoguai.sesameag.task.EcoProtection.EcoProtection
import io.github.aoguai.sesameag.task.ModelTask
import io.github.aoguai.sesameag.task.antCooperate.AntCooperate
import io.github.aoguai.sesameag.task.antDodo.AntDodo
import io.github.aoguai.sesameag.task.antFarm.AntFarm
import io.github.aoguai.sesameag.task.antForest.AntForest
import io.github.aoguai.sesameag.task.antForestPatrol.AntForestPatrol
import io.github.aoguai.sesameag.task.antMember.AntMember
import io.github.aoguai.sesameag.task.antOcean.AntOcean
import io.github.aoguai.sesameag.task.antOrchard.AntOrchard
import io.github.aoguai.sesameag.task.goldenBean.GoldenBeanTreasure
import io.github.aoguai.sesameag.task.antSesameCredit.AntSesameCredit
import io.github.aoguai.sesameag.task.antSports.AntSports
import io.github.aoguai.sesameag.task.antStall.AntStall
import io.github.aoguai.sesameag.task.greenFinance.GreenFinance
import io.github.aoguai.sesameag.task.myBankWelfare.MyBankWelfare
import io.github.aoguai.sesameag.task.reserve.Reserve
import io.github.aoguai.sesameag.task.youthPrivilege.YouthPrivilege
import io.github.aoguai.sesameag.util.GlobalThreadPools
import io.github.aoguai.sesameag.util.Log
import io.github.aoguai.sesameag.util.WorkflowRootGuard
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * 手动任务执行器
 */
object ManualTask {

    /**
     * 手动任务流总开关
     */
    @Volatile
    var isManualEnabled = true

    /**
     * 标记手动任务是否正在运行，用于与自动任务互斥
     */
    @Volatile
    var isManualRunning = false
        private set

    /**
     * 为 Java 提供的非 suspend 启动接口
     */
    @JvmStatic
    @JvmOverloads
    fun runSingle(task: CustomTask, extraParams: Map<String, Any> = emptyMap()) {
        GlobalThreadPools.execute {
            run(listOf(task), extraParams)
        }
    }

    /**
     * 顺序执行选中的手动任务
     */
    suspend fun run(tasks: List<CustomTask>, extraParams: Map<String, Any> = emptyMap()) {
        if (!isManualEnabled) {
            Log.record("ManualTask", "⚠️ 手动任务流总开关已关闭，无法执行")
            return
        }

        if (tasks.isEmpty()) {
            Log.record("ManualTask", "⚠️ 未选中任何子任务")
            return
        }

        if (!WorkflowRootGuard.hasRoot(forceRefresh = true, reason = "manual_task_run")) {
            Log.record("ManualTask", "⛔ 未检测到可用执行权限，手动任务不会执行")
            return
        }
        if (!Config.isLegalAcceptedForCurrentVersion() || !WorkflowRootGuard.isExecutionAllowed()) {
            Log.record("ManualTask", "⛔ 必需权限或使用协议未就绪，手动任务不会执行")
            return
        }

        if (isManualRunning) {
            Log.record("ManualTask", "⚠️ 手动任务已在运行中，请勿重复启动")
            return
        }

        withContext(Dispatchers.IO) {
            try {
                isManualRunning = true
                Log.record("ManualTask", "🚀 开始执行手动任务序列...")

                for (task in tasks) {
                    if (!WorkflowRootGuard.isExecutionAllowed()) {
                        Log.record("ManualTask", "必需权限或使用协议未就绪，已停止后续手动任务")
                        return@withContext
                    }
                    try {
                        Log.record("ManualTask", "⏳ 正在执行: ${task.displayName}...")
                        when (task) {
                            // 森林类任务
                            CustomTask.FOREST_WHACK_MOLE -> {
                                val instance = getForestInstance()
                                if (instance != null) {
                                    instance.manualWhackMole()
                                } else {
                                    Log.record("ManualTask", "❌ 无法加载森林模块")
                                }
                            }

                            CustomTask.FOREST_ENERGY_RAIN -> {
                                val instance = getForestInstance()
                                if (instance != null) {
                                    val exchange = extraParams["exchangeEnergyRainCard"] as? Boolean ?: false
                                    instance.manualUseEnergyRain(exchange)
                                } else {
                                    Log.record("ManualTask", "❌ 无法加载森林模块")
                                }
                            }

                            // 庄园类任务
                            CustomTask.FARM_SEND_BACK_ANIMAL -> getFarmInstance()?.manualSendBackAnimal()
                            CustomTask.FARM_GAME_LOGIC -> getFarmInstance()?.manualFarmGameLogic()
                            CustomTask.FARM_CHOUCHOULE -> getFarmInstance()?.manualChouChouLeLogic()
                            CustomTask.FARM_SPECIAL_FOOD -> {
                                val count = extraParams["specialFoodCount"] as? Int ?: 0
                                getFarmInstance()?.manualUseSpecialFood(count)
                            }
                            CustomTask.FARM_USE_TOOL -> {
                                val toolType = extraParams["toolType"] as? String ?: ""
                                val toolCount = extraParams["toolCount"] as? Int ?: 1
                                getFarmInstance()?.manualUseFarmTool(toolType, toolCount)
                            }

                            // 任务模块整体手动触发：跳过自动调度门控，但保留任务生命周期管理
                            CustomTask.ANT_FOREST -> runModuleTask(AntForest::class.java)
                            CustomTask.ANT_FOREST_PATROL -> runModuleTask(AntForestPatrol::class.java)
                            CustomTask.ANT_FARM -> runModuleTask(AntFarm::class.java)
                            CustomTask.ANT_OCEAN -> runModuleTask(AntOcean::class.java)
                            CustomTask.ANT_STALL -> runModuleTask(AntStall::class.java)
                            CustomTask.ANT_DODO -> runModuleTask(AntDodo::class.java)
                            CustomTask.ANT_COOPERATE -> runModuleTask(AntCooperate::class.java)
                            CustomTask.ANT_MEMBER -> runModuleTask(AntMember::class.java)
                            CustomTask.ANT_SESAME_CREDIT -> runModuleTask(AntSesameCredit::class.java)
                            CustomTask.ANT_ORCHARD -> runModuleTask(AntOrchard::class.java)
                            CustomTask.GOLDEN_BEAN_TREASURE -> runModuleTask(GoldenBeanTreasure::class.java)
                            CustomTask.ANT_SPORTS -> runModuleTask(AntSports::class.java)
                            CustomTask.YOUTH_PRIVILEGE -> runModuleTask(YouthPrivilege::class.java)
                            CustomTask.ECO_PROTECTION -> runModuleTask(EcoProtection::class.java)
                            CustomTask.GREEN_FINANCE -> runModuleTask(GreenFinance::class.java)
                            CustomTask.MY_BANK_WELFARE -> runModuleTask(MyBankWelfare::class.java)
                            CustomTask.RESERVE -> runModuleTask(Reserve::class.java)
                        }
                    } catch (e: CancellationException) {
                        Log.record("ManualTask", "⏹️ 手动任务 ${task.displayName} 已取消")
                        throw e
                    } catch (t: Throwable) {
                        Log.record("ManualTask", "❌ 执行 ${task.displayName} 出错: ${t.message}")
                        Log.printStackTrace(t)
                    }
                }
                Log.record("ManualTask", "✅ 手动任务执行完毕")
            } finally {
                isManualRunning = false
            }
        }
    }

    /**
     * 按需获取并确保蚂蚁森林实例已加载
     */
    private fun getForestInstance(): AntForest? {
        AntForest.instance?.let { return it }
        val loader = ApplicationHook.classLoader ?: return null
        Model.getModel(AntForest::class.java)?.let {
            Log.record("ManualTask", "⚙️ 正在按需加载森林模块...")
            it.ensureBooted(loader)
        }
        return AntForest.instance
    }

    /**
     * 按需获取并确保蚂蚁庄园实例已加载
     */
    private fun getFarmInstance(): AntFarm? {
        AntFarm.instance?.let { return it }
        val loader = ApplicationHook.classLoader ?: return null
        Model.getModel(AntFarm::class.java)?.let {
            Log.record("ManualTask", "⚙️ 正在按需加载庄园模块...")
            it.ensureBooted(loader)
        }
        return AntFarm.instance
    }

    /**
     * 手动触发任务模块整体执行：跳过自动调度门控，但保留任务生命周期和停止语义。
     * 适用于风控后手动重跑单个模块，无需等待自动调度。
     */
    private suspend fun <T : ModelTask> runModuleTask(clazz: Class<T>) {
        val loader = ApplicationHook.classLoader
        if (loader == null) {
            Log.record("ManualTask", "❌ 无法加载 ${clazz.simpleName} 模块：ClassLoader 不可用")
            return
        }

        val instance = Model.getModel(clazz)
        if (instance == null) {
            Log.record("ManualTask", "❌ 无法加载 ${clazz.simpleName} 模块")
            return
        }

        instance.ensureBooted(loader)
        val job = instance.startManualTask(rounds = 1)
        if (job == null) {
            Log.record("ManualTask", "⚠️ ${instance.getName()} 正在运行或等待启动，跳过本次手动执行")
            return
        }
        job.join()
    }
}

