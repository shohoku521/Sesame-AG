package io.github.aoguai.sesameag.task.antDodo


import io.github.aoguai.sesameag.task.antFarm.AntFarmRpcCall

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.runInterruptible
import org.json.JSONException
import org.json.JSONArray
import org.json.JSONObject
import io.github.aoguai.sesameag.entity.friend.FriendCapabilityState
import io.github.aoguai.sesameag.data.Status
import io.github.aoguai.sesameag.data.StatusFlags
import io.github.aoguai.sesameag.hook.AccountSessionCoordinator
import io.github.aoguai.sesameag.hook.ApplicationHook
import io.github.aoguai.sesameag.hook.keepalive.PersistentScheduleDefaults
import io.github.aoguai.sesameag.hook.keepalive.PersistentScheduleKind
import io.github.aoguai.sesameag.hook.keepalive.PersistentScheduleRegistry
import io.github.aoguai.sesameag.hook.keepalive.PersistentScheduleState
import io.github.aoguai.sesameag.hook.keepalive.UnifiedScheduler
import io.github.aoguai.sesameag.model.BaseModel
import io.github.aoguai.sesameag.model.ModelFields
import io.github.aoguai.sesameag.model.ModelGroup
import io.github.aoguai.sesameag.model.withDesc
import io.github.aoguai.sesameag.model.modelFieldExt.BooleanModelField
import io.github.aoguai.sesameag.model.modelFieldExt.ChoiceModelField
import io.github.aoguai.sesameag.model.modelFieldExt.FriendSelectionModelField
import io.github.aoguai.sesameag.task.ModelTask
import io.github.aoguai.sesameag.task.TaskCommon
import io.github.aoguai.sesameag.task.TaskExecutionOutcome
import io.github.aoguai.sesameag.task.TaskStatus
import io.github.aoguai.sesameag.task.common.DeferredReason
import io.github.aoguai.sesameag.task.common.TaskFlowAction
import io.github.aoguai.sesameag.task.common.TaskFlowActionResult
import io.github.aoguai.sesameag.task.common.TaskFlowAdapter
import io.github.aoguai.sesameag.task.common.TaskFlowEngine
import io.github.aoguai.sesameag.task.common.TaskFlowExecutionState
import io.github.aoguai.sesameag.task.common.TaskFlowSnapshot
import io.github.aoguai.sesameag.task.common.TaskFlowItem
import io.github.aoguai.sesameag.task.common.TaskFlowRunResult
import io.github.aoguai.sesameag.task.common.TaskFlowPhase
import io.github.aoguai.sesameag.task.common.TaskRpcFailureType
import io.github.aoguai.sesameag.task.common.GameCenterPlayRpcCall
import io.github.aoguai.sesameag.task.common.NonDurationGameTask
import io.github.aoguai.sesameag.task.exchange.ExchangeEffectNeed
import io.github.aoguai.sesameag.task.exchange.ExchangeReplenishResult
import io.github.aoguai.sesameag.task.exchange.ExchangeReplenisher
import io.github.aoguai.sesameag.util.FriendGuard
import io.github.aoguai.sesameag.util.Log
import io.github.aoguai.sesameag.util.maps.UserMap
import io.github.aoguai.sesameag.util.ResChecker
import io.github.aoguai.sesameag.util.UserDataStoreManager
import io.github.aoguai.sesameag.util.SerialTaskQueue
import io.github.aoguai.sesameag.util.friend.FriendCapabilityRecorder

class AntDodo : ModelTask() {
    private data class CollectToFriendResult(
        val progressed: Boolean,
        val remainingCount: Int?,
    ) {
        val completed: Boolean
            get() = remainingCount == 0
    }

    private var collectToFriend: BooleanModelField? = null
    private var collectToFriendType: ChoiceModelField? = null
    private var collectToFriendList: FriendSelectionModelField? = null
    private var sendFriendCard: FriendSelectionModelField? = null
    private var useProp: BooleanModelField? = null
    private var usePropCollectTimes7Days: BooleanModelField? = null
    private var usePropCollectHistoryAnimal7Days: BooleanModelField? = null
    private var usePropCollectToFriendTimes7Days: BooleanModelField? = null
    private var autoGenerateBook: BooleanModelField? = null
    private var scratchCard: BooleanModelField? = null
    private val loggedTaskProgressHints = LinkedHashSet<String>()
    private var taskListRefreshNeeded = false
    private val taskWorkflowQueue = SerialTaskQueue()

    override fun getName(): String = "神奇物种"

    override fun getGroup(): ModelGroup = ModelGroup.DODO

    override fun getIcon(): String = "AntDodo.png"

    override fun getFields(): ModelFields {
        val modelFields = ModelFields()
        modelFields.addField(
            BooleanModelField("collectToFriend", "帮抽卡 | 开启", false).withDesc(
                "开启后按“帮抽卡 | 动作”和“帮抽卡 | 好友列表”帮好友抽神奇物种卡片。"
            ).also { collectToFriend = it }
        )
        modelFields.addField(
            ChoiceModelField(
                "collectToFriendType",
                "帮抽卡 | 动作",
                CollectToFriendType.COLLECT,
                CollectToFriendType.nickNames
            ).withDesc("选择名单解释方式：仅帮选中好友抽卡，或跳过选中好友。需开启“帮抽卡 | 开启”。").also {
                collectToFriendType = it
            }
        )
        modelFields.addField(
            FriendSelectionModelField(
                "collectToFriendList",
                "帮抽卡 | 好友列表"
            ).withDesc("设置帮抽卡规则作用的好友名单。").also { collectToFriendList = it }
        )
        modelFields.addField(
            FriendSelectionModelField(
                "sendFriendCard",
                "赠送卡片 | 好友列表"
            ).withDesc("列表不为空时，会把当前图鉴可赠送的冗余卡片送给列表中的首个有效好友，并始终保留每张卡至少1张；缺卡时可通过换卡等途径补齐至多两张。").also {
                sendFriendCard = it
            }
        )
        modelFields.addField(
            BooleanModelField("useProp", "道具 | 使用全部", false).withDesc(
                "自动使用当前可消费的神奇物种道具，对所有支持的道具类型生效。"
            ).also { useProp = it }
        )
        modelFields.addField(
            BooleanModelField("usePropCollectTimes7Days", "道具 | 抽卡道具", false).withDesc(
                "单独开启后使用抽卡类道具；开启“道具 | 使用全部”时也会一起生效。"
            ).also { usePropCollectTimes7Days = it }
        )
        modelFields.addField(
            BooleanModelField("usePropCollectHistoryAnimal7Days", "道具 | 抽历史卡道具", false).withDesc(
                "单独开启后使用历史卡抽卡道具；开启“道具 | 使用全部”时也会一起生效。"
            ).also { usePropCollectHistoryAnimal7Days = it }
        )
        modelFields.addField(
            BooleanModelField("usePropCollectToFriendTimes7Days", "道具 | 抽好友卡道具", false).withDesc(
                "单独开启后使用好友卡抽卡道具；开启“道具 | 使用全部”时也会一起生效。"
            ).also { usePropCollectToFriendTimes7Days = it }
        )
        modelFields.addField(
            BooleanModelField("scratchCard", "自动刮卡", false).withDesc(
                "刮开可刮卡片领取奖励，先刮卡再赠送、交换或合成勋章。"
            ).also { scratchCard = it }
        )
        modelFields.addField(
            BooleanModelField("autoGenerateBook", "图鉴勋章 | 自动合成", false).withDesc(
                "图鉴显示“已集齐”时自动合成对应勋章。"
            ).also { autoGenerateBook = it }
        )
        return modelFields
    }

    override fun check(): Boolean {
        return when {
            TaskCommon.IS_ENERGY_TIME -> {
                Log.dodo("⏸ 当前为只收能量时间【${BaseModel.energyTime.value}】，停止执行${getName()}任务！")
                false
            }
            TaskCommon.IS_MODULE_SLEEP_TIME -> {
                Log.dodo("💤 模块休眠时间【${BaseModel.modelSleepTime.value}】停止执行${getName()}任务！")
                false
            }
            else -> true
        }
    }

    override fun runJava(): Unit = taskWorkflowQueue.execute {
        try {
            Log.dodo("执行开始-${getName()}")
            loggedTaskProgressHints.clear()
            val executionState = TaskFlowExecutionState()
            taskListRefreshNeeded = false
            receiveTaskAward(executionState)
            collect()
            if (scratchCard?.value == true) {
                try {
                    val home = JSONObject(AntDodoRpcCall.homePage())
                    if (ResChecker.checkRes(TAG, home)) {
                        val collections = home.optJSONObject("data")?.optJSONArray("curCollection")
                        for (i in 0 until (collections?.length() ?: 0)) {
                            collections?.optJSONObject(i)?.let { scratchAnimalCards(it) }
                        }
                    }
                } catch (t: Throwable) {
                    Log.printStackTrace(TAG, "神奇物种待刮卡查询失败：", t)
                }
            }
            if (collectToFriend?.value == true) {
                if (hasPendingCollectToFriendSchedule()) {
                    Log.dodo("神奇物种帮抽卡已有有效持久调度，跳过常规重复查询")
                } else {
                    var friendCollectPasses = 0
                    while (friendCollectPasses < 2) {
                        if (!collectToFriend().progressed) {
                            break
                        }
                        friendCollectPasses++
                    }
                }
            }
            sendAntDodoCard()
            propList()
            if (autoGenerateBook?.value == true) {
                autoGenerateBook()
            }
            if (taskListRefreshNeeded) receiveTaskAward(executionState)
        } catch (t: Throwable) {
            Log.runtime(TAG, "start.run err:")
            Log.printStackTrace(TAG, t)
        } finally {
            Log.dodo("执行结束-${getName()}")
        }
    }

    private fun collect() {
        if (Status.hasFlagToday(StatusFlags.FLAG_ANTDODO_DAILY_COLLECT_DONE)) {
            Log.dodo("神奇物种卡片今日已收集，跳过重复查询")
            return
        }
        try {
            val response = AntDodoRpcCall.queryAnimalStatus()
            if (response.isNullOrEmpty()) {
                Log.runtime(TAG, "queryAnimalStatus返回空")
                return
            }
            val jo = JSONObject(response)
            if (ResChecker.checkRes(TAG, jo)) {
                val data = jo.getJSONObject("data")
                if (data.getBoolean("collect")) {
                    Status.setFlagToday(StatusFlags.FLAG_ANTDODO_DAILY_COLLECT_DONE)
                    Log.dodo("神奇物种卡片今日收集完成！")
                } else {
                    if (collectAnimalCard()) {
                        confirmDailyCollectDone()
                    }
                }
            } else {
                Log.runtime(TAG, jo.getString("resultDesc"))
            }
        } catch (t: Throwable) {
            Log.runtime(TAG, "AntDodo Collect err:")
            Log.printStackTrace(TAG, t)
        }
    }

    private fun confirmDailyCollectDone() {
        val response = AntDodoRpcCall.queryAnimalStatus()
        if (response.isNullOrEmpty()) {
            Log.runtime(TAG, "神奇物种卡片收集后queryAnimalStatus返回空")
            return
        }
        val result = JSONObject(response)
        if (!ResChecker.checkRes(TAG, result)) {
            Log.runtime(TAG, "神奇物种卡片收集后状态确认失败:${result.optString("resultDesc")}")
            return
        }
        val data = result.optJSONObject("data")
        if (data?.optBoolean("collect") == true) {
            Status.setFlagToday(StatusFlags.FLAG_ANTDODO_DAILY_COLLECT_DONE)
            Log.dodo("神奇物种卡片今日收集完成！")
        }
    }

    private fun scratchAnimalCards(collection: JSONObject): Boolean {
        if (scratchCard?.value != true) return true
        return try {
            val cards = collection.optJSONObject("collectDetail")?.optJSONArray("cardList") ?: JSONArray()
            val animal = collection.optJSONObject("animal") ?: return cards.length() == 0
            val animalId = animal.getString("animalId")
            val bookId = animal.getString("bookId")
            if (animalId.isBlank() || bookId.isBlank()) {
                Log.error(TAG, "神奇物种刮卡缺少动物或图鉴标识")
                return false
            }
            // 刮卡待确认属于账号私有消费状态，跨轮次保留，不随配置导出或日标重置。
            val store = UserDataStoreManager.getCurrentInstance() ?: return false
            val pendingKey = "antDodoScratchPending"
            val rewards = store.getOrCreate<MutableMap<String, Int>>(pendingKey)
            val prefix = "$animalId:"
            var currentCards = (0 until cards.length()).mapNotNull { cards.optJSONObject(it) }
            if (currentCards.any { !it.has("scratchable") || (it.optBoolean("scratchable") && !it.has("scratched")) }) {
                val instanceIds = currentCards.map { it.optString("cardInstanceId") }.toSet()
                val refreshed = JSONObject(AntDodoRpcCall.homePage())
                if (!ResChecker.checkRes(TAG, "神奇物种新卡状态查询失败：", refreshed)) return false
                val collections = refreshed.optJSONObject("data")?.optJSONArray("curCollection")
                val detail = (0 until (collections?.length() ?: 0)).mapNotNull { collections?.optJSONObject(it) }
                    .firstOrNull { it.optJSONObject("animal")?.optString("animalId") == animalId }
                    ?.optJSONObject("collectDetail")
                val refreshedCards = detail?.optJSONArray("cardList")
                val resolved = (0 until (refreshedCards?.length() ?: 0)).mapNotNull { refreshedCards?.optJSONObject(it) }
                if (instanceIds.any { id -> id.isBlank() || resolved.none { it.optString("cardInstanceId") == id } } ||
                    resolved.any { !it.has("scratchable") || (it.optBoolean("scratchable") && !it.has("scratched")) }
                ) {
                    Log.error(TAG, "神奇物种新卡状态尚未完整返回，保留卡片：$animalId")
                    return false
                }
                collection.put("collectDetail", detail)
                currentCards = resolved
            }
            val pending = currentCards.filter { it.optBoolean("scratchable") && !it.optBoolean("scratched") }
            if (pending.isEmpty() && rewards.keys.none { it.startsWith(prefix) }) return true
            for (card in pending) {
                if (Thread.currentThread().isInterrupted) return false
                val instanceId = card.optString("cardInstanceId")
                if (instanceId.isBlank()) {
                    Log.error(TAG, "神奇物种刮卡缺少卡片实例：$animalId")
                    return false
                }
                val key = prefix + instanceId
                if (rewards.containsKey(key)) continue
                rewards[key] = -1
                store.put(pendingKey, rewards, requirePersistence = true)
                val result = JSONObject(AntDodoRpcCall.scratchCard(animalId, bookId, instanceId))
                if (!ResChecker.checkRes(TAG, "神奇物种刮卡失败：", result)) {
                    if (result.opt("success") == false) {
                        rewards.remove(key)
                        store.put(pendingKey, rewards)
                    }
                    return false
                }
                rewards[key] = (result.optJSONObject("data")?.opt("energyGram") as? Number)?.toInt() ?: -1
                store.put(pendingKey, rewards)
            }
            val refreshed = JSONObject(AntDodoRpcCall.homePage())
            if (!ResChecker.checkRes(TAG, "神奇物种刮卡状态查询失败：", refreshed)) return false
            val animals = refreshed.getJSONObject("data").getJSONArray("curCollection")
            val detail = (0 until animals.length()).mapNotNull { animals.optJSONObject(it) }
                .firstOrNull { it.optJSONObject("animal")?.optString("animalId") == animalId }
                ?.optJSONObject("collectDetail")
            val refreshedCards = detail?.optJSONArray("cardList")
            val scratchedIds = (0 until (refreshedCards?.length() ?: 0))
                .mapNotNull { refreshedCards?.optJSONObject(it) }
                .filter { it.optBoolean("scratched") }
                .map { it.optString("cardInstanceId") }.toSet()
            val confirmed = scratchedIds.map { prefix + it }.filter { rewards.containsKey(it) }
            if (confirmed.isNotEmpty()) {
                val energy = confirmed.map { rewards.getValue(it) }
                val rewardText = if (energy.all { it >= 0 }) "，获得${energy.sum()}g能量" else ""
                Log.dodo("神奇物种🦕[${animal.optString("name")}]已刮${confirmed.size}张$rewardText")
                confirmed.forEach { rewards.remove(it) }
                store.put(pendingKey, rewards)
            }
            if (detail == null || rewards.keys.any { it.startsWith(prefix) }) {
                Log.error(TAG, "神奇物种刮卡状态尚未确认，保留卡片：$animalId")
                return false
            }
            collection.put("collectDetail", detail)
            true
        } catch (t: Throwable) {
            Log.printStackTrace(TAG, "神奇物种刮卡失败：", t)
            false
        }
    }

    /** 上次卡背刮奖观察快照，状态变化时才记日志 */
    private var lastScratchObservation: String? = null

    private fun observeScratchableCards(data: JSONObject?) {
        try {
            val curCollection = data?.optJSONArray("curCollection") ?: return
            var scratchableCount = 0
            var unscratchedCount = 0
            var unscratchedEnergyGram = 0
            for (i in 0 until curCollection.length()) {
                val cardList = curCollection.optJSONObject(i)
                    ?.optJSONObject("collectDetail")
                    ?.optJSONArray("cardList") ?: continue
                for (j in 0 until cardList.length()) {
                    val card = cardList.optJSONObject(j) ?: continue
                    if (!card.optBoolean("scratchable", false)) {
                        continue
                    }
                    scratchableCount++
                    if (!card.optBoolean("scratched", false)) {
                        unscratchedCount++
                        unscratchedEnergyGram += card.optInt("energyGram", 0)
                    }
                }
            }
            if (scratchableCount == 0) {
                return
            }
            val snapshot = "可刮$scratchableCount 张，未刮$unscratchedCount 张，未刮累计${unscratchedEnergyGram}g"
            if (snapshot == lastScratchObservation) {
                return
            }
            lastScratchObservation = snapshot
            Log.dodo("神奇物种（卡背刮奖）：$snapshot")
        } catch (t: Throwable) {
            Log.printStackTrace(TAG, t)
        }
    }

    private fun collectAnimalCard(): Boolean {
        return try {
            val homeResponse = AntDodoRpcCall.homePage()
            if (homeResponse.isNullOrEmpty()) {
                Log.runtime(TAG, "homePage返回空")
                return false
            }
            var jo = JSONObject(homeResponse)
            var attempted = false
            if (ResChecker.checkRes(TAG, jo)) {
                var data = jo.optJSONObject("data")
                val ja = data?.optJSONArray("limit")
                if (data == null || ja == null) {
                    Log.error(TAG, "神奇物种抽卡首页缺少data/limit raw=$jo")
                    return false
                }
                observeScratchableCards(data)
                var index = -1
                for (i in 0 until ja.length()) {
                    val limit = ja.optJSONObject(i)
                    if (limit == null) {
                        Log.error(TAG, "神奇物种抽卡限额条目格式错误[index=$i] raw=${ja.opt(i)}")
                        continue
                    }
                    jo = limit
                    if ("DAILY_COLLECT" == jo.optString("actionCode")) {
                        index = i
                        break
                    }
                }
                if (index >= 0) {
                    val leftFreeQuota = jo.opt("leftFreeQuota")?.toString()?.toIntOrNull()
                    if (leftFreeQuota == null || leftFreeQuota < 0) {
                        Log.error(TAG, "神奇物种抽卡缺少有效leftFreeQuota raw=$jo")
                        return false
                    }
                    if (leftFreeQuota == 0 &&
                        !Status.hasFlagToday(StatusFlags.FLAG_ANTDODO_CONSECUTIVE_COLLECT_DONE)
                    ) {
                        Status.setFlagToday(StatusFlags.FLAG_ANTDODO_CONSECUTIVE_COLLECT_DONE)
                        taskListRefreshNeeded = true
                    }
                    for (j in 0 until leftFreeQuota) {
                        val collectResponse = AntDodoRpcCall.collect()
                        attempted = true
                        if (collectResponse.isNullOrEmpty()) {
                            Log.runtime(TAG, "collect返回空")
                            continue
                        }
                        jo = JSONObject(collectResponse)
                        if (ResChecker.checkRes(TAG, jo)) {
                            taskListRefreshNeeded = true
                            data = jo.optJSONObject("data")
                            if (data == null) {
                                Log.error(TAG, "神奇物种抽卡响应缺少data，保留后续回查 raw=$jo")
                                break
                            }
                            val animal = data.optJSONObject("animal")
                            val ecosystem = animal?.optString("ecosystem", "未知生态") ?: "未知生态"
                            val name = animal?.optString("name", "未知物种") ?: "未知物种"
                            Log.dodo("神奇物种🦕[$ecosystem]#$name")
                            scratchAnimalCards(data)
                        } else {
                            Log.runtime(TAG, jo.getString("resultDesc"))
                        }
                    }
                }
            } else {
                Log.runtime(TAG, jo.getString("resultDesc"))
            }
            attempted
        } catch (t: Throwable) {
            Log.runtime(TAG, "AntDodo CollectAnimalCard err:")
            Log.printStackTrace(TAG, t)
            false
        }
    }

    private fun receiveTaskAward(executionState: TaskFlowExecutionState = TaskFlowExecutionState()): TaskFlowRunResult? {
        return try {
            taskListRefreshNeeded = false
            TaskFlowEngine(DodoTaskFlowAdapter(), roundSleepMs = 425L, executionState = executionState).run()
        } catch (e: JSONException) {
            Log.error(TAG, "JSON解析错误: ${e.message}")
            Log.printStackTrace(TAG, e)
            null
        } catch (t: Throwable) {
            if (t is CancellationException || t is InterruptedException) throw t
            Log.runtime(TAG, "AntDodo ReceiveTaskAward 错误:")
            Log.printStackTrace(TAG, t)
            null
        }
    }

    internal fun triggerPersistentTaskFlow(payloadJson: String, scheduleId: String, source: String): Boolean {
        val payload = runCatching { JSONObject(payloadJson.ifBlank { "{}" }) }.getOrDefault(JSONObject())
        return executePersistentChild(
            scheduleId = scheduleId,
            ownerUserId = payload.optString("owner_user_id").trim(),
            sessionEpoch = payload.optLong("session_epoch", 0L),
            source = "$PERSISTENT_CHILD_KIND:$source",
            workflowQueue = taskWorkflowQueue,
        ) {
            if (!isEnable()) return@executePersistentChild TaskExecutionOutcome.SKIPPED
            val result = receiveTaskAward() ?: return@executePersistentChild TaskExecutionOutcome.FAILED
            when {
                result.interrupted -> TaskExecutionOutcome.CANCELLED
                result.failureCount > 0 -> TaskExecutionOutcome.FAILED
                result.completed -> TaskExecutionOutcome.SUCCESS
                else -> TaskExecutionOutcome.DEFERRED
            }
        }
    }

    private fun buildTaskKey(sceneCode: String, taskType: String): String {
        return "$sceneCode|$taskType"
    }

    private inner class DodoTaskFlowAdapter : TaskFlowAdapter {
        override val moduleName: String = TASK_BLACKLIST_MODULE
        override val flowName: String = "神奇物种任务"
        override val nonRetryableActionFlagPrefix: String = StatusFlags.FLAG_ANTDODO_TASK_ACTION_STOP_PREFIX

        override fun isFlowHandledToday(): Boolean = Status.hasFlagToday(StatusFlags.FLAG_ANTDODO_TASKS_DONE)

        override fun onAllTasksDone(snapshot: TaskFlowSnapshot) {
            Status.setFlagToday(StatusFlags.FLAG_ANTDODO_TASKS_DONE)
        }

        override fun shouldSkipByTodayState(item: TaskFlowItem): Boolean =
            item.type == "CONTINUOUS_COLLECT_TIMES_7" &&
                item.status in setOf(TaskStatus.TODO.name, "WAIT_COMPLETE") &&
                item.current != null && item.limit != null && item.current < item.limit &&
                Status.hasFlagToday(StatusFlags.FLAG_ANTDODO_CONSECUTIVE_COLLECT_DONE)

        override fun query(): JSONObject {
            val response = AntDodoRpcCall.taskList()
            if (response.isNullOrEmpty()) {
                return JSONObject()
                    .put("success", false)
                    .put("resultDesc", "taskList返回空")
            }
            return JSONObject(response)
        }

        override fun isQuerySuccess(response: JSONObject): Boolean {
            return ResChecker.checkRes(TAG, response) &&
                response.optJSONObject("data")?.optJSONArray("taskGroupInfoList") != null
        }

        override fun extractItems(response: JSONObject): List<TaskFlowItem> {
            val taskGroupInfoList = response.optJSONObject("data")?.optJSONArray("taskGroupInfoList")
                ?: return emptyList()
            val items = mutableListOf<TaskFlowItem>()
            for (i in 0 until taskGroupInfoList.length()) {
                val taskGroup = taskGroupInfoList.optJSONObject(i) ?: continue
                val taskInfoList = taskGroup.optJSONArray("taskInfoList") ?: continue
                for (j in 0 until taskInfoList.length()) {
                    val taskInfo = taskInfoList.optJSONObject(j) ?: continue
                    val taskBaseInfo = taskInfo.optJSONObject("taskBaseInfo") ?: continue
                    val bizInfo = parseDodoBizInfo(taskBaseInfo.opt("bizInfo"))
                    val taskType = taskBaseInfo.optString("taskType").trim()
                    if (taskType.isBlank()) {
                        continue
                    }
                    val taskTitle = bizInfo.optString("taskTitle", taskType).trim().ifBlank { taskType }
                    val sceneCode = taskBaseInfo.optString("sceneCode").trim()
                    val taskStatus = taskBaseInfo.optString("taskStatus").trim()
                    val awardCount = bizInfo.optString("awardCount", "1").trim().ifBlank { "1" }
                    val taskProgress = parseDodoTaskProgressInt(taskBaseInfo, "taskProgress")
                    val taskRequire = parseDodoTaskProgressInt(taskBaseInfo, "taskRequire")?.takeIf { it > 0 }
                    if (taskType == "CONTINUOUS_COLLECT_TIMES_7" &&
                        taskProgress != null && taskRequire != null && taskProgress < taskRequire &&
                        taskBaseInfo.optBoolean("curCycleFinished")
                    ) {
                        Status.setFlagToday(StatusFlags.FLAG_ANTDODO_CONSECUTIVE_COLLECT_DONE)
                    }
                    val raw = JSONObject()
                        .put("taskGroupId", taskGroup.optString("taskGroupId"))
                        .put("taskInfo", taskInfo)
                        .put("taskBaseInfo", taskBaseInfo)
                        .put("bizInfo", bizInfo)
                        .put("taskKey", buildTaskKey(sceneCode, taskType))
                        .put("awardCount", awardCount)

                    items.add(
                        TaskFlowItem(
                            id = taskType,
                            title = taskTitle,
                            status = taskStatus,
                            type = taskType,
                            sceneCode = sceneCode,
                            actionType = taskBaseInfo.optString("actionType")
                                .ifBlank { bizInfo.optString("actionType") },
                            blacklistKeys = listOf(taskType, taskTitle).filter { it.isNotBlank() },
                            raw = raw,
                            progress = "award=$awardCount progress=${taskProgress ?: 0}/${taskRequire ?: 0} " +
                                "entity=${taskBaseInfo.optLong("entityGenerateTime")}:${taskBaseInfo.optLong("entityExpireTime")}:" +
                                "${taskBaseInfo.optString("taskMode")}:${taskBaseInfo.optBoolean("reDecision")}",
                            current = taskProgress,
                            limit = taskRequire
                        )
                    )
                }
            }
            return items
        }

        override fun mapPhase(item: TaskFlowItem): TaskFlowPhase {
            if (item.type == "CONTINUOUS_COLLECT_TIMES_7" &&
                item.status in setOf(TaskStatus.TODO.name, "WAIT_COMPLETE")
            ) {
                return mapConsecutiveCollectPhase(item)
            }
            return when (item.status) {
                TaskStatus.FINISHED.name,
                "COMPLETE",
                "WAIT_RECEIVE",
                "TO_RECEIVE" -> TaskFlowPhase.REWARD_READY

                TaskStatus.TODO.name,
                "WAIT_COMPLETE" -> if (item.type in BUSINESS_DRIVEN_TASK_TYPES) {
                    TaskFlowPhase.BUSINESS_ACTION
                } else {
                    TaskFlowPhase.READY_TO_COMPLETE
                }

                TaskStatus.RECEIVED.name,
                "HAS_RECEIVED",
                "DONE",
                "COMPLETED" -> TaskFlowPhase.TERMINAL

                else -> TaskFlowPhase.UNKNOWN
            }
        }

        override fun receive(item: TaskFlowItem): TaskFlowActionResult {
            val response = AntDodoRpcCall.receiveTaskAward(item.sceneCode, item.type)
            if (response.isNullOrEmpty()) {
                return emptyActionResponse("AntDodoRpcCall.receiveTaskAward", item, "receiveTaskAward")
            }
            val result = JSONObject(response)
            if (isDodoTaskRpcSuccess(result)) {
                val awardCount = item.raw?.optString("awardCount", "1") ?: "1"
                Log.dodo("任务奖励🎖️[${item.title}]#${awardCount}个")
                return TaskFlowActionResult.success(progressChanged = false)
            }
            return dodoActionFailureResult(
                response = result,
                rpc = "AntDodoRpcCall.receiveTaskAward",
                detail = dodoActionDetail(item, "receiveTaskAward")
            )
        }

        override fun complete(item: TaskFlowItem): TaskFlowActionResult {
            val raw = item.raw ?: return missingRawResult(item, "finishTask")
            val taskBaseInfo = raw.optJSONObject("taskBaseInfo") ?: return missingRawResult(item, "finishTask")
            val decision = GameCenterPlayRpcCall.resolveTaskAction(
                taskBaseInfo, raw.optJSONObject("bizInfo"), directFinishSupported = true,
            )
            if (decision.action == GameCenterPlayRpcCall.TaskAction.DIRECT_FINISH &&
                shouldMaterializeManualTask(raw, taskBaseInfo)
            ) {
                val groupId = raw.optString("taskGroupId").trim()
                if (groupId.isBlank()) {
                    return missingRawResult(item, "reDecisionTaskOpenGreen")
                }
                val response = AntDodoRpcCall.reDecisionTaskOpenGreen(groupId, item.type)
                if (response.isNullOrEmpty()) {
                    return emptyActionResponse(
                        "AntDodoRpcCall.reDecisionTaskOpenGreen",
                        item,
                        "reDecisionTaskOpenGreen"
                    )
                }
                val result = JSONObject(response)
                if (isDodoTaskRpcSuccess(result)) {
                    Log.dodo("物种任务显化🧾️[${item.title}]")
                    return TaskFlowActionResult.success(refreshAfterAction = true, progressChanged = false)
                }
                return dodoActionFailureResult(
                    response = result,
                    rpc = "AntDodoRpcCall.reDecisionTaskOpenGreen",
                    detail = dodoActionDetail(item, "reDecisionTaskOpenGreen")
                )
            }
            when (decision.action) {
                GameCenterPlayRpcCall.TaskAction.DURATION_ONLY -> {
                    val contract = decision.contract ?: return missingRawResult(item, "playDuration")
                    val duration = GameCenterPlayRpcCall.advanceDuration(
                        "dodo_game:${item.sceneCode}:${item.id}:${item.progress}", contract,
                    )
                    if (!duration.success || duration.deferredReason != null) return duration
                }
                GameCenterPlayRpcCall.TaskAction.LEGACY_EXTERNAL_REPORT -> {
                    val game = decision.mappedTask ?: return missingRawResult(item, "externalGame")
                    return runBlocking {
                        NonDurationGameTask.advance(game, item.raw,
                            detail = dodoActionDetail(item, "externalGame"), logger = Log::dodo)
                    }
                }
                GameCenterPlayRpcCall.TaskAction.DEFERRED -> return TaskFlowActionResult.defer(
                    DeferredReason.PREREQUISITE_PENDING, decision.reason,
                    detail = dodoActionDetail(item, "finishTask"),
                )
                else -> Unit
            }
            val response = AntDodoRpcCall.finishTask(item.sceneCode, item.type)
            if (response.isNullOrEmpty()) {
                return emptyActionResponse("AntDodoRpcCall.finishTask", item, "finishTask")
            }
            val result = JSONObject(response)
            if (isDodoTaskRpcSuccess(result)) {
                Log.dodo("物种任务🧾️[${item.title}]已提交，等待任务列表确认")
                return TaskFlowActionResult.success(progressChanged = false)
            }
            val failure = dodoActionFailureResult(
                response = result,
                rpc = "AntDodoRpcCall.finishTask",
                detail = dodoActionDetail(item, "finishTask")
            )
            return if (failure.code == "400000040" && item.sceneCode.isNotBlank()) {
                AntFarmRpcCall.doSceneTask(item.type, item.sceneCode, failure, sceneCode = item.sceneCode, source = "af-biodiversity") { fallback ->
                    dodoActionFailureResult(fallback, "AntFarmRpcCall.doFarmTask", dodoActionDetail(item, "finishTask"))
                }
            } else failure
        }

        override fun afterDeferred(item: TaskFlowItem, action: TaskFlowAction, result: TaskFlowActionResult) {
            val triggerAt = result.deferredUntil ?: return
            val context = ApplicationHook.appContext ?: return
            val owner = AccountSessionCoordinator.currentUserId()?.takeIf { it.isNotBlank() } ?: return
            val epoch = AccountSessionCoordinator.currentSessionEpoch()
            val waitKey = "${item.sceneCode}:${item.id}:${item.progress}"
            val payload = JSONObject().put("child_kind", PERSISTENT_CHILD_KIND)
                .put("child_id", TASK_FLOW_CHILD_ID).put("owner_user_id", owner)
                .put("session_epoch", epoch).put("wait_key", waitKey)
            UnifiedScheduler.schedulePersistentTrigger(
                context = context, name = "神奇物种任务续接", kind = PersistentScheduleKind.MODULE_CHILD,
                triggerAtMs = triggerAt, dedupeKey = "$PERSISTENT_CHILD_KIND:$owner:$waitKey:$triggerAt",
                payloadJson = payload.toString(), toleranceMs = PersistentScheduleDefaults.DEFAULT_TOLERANCE_MS,
                ownerUserId = owner, sessionEpoch = epoch,
            )
        }

        override fun actionKey(item: TaskFlowItem, action: TaskFlowAction): String {
            val taskKey = buildTaskKey(item.sceneCode, item.type)
            return when (action) {
                TaskFlowAction.RECEIVE -> "receive:$taskKey"
                TaskFlowAction.COMPLETE -> "complete:$taskKey"
                else -> super<TaskFlowAdapter>.actionKey(item, action)
            }
        }

        override fun logInfo(message: String) {
            Log.dodo(message)
        }

        override fun logError(message: String) {
            Log.error(TAG, message)
        }

        private fun emptyActionResponse(
            rpc: String,
            item: TaskFlowItem,
            phase: String
        ): TaskFlowActionResult {
            return TaskFlowActionResult.failure(
                failureType = TaskRpcFailureType.RETRYABLE_RPC,
                message = "${phase}返回空",
                rpc = rpc,
                detail = dodoActionDetail(item, phase),
                stopCurrentRound = true
            )
        }

        private fun missingRawResult(item: TaskFlowItem, phase: String): TaskFlowActionResult {
            return TaskFlowActionResult.failure(
                failureType = TaskRpcFailureType.UNKNOWN_NEEDS_REVIEW,
                message = "缺少任务原始数据",
                rpc = "DodoTaskFlowAdapter.$phase",
                detail = dodoActionDetail(item, phase)
            )
        }
    }

    private fun dodoActionFailureResult(
        response: JSONObject,
        rpc: String,
        detail: String
    ): TaskFlowActionResult {
        val code = extractDodoTaskFailureCode(response)
        val message = extractDodoTaskFailureMessage(response)
        return TaskFlowActionResult.failure(
            failureType = classifyDodoTaskFailure(response),
            code = code,
            message = message,
            rpc = rpc,
            raw = response.toString(),
            detail = detail
        )
    }

    private fun dodoActionDetail(item: TaskFlowItem, phase: String): String {
        return "taskType=${item.type} sceneCode=${item.sceneCode} action=$phase"
    }

    private fun parseDodoBizInfo(rawBizInfo: Any?): JSONObject {
        return when (rawBizInfo) {
            is JSONObject -> rawBizInfo
            is String -> rawBizInfo.takeIf { it.isNotBlank() }?.let {
                runCatching { JSONObject(it) }.getOrElse { JSONObject() }
            } ?: JSONObject()
            else -> JSONObject()
        }
    }

    private fun isDodoTaskRpcSuccess(response: JSONObject): Boolean {
        return response.optBoolean("success") ||
            response.optBoolean("isSuccess") ||
            response.optString("code") == "100000000" ||
            response.optString("resultCode").equals("SUCCESS", ignoreCase = true)
    }

    private fun classifyDodoTaskFailure(response: JSONObject): TaskRpcFailureType {
        val code = extractDodoTaskFailureCode(response)
        return when {
            code in setOf("400000030", "400000012") -> TaskRpcFailureType.TERMINAL_DONE
            code == "CAMP_TRIGGER_ERROR" -> TaskRpcFailureType.BUSINESS_LIMIT
            code == "400000040" -> TaskRpcFailureType.UNSUPPORTED_NO_CLOSURE
            code in setOf("20020012", "TASK_ID_INVALID", "ILLEGAL_ARGUMENT", "PROMISE_TEMPLATE_NOT_EXIST") ->
                TaskRpcFailureType.NON_RETRYABLE_INVALID
            code in setOf("3000", "REMOTE_INVOKE_EXCEPTION", "OP_REPEAT_CHECK") ||
                isDodoFailureMarkedRetryable(response) -> TaskRpcFailureType.RETRYABLE_RPC
            else -> TaskRpcFailureType.UNKNOWN_NEEDS_REVIEW
        }
    }

    private fun extractDodoTaskFailureCode(response: JSONObject): String {
        val code = response.optString("code")
            .ifBlank { response.optString("errorCode") }
            .ifBlank { response.optString("resultCode") }
        return code
    }

    private fun extractDodoTaskFailureMessage(response: JSONObject): String {
        return response.optString("desc")
            .ifBlank { response.optString("errorMsg") }
            .ifBlank { response.optString("resultDesc") }
            .ifBlank { response.optString("memo") }
            .ifBlank { response.toString() }
    }

    private fun isDodoFailureMarkedRetryable(response: JSONObject): Boolean {
        return listOf("retryable", "retriable", "canRetry").any { key ->
            response.has(key) && response.optBoolean(key, false)
        }
    }

    private fun containsAny(text: String, vararg keywords: String): Boolean {
        return keywords.any { keyword -> text.contains(keyword, ignoreCase = true) }
    }

    private fun parseDodoTaskProgressInt(source: JSONObject, key: String): Int? {
        val value = source.opt(key)
        return when (value) {
            is Number -> value.toInt()
            is String -> value.trim().toIntOrNull()
            else -> null
        }
    }

    private fun mapConsecutiveCollectPhase(item: TaskFlowItem): TaskFlowPhase {
        val current = item.current ?: 0
        val limit = item.limit
        val curCycleFinished = item.raw?.optJSONObject("taskInfo")?.optJSONObject("taskBaseInfo")?.optBoolean("curCycleFinished") == true
        val progressMessage = when {
            limit == null -> "缺少有效进度[${item.progress}]，等待服务端刷新"
            current < limit && curCycleFinished -> "今日已完成，连续进度[$current/$limit]，等待后续天数推进"
            current < limit -> "今日未完成，连续进度[$current/$limit]，等待主动抽卡推进"
            else -> "进度已满[$current/$limit]，等待服务端刷新为可领奖状态"
        }
        logDodoTaskProgressOnce("物种任务🧾️[${item.title}]$progressMessage，不调用finishTask")
        return TaskFlowPhase.BUSINESS_ACTION
    }

    private fun logDodoTaskProgressOnce(message: String) {
        if (loggedTaskProgressHints.add(message)) {
            Log.dodo(message)
        }
    }

    private fun shouldMaterializeManualTask(raw: JSONObject, taskBaseInfo: JSONObject): Boolean {
        if (!taskBaseInfo.optBoolean("reDecision")) {
            return false
        }
        if (!parseStringSet(taskBaseInfo.optJSONArray("reDecisionModeList")).contains("MANUAL")) {
            return false
        }
        if (taskBaseInfo.optLong("entityGenerateTime", 0L) > 0L ||
            taskBaseInfo.optLong("entityExpireTime", 0L) > 0L ||
            taskBaseInfo.optString("taskMode").isNotBlank()
        ) {
            return false
        }
        return raw.optString("taskGroupId").isNotBlank()
    }

    private fun parseStringSet(values: JSONArray?): Set<String> {
        if (values == null || values.length() == 0) {
            return emptySet()
        }
        val result = LinkedHashSet<String>()
        for (i in 0 until values.length()) {
            val value = values.optString(i).trim()
            if (value.isNotBlank()) {
                result.add(value)
            }
        }
        return result
    }

    private fun propList(allowReplenish: Boolean = true) {
        try {
            th@ while (!Thread.currentThread().isInterrupted) {
                val response = AntDodoRpcCall.propList()
                if (response.isNullOrEmpty()) {
                    Log.runtime(TAG, "propList返回空")
                    return
                }
                val jo = JSONObject(response)
                if (ResChecker.checkRes(TAG, jo)) {
                    val propList = jo.getJSONObject("data").optJSONArray("propList")
                    if (propList == null || propList.length() == 0) {
                        if (replenishDodoPropIfMissing(
                                allowReplenish = allowReplenish,
                                historyMissing = true,
                                friendMissing = true
                            )
                        ) {
                            return
                        }
                        Log.dodo("神奇物种道具跳过：未找到可使用的道具")
                        return
                    }
                    var hasHistoryProp = false
                    var hasFriendProp = false
                    for (i in 0 until propList.length()) {
                        val prop = propList.getJSONObject(i)
                        val propType = prop.optString("propType")
                        val propName = prop.optJSONObject("propConfig")?.optString("propName")
                            ?.takeIf { it.isNotBlank() } ?: propType
                        val propKind = resolvePropKind(propType)
                        val propIdList = prop.optJSONArray("propIdList")
                        val holdsNum = prop.optInt("holdsNum", propIdList?.length() ?: 0)
                        val hasUsablePropId = propIdList != null && propIdList.length() > 0
                        if (propKind == DodoPropKind.HISTORY_CARD && holdsNum > 0 && hasUsablePropId) {
                            hasHistoryProp = true
                        }
                        if (propKind == DodoPropKind.FRIEND_CARD && holdsNum > 0 && hasUsablePropId) {
                            hasFriendProp = true
                        }
                        if (!isUsePropType(propType)) {
                            Log.dodo("神奇物种道具跳过[$propName]：配置未开启")
                            continue
                        }
                        if (propIdList == null || propIdList.length() == 0) {
                            Log.runtime(TAG, "神奇物种道具[$propName]缺少propIdList")
                            continue
                        }
                        val propId = propIdList.getString(0)
                        val consumeTargetResult = resolvePropConsumeTarget(propType)
                        val consumeTarget = consumeTargetResult?.target
                        if (isUniversalCardProp(propType)) {
                            if (consumeTargetResult == null || !consumeTargetResult.querySucceeded) {
                                Log.dodo("神奇物种道具跳过[$propName]：目标卡查询失败")
                                continue
                            }
                            if (consumeTarget == null) {
                                Log.dodo("神奇物种道具跳过[$propName]：未找到可兑换的目标卡片")
                                continue
                            }
                        }
                        val consumeResponse = AntDodoRpcCall.consumeProp(propId, propType, consumeTarget?.animalId)
                        if (consumeResponse.isNullOrEmpty()) {
                            Log.runtime(TAG, "consumeProp返回空")
                            continue
                        }
                        val joConsume = JSONObject(consumeResponse)
                        if (!ResChecker.checkRes(TAG, joConsume)) {
                            Log.dodo("神奇物种道具使用失败[$propName]：${joConsume.optString("resultDesc", "未知错误")}")
                            Log.runtime(joConsume.toString())
                            continue
                        }
                        val useResult = joConsume.optJSONObject("data")?.optJSONObject("useResult")
                        val animal = useResult?.optJSONObject("animal")
                        if (animal != null) {
                            val ecosystem = animal.optString("ecosystem")
                            val name = animal.optString("name")
                            Log.dodo("使用道具🎭[$propName]#${formatAnimalDisplayName(ecosystem, name)}")
                        } else {
                            Log.dodo("使用道具🎭[$propName]")
                        }
                        useResult?.let { scratchAnimalCards(it) }
                        logPropRefreshState(propType, propName, consumeTarget, animal)
                        continue@th
                    }
                    if (replenishDodoPropIfMissing(
                            allowReplenish = allowReplenish,
                            historyMissing = !hasHistoryProp,
                            friendMissing = !hasFriendProp
                        )
                    ) {
                        return
                    }
                }
                break
            }
        } catch (th: Throwable) {
            Log.runtime(TAG, "AntDodo PropList err:")
            Log.printStackTrace(TAG, th)
        }
    }

    private fun replenishDodoPropIfMissing(
        allowReplenish: Boolean,
        historyMissing: Boolean,
        friendMissing: Boolean
    ): Boolean {
        if (!allowReplenish) {
            return false
        }
        var exchanged = false
        if (historyMissing && isUsePropType("COLLECT_HISTORY_ANIMAL_7_DAYS")) {
            val result = ExchangeReplenisher.replenish(
                need = ExchangeEffectNeed.DODO_HISTORY_CARD,
                reason = "神奇物种抽历史卡机会不足",
                maxCount = 1
            ) {
                AntDodoRpcCall.propList()
            }
            exchanged = exchanged || result == ExchangeReplenishResult.EXCHANGED
        }
        if (friendMissing && isUsePropType("COLLECT_TO_FRIEND_TIMES_7_DAYS")) {
            val result = ExchangeReplenisher.replenish(
                need = ExchangeEffectNeed.DODO_FRIEND_CARD,
                reason = "神奇物种抽好友卡机会不足",
                maxCount = 1
            ) {
                AntDodoRpcCall.propList()
            }
            exchanged = exchanged || result == ExchangeReplenishResult.EXCHANGED
        }
        if (exchanged) {
            Log.dodo("神奇物种道具已触发缺货补兑，重新查询道具列表")
            propList(allowReplenish = false)
        }
        return exchanged
    }

    private fun isUsePropType(propType: String): Boolean {
        var usePropType = useProp?.value ?: false
        usePropType = when (resolvePropKind(propType)) {
            DodoPropKind.CURRENT_BOOK_DRAW,
            DodoPropKind.UNIVERSAL_CARD -> usePropType || (usePropCollectTimes7Days?.value ?: false)
            DodoPropKind.HISTORY_CARD -> usePropType || (usePropCollectHistoryAnimal7Days?.value ?: false)
            DodoPropKind.FRIEND_CARD -> usePropType || (usePropCollectToFriendTimes7Days?.value ?: false)
            DodoPropKind.OTHER -> usePropType
        }
        return usePropType
    }

    private fun isUniversalCardProp(propType: String): Boolean {
        return resolvePropKind(propType) == DodoPropKind.UNIVERSAL_CARD
    }

    private fun resolvePropKind(propType: String): DodoPropKind {
        return when (propType) {
            "COLLECT_TIMES_7_DAYS" -> DodoPropKind.CURRENT_BOOK_DRAW
            "UNIVERSAL_CARD_7_DAYS" -> DodoPropKind.UNIVERSAL_CARD
            "COLLECT_HISTORY_ANIMAL_7_DAYS" -> DodoPropKind.HISTORY_CARD
            "COLLECT_TO_FRIEND_TIMES_7_DAYS" -> DodoPropKind.FRIEND_CARD
            else -> DodoPropKind.OTHER
        }
    }

    private fun resolvePropConsumeTarget(propType: String): PropTargetQueryResult? {
        return when (resolvePropKind(propType)) {
            DodoPropKind.UNIVERSAL_CARD -> resolveUniversalCardTarget()
            else -> null
        }
    }

    private fun resolveUniversalCardTarget(): PropTargetQueryResult {
        val currentBookTarget = queryCurrentBookUniversalCardTarget()
        if (!currentBookTarget.querySucceeded) {
            return currentBookTarget
        }
        currentBookTarget.target?.let { return PropTargetQueryResult(it, true) }
        return queryHistoricalBookUniversalCardTarget()
    }

    private fun queryCurrentBookUniversalCardTarget(): PropTargetQueryResult {
        return try {
            val response = AntDodoRpcCall.homePage()
            if (response.isNullOrEmpty()) {
                Log.runtime(TAG, "万能卡目标查询homePage返回空")
                return PropTargetQueryResult(null, false)
            }
            val jo = JSONObject(response)
            if (!ResChecker.checkRes(TAG, jo)) {
                Log.runtime(TAG, "万能卡目标查询homePage失败：${jo.optString("resultDesc")}")
                return PropTargetQueryResult(null, false)
            }
            val data = jo.getJSONObject("data")
            val animalBook = data.optJSONObject("animalBook")
            if (animalBook?.optBoolean("stopAnimalCirculation") == true) {
                return PropTargetQueryResult(null, true)
            }
            val currentBookId = animalBook?.optString("bookId").orEmpty()
            PropTargetQueryResult(
                findMissingAnimalTarget(data.optJSONArray("curCollection"), currentBookId),
                true
            )
        } catch (t: Throwable) {
            Log.printStackTrace(TAG, "queryCurrentBookUniversalCardTarget err:", t)
            PropTargetQueryResult(null, false)
        }
    }

    private fun queryHistoricalBookUniversalCardTarget(): PropTargetQueryResult {
        return try {
            var hasMore: Boolean
            var pageStart = 0
            var queryFailed = false
            do {
                val response = AntDodoRpcCall.queryBookList(9, pageStart)
                if (response.isNullOrEmpty()) {
                    Log.runtime(TAG, "万能卡目标查询queryBookList返回空")
                    return PropTargetQueryResult(null, false)
                }
                val jo = JSONObject(response)
                if (!ResChecker.checkRes(TAG, jo)) {
                    Log.runtime(TAG, "万能卡目标查询queryBookList失败：${jo.optString("resultDesc")}")
                    return PropTargetQueryResult(null, false)
                }
                val data = jo.getJSONObject("data")
                hasMore = data.optBoolean("hasMore")
                pageStart += 9
                val bookForUserList = data.optJSONArray("bookForUserList") ?: break
                for (i in 0 until bookForUserList.length()) {
                    val bookForUser = bookForUserList.optJSONObject(i) ?: continue
                    val animalBookResult = bookForUser.optJSONObject("animalBookResult")
                    if (animalBookResult?.optBoolean("stopAnimalCirculation") == true) {
                        continue
                    }
                    val bookId = animalBookResult?.optString("bookId").orEmpty()
                    if (bookId.isBlank()) {
                        continue
                    }
                    val targetResult = queryBookUniversalCardTarget(bookId)
                    if (!targetResult.querySucceeded) {
                        queryFailed = true
                        continue
                    }
                    targetResult.target?.let { return PropTargetQueryResult(it, true) }
                }
            } while (hasMore && !Thread.currentThread().isInterrupted)
            if (queryFailed) {
                PropTargetQueryResult(null, false)
            } else {
                PropTargetQueryResult(null, true)
            }
        } catch (t: Throwable) {
            Log.printStackTrace(TAG, "queryHistoricalBookUniversalCardTarget err:", t)
            PropTargetQueryResult(null, false)
        }
    }

    private fun queryBookUniversalCardTarget(bookId: String): PropTargetQueryResult {
        val response = AntDodoRpcCall.queryBookInfo(bookId)
        if (response.isNullOrEmpty()) {
            Log.runtime(TAG, "万能卡目标查询queryBookInfo返回空，bookId=$bookId")
            return PropTargetQueryResult(null, false)
        }
        val jo = JSONObject(response)
        if (!ResChecker.checkRes(TAG, jo)) {
            Log.runtime(TAG, "万能卡目标查询queryBookInfo失败，bookId=$bookId：${jo.optString("resultDesc")}")
            return PropTargetQueryResult(null, false)
        }
        val data = jo.getJSONObject("data")
        if (data.optJSONObject("animalBookResult")?.optBoolean("stopAnimalCirculation") == true) {
            return PropTargetQueryResult(null, true)
        }
        return PropTargetQueryResult(
            findMissingAnimalTarget(data.optJSONArray("animalForUserList"), bookId),
            true
        )
    }

    private fun findMissingAnimalTarget(collection: JSONArray?, fallbackBookId: String): PropConsumeTarget? {
        if (collection == null) {
            return null
        }
        for (i in 0 until collection.length()) {
            val item = collection.optJSONObject(i) ?: continue
            val collectDetail = item.optJSONObject("collectDetail")
            if (!isMissingCurrentAnimalCard(collectDetail)) {
                continue
            }
            val animal = item.optJSONObject("animal") ?: continue
            val animalId = animal.optString("animalId")
            val bookId = animal.optString("bookId").ifBlank { fallbackBookId }
            if (animalId.isBlank() || bookId.isBlank()) {
                continue
            }
            return PropConsumeTarget(
                bookId = bookId,
                animalId = animalId,
                ecosystem = animal.optString("ecosystem"),
                name = animal.optString("name")
            )
        }
        return null
    }

    private fun hasCurrentAnimalCard(collectDetail: JSONObject?): Boolean {
        if (collectDetail == null) {
            return false
        }
        return collectDetail.optBoolean("collect") ||
            collectDetail.optInt("count", 0) > 0
    }

    /** 无卡或持有不足两张且未生成勋章：允许通过换卡、道具等获取途径补齐至多两张 */
    private fun isMissingCurrentAnimalCard(collectDetail: JSONObject?): Boolean {
        if (collectDetail?.optBoolean("hasGeneratedBookMedal") == true) {
            return false
        }
        if (!hasCurrentAnimalCard(collectDetail)) {
            return true
        }
        return (collectDetail?.optInt("count", 0) ?: 1) < 2
    }

    private fun hasAnimalCardForBookMedal(collectDetail: JSONObject?): Boolean {
        return hasCurrentAnimalCard(collectDetail)
    }

    private fun logPropRefreshState(
        propType: String,
        propName: String,
        consumeTarget: PropConsumeTarget?,
        usedAnimal: JSONObject?
    ) {
        val refreshParts = mutableListOf<String>()
        queryPropHoldNum(propType)?.let {
            refreshParts.add("剩余${it}张")
        }
        val verifyBookId = usedAnimal?.optString("bookId").orEmpty().ifBlank { consumeTarget?.bookId.orEmpty() }
        val verifyAnimalId = usedAnimal?.optString("animalId").orEmpty().ifBlank { consumeTarget?.animalId.orEmpty() }
        if (verifyBookId.isNotBlank() && verifyAnimalId.isNotBlank()) {
            when (queryAnimalCollectedState(verifyBookId, verifyAnimalId)) {
                true -> refreshParts.add("目标卡已入库")
                false -> refreshParts.add("目标卡状态未确认")
                null -> Log.runtime(TAG, "神奇物种道具刷新[$propName]：目标卡查询失败")
            }
        }
        if (refreshParts.isNotEmpty()) {
            Log.dodo("神奇物种道具刷新[$propName]：${refreshParts.joinToString("，")}")
        }
    }

    private fun queryPropHoldNum(propType: String): Int? {
        return try {
            val response = AntDodoRpcCall.propList()
            if (response.isNullOrEmpty()) {
                Log.runtime(TAG, "道具刷新propList返回空")
                return null
            }
            val jo = JSONObject(response)
            if (!ResChecker.checkRes(TAG, jo)) {
                Log.runtime(TAG, "道具刷新propList失败：${jo.optString("resultDesc")}")
                return null
            }
            val propList = jo.getJSONObject("data").optJSONArray("propList") ?: return 0
            var holdsNum = 0
            val targetKind = resolvePropKind(propType)
            for (i in 0 until propList.length()) {
                val prop = propList.optJSONObject(i) ?: continue
                val currentPropType = prop.optString("propType")
                when (targetKind) {
                    DodoPropKind.OTHER -> if (currentPropType != propType) {
                        continue
                    }
                    else -> if (resolvePropKind(currentPropType) != targetKind) {
                        continue
                    }
                }
                val propIdList = prop.optJSONArray("propIdList")
                holdsNum += prop.optInt("holdsNum", propIdList?.length() ?: 0)
            }
            holdsNum
        } catch (t: Throwable) {
            Log.printStackTrace(TAG, "queryPropHoldNum err:", t)
            null
        }
    }

    private fun queryAnimalCollectedState(bookId: String, animalId: String): Boolean? {
        return try {
            val response = AntDodoRpcCall.queryBookInfo(bookId)
            if (response.isNullOrEmpty()) {
                Log.runtime(TAG, "目标卡刷新queryBookInfo返回空，bookId=$bookId")
                return null
            }
            val jo = JSONObject(response)
            if (!ResChecker.checkRes(TAG, jo)) {
                Log.runtime(TAG, "目标卡刷新queryBookInfo失败，bookId=$bookId：${jo.optString("resultDesc")}")
                return null
            }
            val animalForUserList = jo.getJSONObject("data").optJSONArray("animalForUserList") ?: return null
            for (i in 0 until animalForUserList.length()) {
                val item = animalForUserList.optJSONObject(i) ?: continue
                val currentAnimalId = item.optJSONObject("animal")?.optString("animalId").orEmpty()
                if (currentAnimalId == animalId) {
                    return hasCurrentAnimalCard(item.optJSONObject("collectDetail"))
                }
            }
            false
        } catch (t: Throwable) {
            Log.printStackTrace(TAG, "queryAnimalCollectedState err:", t)
            null
        }
    }

    private fun formatAnimalDisplayName(ecosystem: String, name: String): String {
        return when {
            ecosystem.isBlank() && name.isBlank() -> "未知物种"
            ecosystem.isBlank() -> name
            name.isBlank() -> ecosystem
            else -> "$ecosystem-$name"
        }
    }

    private fun resolveSendFriendCardTarget(): String? {
        val configuredUsers = sendFriendCard?.resolvedIds() ?: emptySet()
        if (configuredUsers.isEmpty()) {
            return null
        }
        val availableFriends = queryDodoAvailableFriendIds()
        if (availableFriends.isEmpty()) {
            return null
        }
        for (safeUserId in configuredUsers.shuffled()) {
            if (FriendGuard.shouldSkipFriend(safeUserId, TAG, "神奇物种送卡")) {
                continue
            }
            if (availableFriends.contains(safeUserId)) {
                return safeUserId
            }
            Log.dodo("神奇物种送卡跳过[${UserMap.getMaskName(safeUserId) ?: safeUserId}]：不在当前可赠送好友列表")
        }
        return null
    }

    private fun queryDodoAvailableFriendIds(): Set<String> {
        return try {
            val response = AntDodoRpcCall.queryFriend()
            if (response.isNullOrEmpty()) {
                emptySet()
            } else {
                val jo = JSONObject(response)
                if (!ResChecker.checkRes(TAG, jo)) {
                    emptySet()
                } else {
                    val friendList = jo.getJSONObject("data").optJSONArray("friends") ?: return emptySet()
                    val availableFriends = LinkedHashSet<String>()
                    for (i in 0 until friendList.length()) {
                        val userId = friendList.optJSONObject(i)?.optString("userId").orEmpty()
                        if (userId.isNotBlank() && !FriendGuard.shouldSkipFriend(userId, TAG, "神奇物种好友校验")) {
                            availableFriends.add(userId)
                            FriendCapabilityRecorder.record(userId, "DODO", FriendCapabilityState.OPEN, "AntDodo.queryFriend")
                        }
                    }
                    availableFriends
                }
            }
        } catch (t: Throwable) {
            Log.printStackTrace(TAG, "queryDodoAvailableFriendIds err:", t)
            emptySet()
        }
    }

    private fun sendAntDodoCard() {
        val targetUser = resolveSendFriendCardTarget() ?: return
        try {
            val homeResponse = AntDodoRpcCall.homePage()
            if (homeResponse.isNullOrEmpty()) {
                Log.runtime(TAG, "送卡homePage返回空")
                return
            }
            val home = JSONObject(homeResponse)
            if (!ResChecker.checkRes(TAG, home)) {
                Log.runtime(TAG, home.optString("resultDesc"))
                return
            }
            val animalBook = home.optJSONObject("data")?.optJSONObject("animalBook") ?: return
            if (animalBook.optBoolean("stopAnimalCirculation")) {
                return
            }
            val bookId = animalBook.optString("bookId")
            if (bookId.isBlank()) {
                return
            }
            val response = AntDodoRpcCall.queryBookInfo(bookId)
            if (response.isNullOrEmpty()) {
                Log.runtime(TAG, "queryBookInfo返回空")
                return
            }
            val jo = JSONObject(response)
            if (ResChecker.checkRes(TAG, jo)) {
                val animalForUserList = jo.getJSONObject("data").optJSONArray("animalForUserList")
                for (i in 0 until (animalForUserList?.length() ?: 0)) {
                    val animalForUser = animalForUserList!!.getJSONObject(i)
                    val count = animalForUser.optJSONObject("collectDetail")?.optInt("count", 0) ?: 0
                    if (count <= 1) {
                        continue
                    }
                    if (!scratchAnimalCards(animalForUser)) continue
                    val animal = animalForUser.getJSONObject("animal")
                    for (j in 1 until count) {
                        sendCard(animal, targetUser)
                    }
                }
            } else {
                Log.runtime(TAG, jo.optString("resultDesc"))
            }
        } catch (th: Throwable) {
            Log.runtime(TAG, "AntDodo SendAntDodoCard err:")
            Log.printStackTrace(TAG, th)
        }
    }

    private fun sendCard(animal: JSONObject, targetUser: String) {
        try {
            if (FriendGuard.shouldSkipFriend(targetUser, TAG, "神奇物种送卡")) {
                return
            }
            val animalId = animal.getString("animalId")
            val ecosystem = animal.getString("ecosystem")
            val name = animal.getString("name")
            val socialResponse = AntDodoRpcCall.social(animalId, targetUser)
            if (socialResponse.isNullOrEmpty()) {
                Log.runtime(TAG, "social返回空")
                return
            }
            val jo = JSONObject(socialResponse)
            if (ResChecker.checkRes(TAG, jo)) {
                taskListRefreshNeeded = true
                Log.dodo("赠送卡片🦕[${UserMap.getMaskName(targetUser) ?: targetUser}]#$ecosystem-$name")
            } else {
                Log.runtime(TAG, jo.getString("resultDesc"))
            }
        } catch (th: Throwable) {
            Log.runtime(TAG, "AntDodo SendCard err:")
            Log.printStackTrace(TAG, th)
        }
    }

    private fun collectToFriend(manageScheduledWakeup: Boolean = true): CollectToFriendResult {
        try {
            val queryResponse = AntDodoRpcCall.queryFriend()
            if (queryResponse.isNullOrEmpty()) {
                Log.runtime(TAG, "queryFriend返回空")
                return CollectToFriendResult(progressed = false, remainingCount = null)
            }
            var jo = JSONObject(queryResponse)
            if (ResChecker.checkRes(TAG, jo)) {
                var handled = false
                val friendData = jo.optJSONObject("data")
                val limitList = friendData?.optJSONObject("extend")?.optJSONArray("limit")
                if (limitList == null) {
                    Log.error(TAG, "神奇物种帮抽卡缺少限额列表 raw=$jo")
                    return CollectToFriendResult(progressed = false, remainingCount = null)
                }
                var collectLimit: JSONObject? = null
                for (i in 0 until limitList.length()) {
                    val limit = limitList.optJSONObject(i)
                    if (limit == null) {
                        Log.error(TAG, "神奇物种帮抽卡限额条目格式错误[index=$i] raw=${limitList.opt(i)}")
                        continue
                    }
                    if (limit.optString("actionCode") == "COLLECT_TO_FRIEND") {
                        collectLimit = limit
                        break
                    }
                }
                val resolvedLimit = collectLimit
                if (resolvedLimit == null || !resolvedLimit.has("startTime") || !resolvedLimit.has("leftLimit")) {
                    Log.runtime(TAG, "神奇物种帮抽卡限额缺少COLLECT_TO_FRIEND.startTime/leftLimit")
                    return CollectToFriendResult(progressed = false, remainingCount = null)
                }
                val startTime = resolvedLimit.opt("startTime")?.toString()?.toLongOrNull()
                val leftLimit = resolvedLimit.opt("leftLimit")?.toString()?.toIntOrNull()
                if (startTime == null || startTime < 0 || leftLimit == null || leftLimit < 0) {
                    Log.error(TAG, "神奇物种帮抽卡限额无效 raw=$resolvedLimit")
                    return CollectToFriendResult(progressed = false, remainingCount = null)
                }
                var count: Int = leftLimit
                if (startTime > System.currentTimeMillis()) {
                    if (manageScheduledWakeup) {
                        registerCollectToFriendSchedule(startTime)
                    }
                    return CollectToFriendResult(progressed = false, remainingCount = count)
                }
                if (count <= 0) {
                    return CollectToFriendResult(progressed = false, remainingCount = 0)
                }
                val initialCount = count
                val friendList = friendData?.optJSONArray("friends")
                if (friendList == null) {
                    Log.error(TAG, "神奇物种帮抽卡缺少好友列表 raw=$jo")
                    return CollectToFriendResult(progressed = false, remainingCount = null)
                }
                for (i in (0 until friendList.length()).shuffled()) {
                    if (count <= 0) break
                    val friend = friendList.optJSONObject(i)
                    val useId = friend?.optString("userId").orEmpty()
                    val dailyCollect = friend?.opt("dailyCollect")?.toString()?.toBooleanStrictOrNull()
                    if (friend == null || useId.isBlank() || dailyCollect == null) {
                        Log.error(TAG, "神奇物种帮抽卡好友条目缺少有效身份或状态[index=$i] raw=${friendList.opt(i)}")
                        continue
                    }
                    if (dailyCollect) {
                        continue
                    }
                    if (FriendGuard.shouldSkipFriend(useId, TAG, "神奇物种帮抽卡")) {
                        continue
                    }
                    var isCollectToFriend = collectToFriendList?.contains(useId) == true
                    if (collectToFriendType?.value == CollectToFriendType.DONT_COLLECT) {
                        isCollectToFriend = !isCollectToFriend
                    }
                    if (!isCollectToFriend) {
                        continue
                    }
                    val collectFriendResponse = AntDodoRpcCall.collect(useId)
                    if (collectFriendResponse.isNullOrEmpty()) {
                        Log.runtime(TAG, "collect(friend)返回空")
                        continue
                    }
                    jo = JSONObject(collectFriendResponse)
                    if (ResChecker.checkRes(TAG, jo)) {
                        taskListRefreshNeeded = true
                        val collectData = jo.optJSONObject("data")
                        if (collectData == null) {
                            Log.error(TAG, "神奇物种帮抽卡响应缺少data，保留后续回查 raw=$jo")
                            return CollectToFriendResult(progressed = false, remainingCount = null)
                        }
                        val animal = collectData.optJSONObject("animal")
                        val ecosystem = animal?.optString("ecosystem", "未知生态") ?: "未知生态"
                        val name = animal?.optString("name", "未知物种") ?: "未知物种"
                        val userName = UserMap.getMaskName(useId) ?: useId
                        Log.dodo("神奇物种🦕帮好友[$userName]抽卡[$ecosystem]#$name")
                        handleFriendExchange(useId, collectData)
                        val refreshedCount = queryCollectToFriendLeftLimit()
                        if (refreshedCount == null) {
                            Log.runtime(TAG, "神奇物种帮抽卡动作成功但未能确认剩余次数，停止当前链路")
                            return CollectToFriendResult(progressed = false, remainingCount = null)
                        }
                        if (refreshedCount >= count) {
                            Log.runtime(TAG, "神奇物种帮抽卡动作成功但剩余次数未推进#$refreshedCount")
                            return CollectToFriendResult(progressed = false, remainingCount = refreshedCount)
                        }
                        count = refreshedCount
                        handled = true
                    } else if (!ResChecker.isSilentFailure(jo)) {
                        val message = jo.optString("resultDesc").ifBlank {
                            jo.optString("desc", "帮好友抽卡失败")
                        }
                        Log.runtime(TAG, message)
                    }
                }
                val remainingCount = count
                when {
                    remainingCount == 0 -> Log.dodo("神奇物种🦕帮好友抽卡机会已全部使用")
                    remainingCount < initialCount -> Log.dodo("神奇物种帮抽卡剩余次数#$remainingCount")
                    handled -> Log.runtime(TAG, "神奇物种帮抽卡动作成功但剩余次数未推进#$remainingCount")
                    else -> Log.dodo("神奇物种帮抽卡仍有${remainingCount}次机会，但当前没有符合配置的好友")
                }
                return CollectToFriendResult(
                    progressed = handled && remainingCount < initialCount,
                    remainingCount = remainingCount,
                )
            } else if (!ResChecker.isSilentFailure(jo)) {
                val message = jo.optString("resultDesc").ifBlank {
                    jo.optString("desc", "查询神奇物种好友列表失败")
                }
                Log.runtime(TAG, message)
            }
        } catch (t: Throwable) {
            if (t is CancellationException || t is InterruptedException) throw t
            Log.runtime(TAG, "AntDodo CollectHelpFriend err:")
            Log.printStackTrace(TAG, t)
        }
        return CollectToFriendResult(progressed = false, remainingCount = null)
    }

    private fun queryCollectToFriendLeftLimit(): Int? {
        val response = AntDodoRpcCall.queryFriend()
        if (response.isNullOrEmpty()) {
            return null
        }
        val json = JSONObject(response)
        if (!ResChecker.checkRes(TAG, json)) {
            return null
        }
        val limitList = json.optJSONObject("data")?.optJSONObject("extend")?.optJSONArray("limit") ?: return null
        for (index in 0 until limitList.length()) {
            val limit = limitList.optJSONObject(index) ?: continue
            if (limit.optString("actionCode") == "COLLECT_TO_FRIEND") {
                val leftLimit = limit.opt("leftLimit")?.toString()?.toIntOrNull()
                if (leftLimit == null || leftLimit < 0) {
                    Log.error(TAG, "神奇物种帮抽卡回查缺少有效leftLimit raw=$limit")
                    return null
                }
                return leftLimit
            }
        }
        return null
    }

    private fun registerCollectToFriendSchedule(triggerAtMs: Long) {
        val context = ApplicationHook.appContext ?: return
        val ownerUserId =
            AccountSessionCoordinator.currentUserId()?.takeIf { it.isNotBlank() }
                ?: UserMap.currentUid?.takeIf { it.isNotBlank() }
                ?: return
        val sessionEpoch = AccountSessionCoordinator.currentSessionEpoch()
        val payload =
            JSONObject()
                .put("child_kind", PERSISTENT_CHILD_KIND)
                .put("child_id", COLLECT_TO_FRIEND_CHILD_ID)
                .put("owner_user_id", ownerUserId)
                .put("session_epoch", sessionEpoch)
        val schedule = UnifiedScheduler.schedulePersistentTrigger(
            context = context,
            name = "神奇物种子任务:帮好友抽卡",
            kind = PersistentScheduleKind.MODULE_CHILD,
            triggerAtMs = triggerAtMs,
            dedupeKey = collectToFriendDedupeKey(ownerUserId),
            payloadJson = payload.toString(),
            toleranceMs = PersistentScheduleDefaults.DEFAULT_TOLERANCE_MS,
            ownerUserId = ownerUserId,
            sessionEpoch = sessionEpoch,
        )
        if (schedule.state == PersistentScheduleState.SCHEDULED) {
            Log.dodo("神奇物种帮抽卡将在开放时间继续执行")
        } else {
            Log.runtime(TAG, "神奇物种帮抽卡持久调度注册失败:${schedule.lastError.orEmpty()}")
        }
    }

    internal fun triggerPersistentCollectToFriend(
        payloadJson: String,
        scheduleId: String,
        source: String,
    ): Boolean {
        val payload = runCatching { JSONObject(payloadJson.ifBlank { "{}" }) }.getOrDefault(JSONObject())
        val ownerUserId = payload.optString("owner_user_id").trim()
        val sessionEpoch = payload.optLong("session_epoch", 0L)
        Log.dodo(
            "神奇物种持久帮抽卡接管[scheduleId=$scheduleId] state=QUEUED source=$source owner=$ownerUserId session=$sessionEpoch",
        )
        if (
            ownerUserId.isBlank() ||
            sessionEpoch <= 0L ||
            !AccountSessionCoordinator.isCurrentSession(ownerUserId, sessionEpoch)
        ) {
            Log.dodo("神奇物种持久帮抽卡会话已失效，跳过执行")
            PersistentScheduleRegistry.markFired(
                ApplicationHook.appContext,
                scheduleId,
                source = "dodo_invalid_session:$source",
            )
            return true
        }
        if (collectToFriend?.value != true) {
            Log.dodo("神奇物种持久帮抽卡触发时功能已关闭，跳过执行")
            PersistentScheduleRegistry.markFired(
                ApplicationHook.appContext,
                scheduleId,
                source = "dodo_disabled:$source",
            )
            return true
        }
        return executePersistentChild(
            scheduleId = scheduleId,
            ownerUserId = ownerUserId,
            sessionEpoch = sessionEpoch,
            source = "dodo_collect_to_friend:$source",
            workflowQueue = taskWorkflowQueue,
        ) {
            if (!isEnable() || collectToFriend?.value != true) {
                return@executePersistentChild TaskExecutionOutcome.SKIPPED
            }
            runInterruptible(Dispatchers.IO) {
                loggedTaskProgressHints.clear()
                val result = collectToFriend(manageScheduledWakeup = false)
                val rewardResult = if (result.progressed || result.completed || taskListRefreshNeeded) {
                    // 次数已用尽时也补回查，覆盖抽卡成功后进程在领奖前退出的情况。
                    receiveTaskAward() ?: return@runInterruptible TaskExecutionOutcome.FAILED
                } else null
                when {
                    rewardResult?.interrupted == true -> TaskExecutionOutcome.CANCELLED
                    rewardResult != null && rewardResult.failureCount > 0 -> TaskExecutionOutcome.FAILED
                    !result.completed -> {
                        Log.error(TAG, "持久帮抽卡尚未完成 remaining=${result.remainingCount ?: "unknown"}")
                        TaskExecutionOutcome.FAILED
                    }
                    rewardResult?.completed == true -> TaskExecutionOutcome.SUCCESS
                    else -> TaskExecutionOutcome.DEFERRED
                }
            }
        }
    }

    private fun collectToFriendDedupeKey(ownerUserId: String): String = "dodo_child_$ownerUserId::$COLLECT_TO_FRIEND_CHILD_ID"

    private fun hasPendingCollectToFriendSchedule(): Boolean {
        val ownerUserId =
            AccountSessionCoordinator.currentUserId()?.takeIf { it.isNotBlank() }
                ?: UserMap.currentUid?.takeIf { it.isNotBlank() }
                ?: return false
        val sessionEpoch = AccountSessionCoordinator.currentSessionEpoch()
        if (sessionEpoch <= 0L) {
            return false
        }
        val dedupeKey = collectToFriendDedupeKey(ownerUserId)
        val now = System.currentTimeMillis()
        return PersistentScheduleRegistry.list().any { schedule ->
            schedule.kind == PersistentScheduleKind.MODULE_CHILD &&
                schedule.ownerUserId?.trim() == ownerUserId &&
                schedule.sessionEpoch == sessionEpoch &&
                schedule.dedupeKey == dedupeKey &&
                when (schedule.state) {
                    PersistentScheduleState.SCHEDULED -> schedule.triggerAtMs > now
                    PersistentScheduleState.QUEUED,
                    PersistentScheduleState.RUNNING,
                    -> true

                    else -> false
                }
        }
    }

    private fun handleFriendExchange(targetUserId: String, collectData: JSONObject) {
        val animal = collectData.optJSONObject("animal") ?: return
        val targetAnimalId = animal.optString("animalId")
        if (targetAnimalId.isBlank()) {
            return
        }
        val collectDetail = collectData.optJSONObject("collectDetail")
        if (!isMissingCurrentAnimalCard(collectDetail)) {
            giveUpFriendExchange(targetUserId, "已有目标卡或当前勋章已完成，保留重复卡")
            return
        }
        val notifyResponse = AntDodoRpcCall.socialExchangeMsg(targetAnimalId, targetUserId)
        if (notifyResponse.isNullOrEmpty()) {
            Log.runtime(TAG, "social(EXCHANGE_MSG)返回空")
            return
        }
        val notifyResult = JSONObject(notifyResponse)
        if (!ResChecker.checkRes(TAG, notifyResult)) {
            logDodoFriendBusinessFailure("通知交换", targetUserId, notifyResult)
            return
        }
        val candidateResult = queryExchangeCardCandidate(targetAnimalId)
        if (!candidateResult.querySucceeded) {
            Log.runtime(TAG, "神奇物种好友换卡[${UserMap.getMaskName(targetUserId) ?: targetUserId}]：查询可交换卡片失败")
            return
        }
        val candidate = candidateResult.candidate
        if (candidate == null) {
            giveUpFriendExchange(targetUserId, "没有可交换的冗余卡")
            return
        }
        val exchangeResponse = AntDodoRpcCall.exchange(candidate.animalId, targetAnimalId, targetUserId)
        if (exchangeResponse.isNullOrEmpty()) {
            Log.runtime(TAG, "exchange返回空")
            return
        }
        val exchangeResult = JSONObject(exchangeResponse)
        if (ResChecker.checkRes(TAG, exchangeResult)) {
            exchangeResult.optJSONObject("data")?.let { scratchAnimalCards(it) }
            val targetAnimal = exchangeResult.optJSONObject("data")?.optJSONObject("animal") ?: animal
            Log.dodo(
                "神奇物种🦕帮好友换卡[${UserMap.getMaskName(targetUserId) ?: targetUserId}]#${candidate.displayName}→${
                    formatAnimalDisplayName(
                        targetAnimal.optString("ecosystem"),
                        targetAnimal.optString("name")
                    )
                }"
            )
            return
        }
        logDodoFriendBusinessFailure("交换卡片", targetUserId, exchangeResult)
    }

    private fun queryExchangeCardCandidate(targetAnimalId: String): ExchangeCardCandidateQueryResult {
        return try {
            var pageStart: Any = 0
            var maxCount = 1
            var candidate: ExchangeCardCandidate? = null
            var candidateCollection: JSONObject? = null
            val visitedPages = hashSetOf<String>()
            while (!Thread.currentThread().isInterrupted) {
                check(visitedPages.add(pageStart.toString())) { "换卡库存分页游标重复：$pageStart" }
                val response = AntDodoRpcCall.queryMyCollection(targetAnimalId, 18, pageStart)
                if (response.isNullOrEmpty()) {
                    Log.runtime(TAG, "queryMyCollection返回空")
                    return ExchangeCardCandidateQueryResult(null, false)
                }
                val jo = JSONObject(response)
                if (!ResChecker.checkRes(TAG, jo)) {
                    Log.runtime(TAG, "queryMyCollection失败：${jo.optString("resultDesc")}")
                    return ExchangeCardCandidateQueryResult(null, false)
                }
                val data = jo.getJSONObject("data")
                val animalCollectionInfoList = data.getJSONArray("animalCollectionInfoList")
                for (i in 0 until animalCollectionInfoList.length()) {
                    val collection = animalCollectionInfoList.getJSONObject(i)
                    val animal = collection.getJSONObject("animal")
                    val animalId = animal.optString("animalId")
                    val count = collection.optJSONObject("collectDetail")?.optInt("count", 0) ?: 0
                    if (animalId.isBlank() || animalId == targetAnimalId || count <= maxCount) continue
                    maxCount = count
                    candidateCollection = collection
                    candidate = ExchangeCardCandidate(
                        animalId = animalId,
                        displayName = formatAnimalDisplayName(animal.optString("ecosystem"), animal.optString("name"))
                    )
                }
                if (!data.getBoolean("hasMore")) {
                    if (candidateCollection != null && !scratchAnimalCards(candidateCollection)) {
                        return ExchangeCardCandidateQueryResult(null, false)
                    }
                    return ExchangeCardCandidateQueryResult(candidate, true)
                }
                check(animalCollectionInfoList.length() > 0) { "换卡库存非末页为空" }
                val nextPageStart = data.opt("nextPageStart")
                check(nextPageStart != null && nextPageStart != JSONObject.NULL) { "换卡库存缺少下一页游标" }
                pageStart = nextPageStart
            }
            ExchangeCardCandidateQueryResult(null, false)
        } catch (t: Throwable) {
            Log.printStackTrace(TAG, "queryExchangeCardCandidate err:", t)
            ExchangeCardCandidateQueryResult(null, false)
        }
    }

    private fun giveUpFriendExchange(targetUserId: String, reason: String) {
        val response = AntDodoRpcCall.socialGiveUpExchange(targetUserId)
        if (response.isNullOrEmpty()) {
            Log.runtime(TAG, "social(GIVE_UP_EXCHANGE)返回空")
            return
        }
        val jo = JSONObject(response)
        if (ResChecker.checkRes(TAG, jo)) {
            Log.dodo("神奇物种好友换卡放弃[${UserMap.getMaskName(targetUserId) ?: targetUserId}]：$reason")
            return
        }
        logDodoFriendBusinessFailure("放弃交换", targetUserId, jo)
    }

    private fun logDodoFriendBusinessFailure(action: String, targetUserId: String, response: JSONObject) {
        val code = extractDodoTaskFailureCode(response)
        val message = extractDodoTaskFailureMessage(response)
        val userName = UserMap.getMaskName(targetUserId) ?: targetUserId
        when (classifyDodoFriendBusinessFailure(response)) {
            DodoBusinessFailureKind.TERMINAL -> {
                Log.dodo(
                    "神奇物种好友换卡[$userName]${action}跳过：$message${
                        if (code.isBlank()) "" else "($code)"
                    }"
                )
            }

            DodoBusinessFailureKind.RETRYABLE -> {
                Log.runtime(TAG, "神奇物种好友换卡[$userName]${action}待重试：$message${if (code.isBlank()) "" else "($code)"}")
            }

            DodoBusinessFailureKind.UNKNOWN -> {
                Log.runtime(TAG, "神奇物种好友换卡[$userName]${action}异常：$message${if (code.isBlank()) "" else "($code)"}")
            }
        }
    }

    private fun classifyDodoFriendBusinessFailure(response: JSONObject): DodoBusinessFailureKind {
        val code = extractDodoTaskFailureCode(response)
        val desc = extractDodoTaskFailureMessage(response)
        return when {
            code in setOf(
                "EXCHANGED",
                "NO_OWNER_ANIMAL",
                "NO_TARGET_OWNER_ANIMAL",
                "EXCHANGE_ANIMAL_EQUAL",
                "EXCHANGE_NOT_YOU_COLLECT",
                "TIME_LIMIT_EXCEED_7D",
                "EXCHANGE_NOT_START",
                "NOT_FRIEND",
                "FRIEND_COLLECTED_LIMIT",
                "COLLECT_TO_FRIEND_LIMIT",
                "COLLECT_LIMIT_TO_OTHER",
                "NOT_START",
                "TARGET_USER_NOT_V2",
                "PRODUCT_NOT_OPEN",
                "DISABLE_ANIMAL_CIRCULATION",
                "NO_ANIMAL_BOOK_CAN_COLLECT",
                "OTHER_RECEIVE",
                "YOURSELF_RECEIVE"
            ) ||
                containsAny(
                    desc,
                    "已经交换",
                    "你还没有这张物种卡片",
                    "对方不拥有该物种卡",
                    "交换的物种卡不能相同",
                    "交换时间",
                    "链接超过7天",
                    "功能暂未开放",
                    "版权限制",
                    "该物种卡已被其他人领取",
                    "该物种卡已被你领取"
                ) -> DodoBusinessFailureKind.TERMINAL

            code in setOf("3000", "REMOTE_INVOKE_EXCEPTION", "SYSTEM_ERROR") ||
                containsAny(desc, "系统出错", "系统繁忙", "稍后", "重试", "人数过多") ||
                isDodoFailureMarkedRetryable(response) -> DodoBusinessFailureKind.RETRYABLE

            else -> DodoBusinessFailureKind.UNKNOWN
        }
    }

    private fun autoGenerateBook() {
        try {
            val generatedBookIds = LinkedHashSet<String>()
            generateCurrentBookIfReminded()?.let { generatedBookIds.add(it) }
            var hasMore: Boolean
            var pageStart = 0
            do {
                if (Thread.currentThread().isInterrupted) {
                    break
                }
                val bookListResponse = AntDodoRpcCall.queryBookList(9, pageStart)
                if (bookListResponse.isNullOrEmpty()) {
                    Log.runtime(TAG, "queryBookList返回空")
                    break
                }
                var jo = JSONObject(bookListResponse)
                if (!ResChecker.checkRes(TAG, jo)) {
                    Log.runtime(TAG, "queryBookList失败：${jo.optString("resultDesc", jo.toString())}")
                    break
                }
                jo = jo.getJSONObject("data")
                hasMore = jo.optBoolean("hasMore")
                pageStart += 9
                val bookForUserList = jo.optJSONArray("bookForUserList") ?: break
                for (i in 0 until bookForUserList.length()) {
                    val bookForUser = bookForUserList.optJSONObject(i) ?: continue
                    val animalBookResult = bookForUser.optJSONObject("animalBookResult") ?: continue
                    if (animalBookResult.optBoolean("stopAnimalCirculation")) {
                        continue
                    }
                    val bookId = animalBookResult.optString("bookId")
                    if (bookId.isBlank() || generatedBookIds.contains(bookId)) {
                        continue
                    }
                    if (!isBookReadyForMedal(bookForUser, bookId)) {
                        continue
                    }
                    val ecosystem = animalBookResult.optString("ecosystem")
                    if (generateBookMedal(bookId, ecosystem)) {
                        generatedBookIds.add(bookId)
                    }
                }
            } while (hasMore && !Thread.currentThread().isInterrupted)
        } catch (t: Throwable) {
            Log.runtime(TAG, "generateBookMedal err:")
            Log.printStackTrace(TAG, t)
        }
    }

    private fun generateCurrentBookIfReminded(): String? {
        val homeResponse = AntDodoRpcCall.homePage()
        if (homeResponse.isNullOrEmpty()) {
            Log.runtime(TAG, "自动合成图鉴homePage返回空")
            return null
        }
        val jo = JSONObject(homeResponse)
        if (!ResChecker.checkRes(TAG, jo)) {
            Log.runtime(TAG, "自动合成图鉴homePage失败：${jo.optString("resultDesc", jo.toString())}")
            return null
        }
        val data = jo.getJSONObject("data")
        if (!data.optBoolean("showBookMedalGenerationRemind") && !data.optBoolean("showMedalRedDot")) {
            return null
        }
        val animalBook = data.optJSONObject("animalBook") ?: return null
        if (animalBook.optBoolean("stopAnimalCirculation")) {
            return null
        }
        val bookId = animalBook.optString("bookId")
        if (bookId.isBlank()) {
            return null
        }
        val ecosystem = animalBook.optString("ecosystem")
        return if (isBookCollectedButMedalMissing(bookId) == true && generateBookMedal(bookId, ecosystem)) {
            bookId
        } else {
            null
        }
    }

    private fun isBookReadyForMedal(bookForUser: JSONObject, bookId: String): Boolean {
        val status = bookForUser.optString("medalGenerationStatus")
        if (isGeneratedBookStatus(status) || isNotReadyBookStatus(status)) {
            return false
        }
        if (isReadyBookStatus(status)) {
            return true
        }
        return isBookCollectedButMedalMissing(bookId) == true
    }

    private fun isGeneratedBookStatus(status: String): Boolean {
        return status == "已合成" ||
            status == "已生成" ||
            status.uppercase() in setOf(
                "GENERATED",
                "HAS_GENERATED",
                "GENERATED_BOOK_MEDAL"
            )
    }

    private fun isReadyBookStatus(status: String): Boolean {
        return status == "已集齐" ||
            status.uppercase() in setOf(
                "CAN_GENERATE",
                "CAN_GENERATE_MEDAL",
                "CAN_GENERATE_BOOK_MEDAL",
                "READY_TO_GENERATE",
                "TO_GENERATE"
            )
    }

    private fun isNotReadyBookStatus(status: String): Boolean {
        return status == "未集齐" ||
            status == "不可合成" ||
            status.uppercase() in setOf(
                "CAN_NOT_GENERATE",
                "NOT_COLLECTED",
                "UNFINISHED"
            )
    }

    private fun isBookCollectedButMedalMissing(bookId: String): Boolean? {
        return try {
            val response = AntDodoRpcCall.queryBookInfo(bookId)
            if (response.isNullOrEmpty()) {
                Log.runtime(TAG, "自动合成图鉴queryBookInfo返回空，bookId=$bookId")
                return null
            }
            val jo = JSONObject(response)
            if (!ResChecker.checkRes(TAG, jo)) {
                Log.runtime(TAG, "自动合成图鉴queryBookInfo失败，bookId=$bookId：${jo.optString("resultDesc")}")
                return null
            }
            val data = jo.getJSONObject("data")
            if (data.optJSONObject("animalBookResult")?.optBoolean("stopAnimalCirculation") == true) {
                return false
            }
            val animalForUserList = data.optJSONArray("animalForUserList") ?: return null
            if (animalForUserList.length() == 0) {
                return false
            }
            var hasMedalPending = false
            for (i in 0 until animalForUserList.length()) {
                val collectDetail = animalForUserList.optJSONObject(i)?.optJSONObject("collectDetail")
                if (!hasAnimalCardForBookMedal(collectDetail)) {
                    return false
                }
                if (collectDetail?.optBoolean("hasGeneratedBookMedal") != true) {
                    hasMedalPending = true
                }
            }
            hasMedalPending
        } catch (t: Throwable) {
            Log.printStackTrace(TAG, "isBookCollectedButMedalMissing err:", t)
            null
        }
    }

    private fun generateBookMedal(bookId: String, ecosystem: String): Boolean {
        if (scratchCard?.value == true) {
            val book = JSONObject(AntDodoRpcCall.queryBookInfo(bookId))
            if (!ResChecker.checkRes(TAG, "合成前卡片查询失败：", book)) return false
            val collections = book.getJSONObject("data").getJSONArray("animalForUserList")
            for (i in 0 until collections.length()) {
                if (!scratchAnimalCards(collections.getJSONObject(i))) return false
            }
        }
        val medalResponse = AntDodoRpcCall.generateBookMedal(bookId)
        if (medalResponse.isNullOrEmpty()) {
            Log.runtime(TAG, "generateBookMedal返回空，bookId=$bookId")
            return false
        }
        val jo = JSONObject(medalResponse)
        if (!ResChecker.checkRes(TAG, jo)) {
            Log.dodo("合成图鉴失败[${ecosystem.ifBlank { bookId }}]：${jo.optString("resultDesc", jo.toString())}")
            return false
        }
        Log.dodo("神奇物种🦕合成勋章[${ecosystem.ifBlank { bookId }}]")
        return true
    }

    interface CollectToFriendType {
        companion object {
            const val COLLECT = 0
            const val DONT_COLLECT = 1
            val nickNames = arrayOf("选中帮抽卡", "选中不帮抽卡")
        }
    }

    private enum class DodoPropKind {
        CURRENT_BOOK_DRAW,
        UNIVERSAL_CARD,
        HISTORY_CARD,
        FRIEND_CARD,
        OTHER
    }

    private enum class DodoBusinessFailureKind {
        TERMINAL,
        RETRYABLE,
        UNKNOWN
    }

    private data class PropConsumeTarget(
        val bookId: String,
        val animalId: String,
        val ecosystem: String,
        val name: String
    )

    private data class ExchangeCardCandidate(
        val animalId: String,
        val displayName: String
    )

    private data class PropTargetQueryResult(
        val target: PropConsumeTarget?,
        val querySucceeded: Boolean
    )

    private data class ExchangeCardCandidateQueryResult(
        val candidate: ExchangeCardCandidate?,
        val querySucceeded: Boolean
    )

    companion object {
        private val TAG = AntDodo::class.java.simpleName
        private const val TASK_BLACKLIST_MODULE = "神奇物种"
        const val PERSISTENT_CHILD_KIND = "dodo_child_task"
        const val COLLECT_TO_FRIEND_CHILD_ID = "collect_to_friend"
        const val TASK_FLOW_CHILD_ID = "task_flow"
        private val BUSINESS_DRIVEN_TASK_TYPES = setOf("HELP_FRIEND_COLLECT")
    }
}

